import { useState, type CSSProperties, type FormEvent } from 'react';
import { ApiClientError, changePassword, type AuthenticatedUser } from '../lib/api';
import {
  INTERFACE_FONT_OPTIONS,
  WRITING_EDITOR_WIDTH_OPTIONS,
  WRITING_FONT_OPTIONS,
  WRITING_FONT_SIZE_OPTIONS,
  WRITING_LINE_SPACING_OPTIONS,
  getAppearanceCssVariables,
  getInterfaceFontOption,
  getWritingFontOption,
} from '../lib/writingAppearance';
import type {
  InterfaceFontId,
  WritingEditorWidth,
  WritingFontId,
  WritingFontSize,
  WritingLineSpacing,
} from '../lib/types';
import { useLoreLoomStore } from '../store/useLoreLoomStore';
import PasswordField from '../components/PasswordField';

type PasswordChangeFormState = {
  currentPassword: string;
  newPassword: string;
  passwordConfirmation: string;
};

type ValidationIssue = {
  message: string;
};

const initialFormState: PasswordChangeFormState = {
  currentPassword: '',
  newPassword: '',
  passwordConfirmation: '',
};

function formatChangePasswordError(error: unknown) {
  if (error instanceof ApiClientError) {
    if (
      error.status === 400 &&
      typeof error.data === 'object' &&
      error.data !== null &&
      'issues' in error.data &&
      Array.isArray(error.data.issues)
    ) {
      const issues = error.data.issues.filter(
        (issue): issue is ValidationIssue =>
          typeof issue === 'object' &&
          issue !== null &&
          'message' in issue &&
          typeof (issue as { message?: unknown }).message === 'string',
      );

      if (issues.length > 0) {
        return issues.map((issue) => issue.message).join('\n');
      }
    }

    if (error.status === 400 && typeof error.data === 'object' && error.data !== null) {
      if ('error' in error.data && error.data.error === 'invalid_current_password') {
        return 'The current password was not accepted.';
      }
    }

    if (error.status === 401) {
      return 'Your session is no longer valid. Please sign in again.';
    }

    return error.message;
  }

  return error instanceof Error ? error.message : 'Something went wrong while talking to the LoreLoom API.';
}

function formatUserLabel(user: AuthenticatedUser) {
  return user.displayName?.trim() || user.username;
}

function ChoiceRow<T extends string>({
  label,
  helper,
  options,
  value,
  onChange,
}: {
  label: string;
  helper: string;
  options: Array<{ id: T; label: string }>;
  value: T;
  onChange: (value: T) => void;
}) {
  return (
    <div className="space-y-3">
      <div>
        <h3 className="text-sm font-medium text-white">{label}</h3>
        <p className="mt-1 text-sm leading-6 text-slate-400">{helper}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => {
          const isActive = option.id === value;
          return (
            <button
              key={option.id}
              type="button"
              onClick={() => onChange(option.id)}
              aria-pressed={isActive}
              className={`app-focus-ring inline-flex rounded-full border px-3 py-2 text-sm transition ${
                isActive
                  ? 'border-[color:var(--app-border-strong)] bg-[rgba(123,90,137,0.16)] text-[color:var(--app-gold-soft)]'
                  : 'border-[color:var(--app-border)] bg-[rgba(255,248,236,0.03)] text-slate-300 hover:bg-white/[0.05]'
              }`}
            >
              {option.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function AccountSettingsPage({ currentUser }: { currentUser: AuthenticatedUser }) {
  const appearance = useLoreLoomStore((state) => state.appearance);
  const updateWritingAppearance = useLoreLoomStore((state) => state.updateWritingAppearance);
  const [form, setForm] = useState<PasswordChangeFormState>(initialFormState);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const interfacePreviewFont = getInterfaceFontOption(appearance.interfaceFontId);
  const writingPreviewFont = getWritingFontOption(appearance.writingFontId);
  const writingPreviewStyle = getAppearanceCssVariables(appearance) as CSSProperties;
  const interfacePreviewStyle = { fontFamily: interfacePreviewFont.family } as CSSProperties;

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    setMessage(null);

    try {
      await changePassword({
        currentPassword: form.currentPassword,
        newPassword: form.newPassword,
        passwordConfirmation: form.passwordConfirmation,
      });

      setForm(initialFormState);
      setMessage('Your password has been updated. Other active sessions were signed out.');
    } catch (caughtError) {
      setError(formatChangePasswordError(caughtError));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <section className="app-panel rounded-3xl p-6">
        <div className="space-y-2">
          <p className="app-accent-label text-sm font-medium uppercase tracking-[0.18em]">Account</p>
          <h1 className="text-3xl font-semibold tracking-tight text-white">Signed-in account</h1>
          <p className="max-w-3xl text-sm leading-7 text-slate-300">
            Manage the local password for this account. Changing it signs out other active sessions while keeping this
            one signed in.
          </p>
        </div>
      </section>

      <section className="app-panel rounded-3xl p-6">
        <div className="space-y-2">
          <h2 className="text-xl font-semibold text-white">Current user</h2>
          <p className="text-sm leading-6 text-slate-300">
            {formatUserLabel(currentUser)} <span className="text-slate-500">(@{currentUser.username})</span>
          </p>
          <p className="text-xs uppercase tracking-[0.16em] text-slate-500">{currentUser.role}</p>
        </div>
      </section>

      <section className="app-panel rounded-3xl p-6">
        <div className="mb-5 space-y-2">
          <h2 className="text-xl font-semibold text-white">Writing appearance</h2>
          <p className="max-w-3xl text-sm leading-6 text-slate-300">
            These preferences only change how LoreLoom looks on this device. Interface font changes the controls,
            labels, and general app text. Writing font changes the manuscript, editor, Focus Mode, and preview text.
            Size, spacing, and width only affect writing comfort.
          </p>
        </div>

        <div className="grid gap-6 xl:grid-cols-[0.92fr_1.08fr]">
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-white" htmlFor="interface-font">
                Interface font
              </label>
              <p className="text-sm leading-6 text-slate-400">
                Changes the typography used for app controls, labels, navigation, forms, dashboard cards, and other
                interface text.
              </p>
              <select
                id="interface-font"
                value={appearance.interfaceFontId}
                onChange={(event) =>
                  updateWritingAppearance({ interfaceFontId: event.target.value as InterfaceFontId })
                }
                className="app-select app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
              >
                {INTERFACE_FONT_OPTIONS.map((option) => (
                  <option key={option.id} value={option.id}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-white" htmlFor="writing-font">
                Writing font
              </label>
              <p className="text-sm leading-6 text-slate-400">
                Changes the manuscript, editor, Focus Mode, and preview reading text.
              </p>
              <select
                id="writing-font"
                value={appearance.writingFontId}
                onChange={(event) =>
                  updateWritingAppearance({ writingFontId: event.target.value as WritingFontId })
                }
                className="app-select app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
              >
                {(['Sans', 'Serif', 'Monospace'] as const).map((category) => (
                  <optgroup key={category} label={category}>
                    {WRITING_FONT_OPTIONS.filter((option) => option.category === category).map((option) => (
                      <option key={option.id} value={option.id}>
                        {option.label}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>

            <ChoiceRow
              label="Font size"
              helper="Scale the reading and writing text size without changing your manuscript data."
              options={WRITING_FONT_SIZE_OPTIONS}
              value={appearance.fontSize}
              onChange={(fontSize) => updateWritingAppearance({ fontSize: fontSize as WritingFontSize })}
            />

            <ChoiceRow
              label="Line spacing"
              helper="Increase or tighten vertical rhythm for a calmer or denser writing flow."
              options={WRITING_LINE_SPACING_OPTIONS}
              value={appearance.lineSpacing}
              onChange={(lineSpacing) =>
                updateWritingAppearance({ lineSpacing: lineSpacing as WritingLineSpacing })
              }
            />

            <ChoiceRow
              label="Editor width"
              helper="Control how wide the writing column feels in the editor, Focus Mode, and previews."
              options={WRITING_EDITOR_WIDTH_OPTIONS}
              value={appearance.editorWidth}
              onChange={(editorWidth) =>
                updateWritingAppearance({ editorWidth: editorWidth as WritingEditorWidth })
              }
            />
          </div>

          <div className="space-y-4">
            <div className="app-panel-inset rounded-3xl p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="app-accent-label text-[11px] uppercase tracking-[0.18em]">Interface preview</p>
                  <h3 className="mt-2 text-lg font-medium text-white">{interfacePreviewFont.label}</h3>
                </div>
                <p className="text-sm text-slate-500">General UI text</p>
              </div>

              <div className="mt-5 space-y-3 rounded-2xl border border-[color:var(--app-border)] bg-[rgba(255,248,236,0.03)] p-4 text-sm leading-6 text-slate-200" style={interfacePreviewStyle}>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] uppercase tracking-[0.18em] text-slate-400">LoreLoom</span>
                  <span className="rounded-full border border-[color:var(--app-border)] px-2 py-1 text-xs text-slate-300">
                    Dashboard
                  </span>
                  <span className="rounded-full border border-[color:var(--app-border)] px-2 py-1 text-xs text-slate-300">
                    Account
                  </span>
                </div>
                <p className="text-slate-300">
                  Buttons, labels, and navigation use this font so the interface feels comfortable and easy to read.
                </p>
              </div>
            </div>

            <div className="app-panel-inset rounded-3xl p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="app-accent-label text-[11px] uppercase tracking-[0.18em]">Live preview</p>
                  <h3 className="mt-2 text-lg font-medium text-white">{writingPreviewFont.label}</h3>
                </div>
                <p className="text-sm text-slate-500">{writingPreviewFont.category}</p>
              </div>

              <div className="writing-preview-sample mt-5" style={writingPreviewStyle}>
                <h4 className="text-2xl font-semibold text-white">A quieter writing surface</h4>
                <div className="writing-column writing-reading-surface writing-body mt-4 space-y-4">
                  <p className="text-slate-200">
                    The harbor was still awake when the last lamp in the tower went out, and the page felt wider,
                    calmer, and easier to trust for another hour of work.
                  </p>
                  <p className="text-slate-300">
                    These controls are meant for comfort, readability, and sustained focus, especially during longer
                    writing sessions.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="app-panel rounded-3xl p-6">
        <div className="mb-5 space-y-2">
          <h2 className="text-xl font-semibold text-white">Change password</h2>
          <p className="text-sm leading-6 text-slate-300">
            Change the local password for this signed-in account. The current session stays active after a successful
            change.
          </p>
        </div>

        <form className="space-y-4 max-w-xl" onSubmit={handleSubmit}>
          <PasswordField
            label="Current password"
            value={form.currentPassword}
            onChange={(currentPassword) => setForm((current) => ({ ...current, currentPassword }))}
            placeholder="Current password"
            autoComplete="current-password"
          />
          <PasswordField
            label="New password"
            value={form.newPassword}
            onChange={(newPassword) => setForm((current) => ({ ...current, newPassword }))}
            placeholder="At least 6 characters"
            autoComplete="new-password"
            helperText="Local account passwords must be at least 6 characters."
          />
          <PasswordField
            label="Confirm new password"
            value={form.passwordConfirmation}
            onChange={(passwordConfirmation) =>
              setForm((current) => ({ ...current, passwordConfirmation }))
            }
            placeholder="Repeat new password"
            autoComplete="new-password"
          />

          {message ? (
            <div className="rounded-2xl border border-emerald-400/30 bg-emerald-500/10 px-4 py-4 text-sm text-emerald-100">
              {message}
            </div>
          ) : null}

          {error ? (
            <div className="whitespace-pre-line rounded-2xl border border-rose-400/30 bg-rose-500/10 px-4 py-4 text-sm text-rose-100">
              {error}
            </div>
          ) : null}

          <button
            type="submit"
            disabled={submitting}
            className="app-button-primary app-focus-ring inline-flex rounded-xl px-4 py-2 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-70"
          >
            {submitting ? 'Updating password…' : 'Change password'}
          </button>
        </form>
      </section>
    </div>
  );
}
