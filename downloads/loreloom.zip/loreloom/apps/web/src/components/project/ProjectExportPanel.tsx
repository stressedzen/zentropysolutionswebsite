import { Link } from 'react-router-dom';
import { formatRelativeBackupDate, isBackupReminderStale } from '../../lib/writing-stats';

type ProjectExportPanelProps = {
  projectId: string;
  hasCodexEntries: boolean;
  exportError: string;
  lastBackupExportAt: string | null;
  onExportBackup: () => void;
  onExportStory: () => void;
  onExportWiki: () => void;
};

export default function ProjectExportPanel({
  projectId,
  hasCodexEntries,
  exportError,
  lastBackupExportAt,
  onExportBackup,
  onExportStory,
  onExportWiki,
}: ProjectExportPanelProps) {
  const backupIsStale = isBackupReminderStale(lastBackupExportAt);

  return (
    <section className="app-panel rounded-3xl p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="max-w-2xl">
          <h2 className="text-lg font-medium text-white">Backup and export</h2>
          <p className="mt-2 text-sm leading-6 text-slate-300">
            Export a restoreable backup, a manuscript-ready plain text copy, or a simple reading preview of this project.
          </p>
          <p
            className={`mt-3 text-sm leading-6 ${
              backupIsStale ? 'text-[color:var(--app-gold-soft)]' : 'text-slate-400'
            }`}
          >
            Last manual backup export: {formatRelativeBackupDate(lastBackupExportAt)}.
          </p>
          {backupIsStale ? (
            <p className="mt-1 text-sm leading-6 text-slate-400">
              Manual backups are an extra ownership copy alongside local autosave and sync.
            </p>
          ) : null}
        </div>
        <div className="flex flex-col gap-2 sm:items-end">
          <Link
            to={`/projects/${projectId}/preview`}
            className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
          >
            Book Preview
          </Link>
          <button
            type="button"
            onClick={onExportBackup}
            className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
          >
            Export project backup
          </button>
          <button
            type="button"
            onClick={onExportStory}
            className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
          >
            Export story TXT
          </button>
          {hasCodexEntries ? (
            <button
              type="button"
              onClick={onExportWiki}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
            >
              Export Wiki
            </button>
          ) : null}
        </div>
      </div>
      {exportError ? (
        <p className="mt-4 text-sm leading-6 text-rose-200" role="alert">
          {exportError}
        </p>
      ) : (
        <p className="mt-4 text-sm leading-6 text-slate-400">
          Backup exports include project metadata, structure nodes, text blocks, and codex entries for future
          compatibility.
        </p>
      )}
    </section>
  );
}
