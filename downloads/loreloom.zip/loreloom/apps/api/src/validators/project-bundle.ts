import { z } from 'zod';

const structureNodeTypeSchema = z.enum([
  'book',
  'part',
  'act',
  'chapter',
  'sequence',
  'section',
  'custom',
]);

const codexEntryTypeSchema = z.enum([
  'character',
  'location',
  'object',
  'faction',
  'lore',
  'timeline',
  'custom',
]);

const codexNodeTypeSchema = z.enum([
  'codex',
  'group',
  'characters',
  'places',
  'factions',
  'objects',
  'timeline',
  'research',
  'custom',
]);

const isoStringSchema = z.string().min(1);
const idSchema = z.string().min(1);

export const projectParamsSchema = z.object({
  id: idSchema,
});

export const projectSchema = z.object({
  id: idSchema,
  name: z.string().min(1),
  createdAt: isoStringSchema,
  updatedAt: isoStringSchema,
});

export const structureNodeSchema = z.object({
  id: idSchema,
  projectId: idSchema,
  parentId: idSchema.nullable(),
  type: structureNodeTypeSchema,
  customTypeLabel: z.string().min(1).nullable().optional().transform((value) => value ?? null),
  title: z.string().min(1),
  orderIndex: z.number().int(),
  createdAt: isoStringSchema,
  updatedAt: isoStringSchema,
});

export const sceneSchema = z.object({
  id: idSchema,
  projectId: idSchema,
  structureNodeId: idSchema,
  title: z.string().min(1),
  content: z.string(),
  createdAt: isoStringSchema,
  updatedAt: isoStringSchema,
});

export const codexNodeSchema = z.object({
  id: idSchema,
  projectId: idSchema,
  parentId: idSchema.nullable(),
  type: codexNodeTypeSchema,
  customTypeLabel: z.string().min(1).nullable().optional().transform((value) => value ?? null),
  title: z.string().min(1),
  tags: z.array(z.string()),
  orderIndex: z.number().int(),
  createdAt: isoStringSchema,
  updatedAt: isoStringSchema,
});

export const codexEntrySchema = z.object({
  id: idSchema,
  projectId: idSchema,
  codexNodeId: idSchema.nullable().optional().transform((value) => value ?? null),
  title: z.string().min(1),
  type: codexEntryTypeSchema,
  content: z.string(),
  tags: z.array(z.string()),
  createdAt: isoStringSchema,
  updatedAt: isoStringSchema,
});

export const revisionSnapshotSchema = z.object({
  id: idSchema,
  sceneId: idSchema,
  projectId: idSchema,
  title: z.string(),
  content: z.string(),
  createdAt: isoStringSchema,
});

export const projectBundleSchema = z
  .object({
    project: projectSchema,
    structureNodes: z.array(structureNodeSchema),
    scenes: z.array(sceneSchema),
    codexNodes: z.array(codexNodeSchema).default([]),
    codexEntries: z.array(codexEntrySchema),
    revisionSnapshots: z.array(revisionSnapshotSchema),
  })
  .superRefine((bundle, context) => {
    const projectId = bundle.project.id;
    const structureNodeIds = new Set(bundle.structureNodes.map((node) => node.id));
    const codexNodeIds = new Set(bundle.codexNodes.map((node) => node.id));
    const sceneIds = new Set(bundle.scenes.map((scene) => scene.id));

    for (const node of bundle.structureNodes) {
      if (node.projectId !== projectId) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Structure node ${node.id} must belong to project ${projectId}.`,
        });
      }

      if (node.parentId && !structureNodeIds.has(node.parentId)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Structure node ${node.id} references missing parent ${node.parentId}.`,
        });
      }
    }

    for (const scene of bundle.scenes) {
      if (scene.projectId !== projectId) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Scene ${scene.id} must belong to project ${projectId}.`,
        });
      }

      if (!structureNodeIds.has(scene.structureNodeId)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Scene ${scene.id} references missing structure node ${scene.structureNodeId}.`,
        });
      }
    }

    for (const node of bundle.codexNodes) {
      if (node.projectId !== projectId) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Codex node ${node.id} must belong to project ${projectId}.`,
        });
      }

      if (node.parentId && !codexNodeIds.has(node.parentId)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Codex node ${node.id} references missing parent ${node.parentId}.`,
        });
      }
    }

    for (const codexEntry of bundle.codexEntries) {
      if (codexEntry.projectId !== projectId) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Codex entry ${codexEntry.id} must belong to project ${projectId}.`,
        });
      }

      if (codexEntry.codexNodeId && !codexNodeIds.has(codexEntry.codexNodeId)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Codex entry ${codexEntry.id} references missing codex node ${codexEntry.codexNodeId}.`,
        });
      }
    }

    for (const snapshot of bundle.revisionSnapshots) {
      if (snapshot.projectId !== projectId) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Revision snapshot ${snapshot.id} must belong to project ${projectId}.`,
        });
      }

      if (!sceneIds.has(snapshot.sceneId)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Revision snapshot ${snapshot.id} references missing scene ${snapshot.sceneId}.`,
        });
      }
    }
  });

export const putProjectBundleBodySchema = z.object({
  baseRevision: z.number().int().nonnegative(),
  bundle: projectBundleSchema,
});

export type ProjectParams = z.infer<typeof projectParamsSchema>;
export type Project = z.infer<typeof projectSchema>;
export type StructureNode = z.infer<typeof structureNodeSchema>;
export type Scene = z.infer<typeof sceneSchema>;
export type CodexNode = z.infer<typeof codexNodeSchema>;
export type CodexEntry = z.infer<typeof codexEntrySchema>;
export type RevisionSnapshot = z.infer<typeof revisionSnapshotSchema>;
export type ProjectBundle = z.infer<typeof projectBundleSchema>;
export type PutProjectBundleBody = z.infer<typeof putProjectBundleBodySchema>;

export type ProjectSummary = Project & {
  serverRevision: number;
};

export type ProjectBundleWithRevision = ProjectBundle & {
  serverRevision: number;
};
