import logoUrl from '../assets/loreloom-logo.png';

type LoreLoomLogoProps = {
  className?: string;
};

export default function LoreLoomLogo({ className }: LoreLoomLogoProps) {
  return (
    <img
      src={logoUrl}
      alt="LoreLoom logo"
      className={`w-auto object-contain ${className ?? 'h-8'}`}
      draggable={false}
      loading="eager"
      decoding="async"
    />
  );
}
