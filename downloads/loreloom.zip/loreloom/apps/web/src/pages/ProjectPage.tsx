import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import CommandPalette, { type CommandPaletteItem } from '../components/CommandPalette';
import SyncStatusBadge from '../components/SyncStatusBadge';
import CodexPanel from '../components/project/CodexPanel';
import ProjectExportPanel from '../components/project/ProjectExportPanel';
import StructureTreeSection from '../components/project/StructureTreeSection';
import { exportProjectBackupFile, exportProjectStoryFile } from '../lib/backup';
import {
  buildCodexNodeTree,
  findDefaultCodexNode,
  flattenCodexNodeTree,
  getCodexNodeTypeLabel,
} from '../lib/codex';
import { fuzzyScore } from '../lib/fuzzy';
import {
  buildStructureNodeTree,
  flattenStructureNodeTree,
  getStructureNodeTypeLabel,
} from '../lib/structure';
import { countProjectWords } from '../lib/writing-stats';
import { useLoreLoomStore } from '../store/useLoreLoomStore';
import type { CodexEntryType, CodexNodeType, Scene, StructureNodeType } from '../lib/types';

function toTagList(value: string) {
  return Array.from(
    new Set(
      value
        .split(',')
        .map((tag) => tag.trim())
        .filter(Boolean),
    ),
  );
}

function isMacPlatform() {
  if (typeof window === 'undefined') {
    return false;
  }

  return /Mac|iPhone|iPad|iPod/.test(window.navigator.platform);
}

export default function ProjectPage() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const codexSectionRef = useRef<HTMLElement | null>(null);
  const projects = useLoreLoomStore((state) => state.projects);
  const structureNodes = useLoreLoomStore((state) => state.structureNodes);
  const scenes = useLoreLoomStore((state) => state.scenes);
  const codexNodes = useLoreLoomStore((state) => state.codexNodes);
  const codexEntries = useLoreLoomStore((state) => state.codexEntries);
  const revisionSnapshots = useLoreLoomStore((state) => state.revisionSnapshots);
  const createScene = useLoreLoomStore((state) => state.createScene);
  const createStructureNode = useLoreLoomStore((state) => state.createStructureNode);
  const updateProject = useLoreLoomStore((state) => state.updateProject);
  const updateScene = useLoreLoomStore((state) => state.updateScene);
  const updateStructureNode = useLoreLoomStore((state) => state.updateStructureNode);
  const deleteProject = useLoreLoomStore((state) => state.deleteProject);
  const deleteStructureNode = useLoreLoomStore((state) => state.deleteStructureNode);
  const deleteScene = useLoreLoomStore((state) => state.deleteScene);
  const createCodexEntry = useLoreLoomStore((state) => state.createCodexEntry);
  const createCodexNode = useLoreLoomStore((state) => state.createCodexNode);
  const updateCodexEntry = useLoreLoomStore((state) => state.updateCodexEntry);
  const updateCodexNode = useLoreLoomStore((state) => state.updateCodexNode);
  const deleteCodexEntry = useLoreLoomStore((state) => state.deleteCodexEntry);
  const deleteCodexNode = useLoreLoomStore((state) => state.deleteCodexNode);
  const requestProjectSync = useLoreLoomStore((state) => state.requestProjectSync);
  const recordProjectBackupExport = useLoreLoomStore((state) => state.recordProjectBackupExport);
  const lastBackupExportAt = useLoreLoomStore((state) =>
    projectId ? state.backups.projectBackupExports[projectId] ?? null : null,
  );

  const [activeSceneCreateNodeId, setActiveSceneCreateNodeId] = useState<string | null>(null);
  const [draftSceneTitle, setDraftSceneTitle] = useState('');
  const [renamingSceneId, setRenamingSceneId] = useState<string | null>(null);
  const [renamingSceneTitle, setRenamingSceneTitle] = useState('');
  const [selectedStructureNodeId, setSelectedStructureNodeId] = useState<string | null>(null);
  const [collapsedNodeIds, setCollapsedNodeIds] = useState<Set<string>>(() => new Set());
  const [activeStructureEditNodeId, setActiveStructureEditNodeId] = useState<string | null>(null);
  const [structureEditTitle, setStructureEditTitle] = useState('');
  const [structureEditType, setStructureEditType] = useState<StructureNodeType>('chapter');
  const [structureEditCustomTypeLabel, setStructureEditCustomTypeLabel] = useState('');
  const [activeChildStructureParentId, setActiveChildStructureParentId] = useState<string | null>(null);
  const [childStructureTitle, setChildStructureTitle] = useState('');
  const [childStructureType, setChildStructureType] = useState<StructureNodeType>('chapter');
  const [childStructureCustomTypeLabel, setChildStructureCustomTypeLabel] = useState('');
  const [isTopLevelStructureFormOpen, setIsTopLevelStructureFormOpen] = useState(false);
  const [topLevelStructureTitle, setTopLevelStructureTitle] = useState('');
  const [topLevelStructureType, setTopLevelStructureType] = useState<StructureNodeType>('chapter');
  const [topLevelStructureCustomTypeLabel, setTopLevelStructureCustomTypeLabel] = useState('');
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [commandQuery, setCommandQuery] = useState('');
  const [selectedCodexNodeId, setSelectedCodexNodeId] = useState<string | null>(null);
  const [selectedCodexId, setSelectedCodexId] = useState<string | null>(null);
  const [codexEditorMode, setCodexEditorMode] = useState<'entry' | 'node'>('entry');
  const [editingCodexNodeId, setEditingCodexNodeId] = useState<string | null>(null);
  const [codexNodeParentId, setCodexNodeParentId] = useState<string | null>(null);
  const [codexNodeTitle, setCodexNodeTitle] = useState('');
  const [codexNodeType, setCodexNodeType] = useState<CodexNodeType>('group');
  const [codexNodeCustomTypeLabel, setCodexNodeCustomTypeLabel] = useState('');
  const [codexNodeTags, setCodexNodeTags] = useState('');
  const [codexTitle, setCodexTitle] = useState('');
  const [codexType, setCodexType] = useState<CodexEntryType>('character');
  const [codexContent, setCodexContent] = useState('');
  const [codexTags, setCodexTags] = useState('');
  const [codexEntryNodeId, setCodexEntryNodeId] = useState<string | null>(null);
  const [exportError, setExportError] = useState('');

  const project = useMemo(
    () => (projectId ? projects.find((entry) => entry.id === projectId) : undefined),
    [projectId, projects],
  );
  const projectScenes = useMemo(() => {
    if (!projectId) {
      return [];
    }

    return scenes
      .filter((scene) => scene.projectId === projectId)
      .sort((left, right) => {
        const updated = right.updatedAt.localeCompare(left.updatedAt);
        if (updated !== 0) {
          return updated;
        }

        return right.createdAt.localeCompare(left.createdAt);
      });
  }, [projectId, scenes]);
  const projectStructureNodes = useMemo(() => {
    if (!projectId) {
      return [];
    }

    return structureNodes
      .filter((node) => node.projectId === projectId)
      .sort((left, right) => {
        if (left.parentId !== right.parentId) {
          if (left.parentId === null) {
            return -1;
          }
          if (right.parentId === null) {
            return 1;
          }

          const parentCompare = left.parentId.localeCompare(right.parentId);
          if (parentCompare !== 0) {
            return parentCompare;
          }
        }

        if (left.orderIndex !== right.orderIndex) {
          return left.orderIndex - right.orderIndex;
        }

        const createdCompare = left.createdAt.localeCompare(right.createdAt);
        if (createdCompare !== 0) {
          return createdCompare;
        }

        return left.id.localeCompare(right.id);
      });
  }, [projectId, structureNodes]);
  const projectCodexEntries = useMemo(() => {
    if (!projectId || !project) {
      return [];
    }

    return codexEntries
      .filter((entry) => entry.projectId === project.id)
      .sort((left, right) => {
        const updated = right.updatedAt.localeCompare(left.updatedAt);
        if (updated !== 0) {
          return updated;
        }

        return right.createdAt.localeCompare(left.createdAt);
      });
  }, [codexEntries, project, projectId]);
  const projectCodexNodes = useMemo(() => {
    if (!projectId) {
      return [];
    }

    return codexNodes
      .filter((node) => node.projectId === projectId)
      .sort((left, right) => {
        if (left.parentId !== right.parentId) {
          if (left.parentId === null) {
            return -1;
          }
          if (right.parentId === null) {
            return 1;
          }

          const parentCompare = left.parentId.localeCompare(right.parentId);
          if (parentCompare !== 0) {
            return parentCompare;
          }
        }

        if (left.orderIndex !== right.orderIndex) {
          return left.orderIndex - right.orderIndex;
        }

        const createdCompare = left.createdAt.localeCompare(right.createdAt);
        if (createdCompare !== 0) {
          return createdCompare;
        }

        return left.id.localeCompare(right.id);
      });
  }, [codexNodes, projectId]);
  const projectStructureTree = useMemo(
    () => buildStructureNodeTree(projectStructureNodes),
    [projectStructureNodes],
  );
  const projectCodexTree = useMemo(() => buildCodexNodeTree(projectCodexNodes), [projectCodexNodes]);
  const structureNodeTitlesById = useMemo(
    () => new Map(projectStructureNodes.map((node) => [node.id, node.title])),
    [projectStructureNodes],
  );
  const structureNodeParentsById = useMemo(
    () => new Map(projectStructureNodes.map((node) => [node.id, node.parentId])),
    [projectStructureNodes],
  );
  const flatStructureNodeOptions = useMemo(
    () => flattenStructureNodeTree(projectStructureTree),
    [projectStructureTree],
  );
  const flatCodexNodeOptions = useMemo(() => flattenCodexNodeTree(projectCodexTree), [projectCodexTree]);
  const projectWordCount = useMemo(() => countProjectWords(projectScenes), [projectScenes]);
  const projectSceneCount = projectScenes.length;
  const codexEntryCount = projectCodexEntries.length;
  const defaultCodexNode = useMemo(
    () => (projectId ? findDefaultCodexNode(projectCodexNodes, projectId) : null),
    [projectCodexNodes, projectId],
  );
  const codexNodesById = useMemo(
    () => new Map(projectCodexNodes.map((node) => [node.id, node])),
    [projectCodexNodes],
  );
  const codexNodeChildrenCountById = useMemo(() => {
    const counts = new Map<string, number>();

    for (const node of projectCodexNodes) {
      if (!node.parentId) {
        continue;
      }

      counts.set(node.parentId, (counts.get(node.parentId) ?? 0) + 1);
    }

    return counts;
  }, [projectCodexNodes]);
  const codexEntryCountByNodeId = useMemo(() => {
    const counts = new Map<string, number>();

    for (const entry of projectCodexEntries) {
      counts.set(entry.codexNodeId, (counts.get(entry.codexNodeId) ?? 0) + 1);
    }

    return counts;
  }, [projectCodexEntries]);
  const selectedCodexEntry = useMemo(
    () => projectCodexEntries.find((entry) => entry.id === selectedCodexId) ?? null,
    [projectCodexEntries, selectedCodexId],
  );
  const editingCodexNode = useMemo(
    () => (editingCodexNodeId ? projectCodexNodes.find((node) => node.id === editingCodexNodeId) ?? null : null),
    [editingCodexNodeId, projectCodexNodes],
  );
  const deleteableCodexNodeIds = useMemo(
    () =>
      new Set(
        projectCodexNodes
          .filter((node) => {
            if (defaultCodexNode?.id === node.id) {
              return false;
            }

            const hasChildren = (codexNodeChildrenCountById.get(node.id) ?? 0) > 0;
            const hasEntries = (codexEntryCountByNodeId.get(node.id) ?? 0) > 0;
            return !hasChildren && !hasEntries;
          })
          .map((node) => node.id),
      ),
    [codexEntryCountByNodeId, codexNodeChildrenCountById, defaultCodexNode, projectCodexNodes],
  );
  const deleteableStructureNodeIds = useMemo(
    () =>
      new Set(
        projectStructureNodes
          .filter((node) => {
            const hasScenes = projectScenes.some((scene) => scene.structureNodeId === node.id);
            const hasChildren = projectStructureNodes.some((candidate) => candidate.parentId === node.id);
            return !hasScenes && !hasChildren;
          })
          .map((node) => node.id),
      ),
    [projectScenes, projectStructureNodes],
  );
  const isEditingCodexEntry = selectedCodexEntry !== null;
  const isEditingCodexNode = editingCodexNode !== null;

  useEffect(() => {
    if (!projectId || typeof window === 'undefined') {
      setCollapsedNodeIds(new Set());
      return;
    }

    try {
      const raw = window.sessionStorage.getItem(`loreloom-collapsed-nodes:${projectId}`);
      if (!raw) {
        setCollapsedNodeIds(new Set());
        return;
      }

      const parsed = JSON.parse(raw) as string[];
      setCollapsedNodeIds(new Set(Array.isArray(parsed) ? parsed : []));
    } catch {
      setCollapsedNodeIds(new Set());
    }
  }, [projectId]);

  useEffect(() => {
    if (!projectId || typeof window === 'undefined') {
      return;
    }

    window.sessionStorage.setItem(
      `loreloom-collapsed-nodes:${projectId}`,
      JSON.stringify(Array.from(collapsedNodeIds)),
    );
  }, [collapsedNodeIds, projectId]);

  useEffect(() => {
    if (!projectStructureNodes.length) {
      setSelectedStructureNodeId(null);
      setCollapsedNodeIds(new Set());
      return;
    }

    if (selectedStructureNodeId && !projectStructureNodes.some((node) => node.id === selectedStructureNodeId)) {
      setSelectedStructureNodeId(null);
    }
  }, [projectStructureNodes, selectedStructureNodeId]);

  useEffect(() => {
    setCollapsedNodeIds((current) => {
      const validNodeIds = new Set(projectStructureNodes.map((node) => node.id));
      const next = new Set(Array.from(current).filter((nodeId) => validNodeIds.has(nodeId)));
      return next.size === current.size ? current : next;
    });
  }, [projectStructureNodes]);

  useEffect(() => {
    if (!activeStructureEditNodeId) {
      setStructureEditTitle('');
      setStructureEditType('chapter');
      setStructureEditCustomTypeLabel('');
      return;
    }

    const node = projectStructureNodes.find((entry) => entry.id === activeStructureEditNodeId);
    if (!node) {
      setActiveStructureEditNodeId(null);
      setStructureEditTitle('');
      setStructureEditType('chapter');
      setStructureEditCustomTypeLabel('');
      return;
    }

    setStructureEditTitle(node.title);
    setStructureEditType(node.type);
    setStructureEditCustomTypeLabel(node.customTypeLabel ?? '');
  }, [activeStructureEditNodeId, projectStructureNodes]);

  useEffect(() => {
    if (!activeChildStructureParentId) {
      return;
    }

    if (!projectStructureNodes.some((node) => node.id === activeChildStructureParentId)) {
      cancelChildStructureCreation();
    }
  }, [activeChildStructureParentId, projectStructureNodes]);

  useEffect(() => {
    if (!activeSceneCreateNodeId) {
      return;
    }

    if (!projectStructureNodes.some((node) => node.id === activeSceneCreateNodeId)) {
      cancelSceneCreationForNode();
    }
  }, [activeSceneCreateNodeId, projectStructureNodes]);

  useEffect(() => {
    if (!renamingSceneId) {
      return;
    }

    if (!projectScenes.some((scene) => scene.id === renamingSceneId)) {
      cancelSceneRename();
    }
  }, [projectScenes, renamingSceneId]);

  useEffect(() => {
    if (!projectCodexNodes.length) {
      setSelectedCodexNodeId(null);
      setSelectedCodexId(null);
      setCodexEntryNodeId(null);
      return;
    }

    if (selectedCodexNodeId && !projectCodexNodes.some((node) => node.id === selectedCodexNodeId)) {
      setSelectedCodexNodeId(defaultCodexNode?.id ?? null);
    }

    if (!selectedCodexNodeId) {
      setSelectedCodexNodeId(defaultCodexNode?.id ?? projectCodexNodes[0]?.id ?? null);
    }
  }, [defaultCodexNode, projectCodexNodes, selectedCodexNodeId]);

  useEffect(() => {
    if (editingCodexNodeId && !projectCodexNodes.some((node) => node.id === editingCodexNodeId)) {
      setEditingCodexNodeId(null);
      setCodexNodeParentId(null);
      setCodexNodeTitle('');
      setCodexNodeType('group');
      setCodexNodeCustomTypeLabel('');
      setCodexNodeTags('');
    }
  }, [editingCodexNodeId, projectCodexNodes]);

  useEffect(() => {
    if (!selectedCodexEntry) {
      if (selectedCodexId !== null) {
        setSelectedCodexId(null);
      }
      setCodexEditorMode('entry');
      setCodexTitle('');
      setCodexType('character');
      setCodexContent('');
      setCodexTags('');
      setCodexEntryNodeId(selectedCodexNodeId ?? defaultCodexNode?.id ?? null);
      return;
    }

    setCodexEditorMode('entry');
    setSelectedCodexNodeId(selectedCodexEntry.codexNodeId);
    setCodexTitle(selectedCodexEntry.title);
    setCodexType(selectedCodexEntry.type);
    setCodexContent(selectedCodexEntry.content);
    setCodexTags(selectedCodexEntry.tags.join(', '));
    setCodexEntryNodeId(selectedCodexEntry.codexNodeId);
  }, [defaultCodexNode, selectedCodexEntry, selectedCodexId, selectedCodexNodeId]);

  useEffect(() => {
    if (!editingCodexNode) {
      return;
    }

    setCodexEditorMode('node');
    setSelectedCodexNodeId(editingCodexNode.id);
    setCodexNodeParentId(editingCodexNode.parentId);
    setCodexNodeTitle(editingCodexNode.title);
    setCodexNodeType(editingCodexNode.type);
    setCodexNodeCustomTypeLabel(editingCodexNode.customTypeLabel ?? '');
    setCodexNodeTags(editingCodexNode.tags.join(', '));
  }, [editingCodexNode]);

  function resetCodexForm(targetNodeId?: string | null) {
    const nextNodeId = targetNodeId ?? selectedCodexNodeId ?? defaultCodexNode?.id ?? null;
    setSelectedCodexId(null);
    if (nextNodeId) {
      setSelectedCodexNodeId(nextNodeId);
    }
    setCodexEditorMode('entry');
    setCodexTitle('');
    setCodexType('character');
    setCodexContent('');
    setCodexTags('');
    setCodexEntryNodeId(nextNodeId);
  }

  function resetCodexNodeForm(parentId = selectedCodexNodeId ?? defaultCodexNode?.id ?? null) {
    setEditingCodexNodeId(null);
    setCodexEditorMode('node');
    setCodexNodeParentId(parentId);
    setCodexNodeTitle('');
    setCodexNodeType('group');
    setCodexNodeCustomTypeLabel('');
    setCodexNodeTags('');
  }

  function cancelCodexNodeEdit() {
    setEditingCodexNodeId(null);
    setCodexNodeParentId(null);
    setCodexNodeTitle('');
    setCodexNodeType('group');
    setCodexNodeCustomTypeLabel('');
    setCodexNodeTags('');
    setCodexEditorMode('entry');
    if (!selectedCodexEntry) {
      resetCodexForm();
    }
  }

  function handleSelectCodexNode(nodeId: string) {
    if (!codexNodesById.has(nodeId)) {
      return;
    }

    setSelectedCodexNodeId(nodeId);
    if (!selectedCodexEntry) {
      setCodexEntryNodeId(nodeId);
    }
  }

  function beginCodexNodeCreation(parentId: string | null) {
    setSelectedCodexId(null);
    setSelectedCodexNodeId(parentId ?? defaultCodexNode?.id ?? null);
    resetCodexNodeForm(parentId);
  }

  function beginCodexNodeEdit(nodeId: string) {
    const node = codexNodesById.get(nodeId);
    if (!node) {
      return;
    }

    setSelectedCodexId(null);
    setEditingCodexNodeId(nodeId);
  }

  function saveCodexNode() {
    if (!projectId) {
      return;
    }

    const tags = toTagList(codexNodeTags);

    if (editingCodexNodeId) {
      updateCodexNode(editingCodexNodeId, {
        title: codexNodeTitle,
        type: codexNodeType,
        customTypeLabel: codexNodeType === 'custom' ? codexNodeCustomTypeLabel : null,
        tags,
      });
      cancelCodexNodeEdit();
      return;
    }

    const created = createCodexNode(projectId, {
      parentId: codexNodeParentId,
      title: codexNodeTitle,
      type: codexNodeType,
      customTypeLabel: codexNodeType === 'custom' ? codexNodeCustomTypeLabel : null,
      tags,
    });

    setSelectedCodexNodeId(created.id);
    setEditingCodexNodeId(null);
    setCodexNodeParentId(null);
    setCodexNodeTitle('');
    setCodexNodeType('group');
    setCodexNodeCustomTypeLabel('');
    setCodexNodeTags('');
    resetCodexForm(created.id);
  }

  function handleDeleteCodexNode(nodeId: string) {
    const node = codexNodesById.get(nodeId);
    if (!node || !deleteableCodexNodeIds.has(nodeId)) {
      return;
    }

    const confirmed = window.confirm(`Delete codex node "${node.title}"? This cannot be undone.`);
    if (!confirmed) {
      return;
    }

    const fallbackNodeId = node.parentId ?? defaultCodexNode?.id ?? null;

    deleteCodexNode(nodeId);
    if (selectedCodexNodeId === nodeId) {
      setSelectedCodexNodeId(fallbackNodeId);
    }
    if (codexEntryNodeId === nodeId) {
      setCodexEntryNodeId(fallbackNodeId);
    }
    if (editingCodexNodeId === nodeId) {
      cancelCodexNodeEdit();
    }
  }

  function cancelStructureEdit() {
    setActiveStructureEditNodeId(null);
    setStructureEditTitle('');
    setStructureEditType('chapter');
    setStructureEditCustomTypeLabel('');
  }

  function clearNodeSelection() {
    setSelectedStructureNodeId(null);
  }

  function closeNodeInlineState() {
    cancelStructureEdit();
    cancelChildStructureCreation();
    cancelSceneCreationForNode();
  }

  function expandNodePath(nodeId: string) {
    setCollapsedNodeIds((current) => {
      const next = new Set(current);
      let currentNodeId: string | null = nodeId;

      while (currentNodeId) {
        next.delete(currentNodeId);
        currentNodeId = structureNodeParentsById.get(currentNodeId) ?? null;
      }

      return next;
    });
  }

  function toggleNodeCollapse(nodeId: string) {
    setCollapsedNodeIds((current) => {
      const next = new Set(current);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  }

  function handleSelectNode(nodeId: string) {
    const nodeExists = projectStructureNodes.some((entry) => entry.id === nodeId);
    if (!nodeExists) {
      clearNodeSelection();
      closeNodeInlineState();
      return;
    }

    if (selectedStructureNodeId === nodeId) {
      clearNodeSelection();
      if (activeStructureEditNodeId === nodeId) {
        cancelStructureEdit();
      }
      if (activeChildStructureParentId === nodeId) {
        cancelChildStructureCreation();
      }
      if (activeSceneCreateNodeId === nodeId) {
        cancelSceneCreationForNode();
      }
      return;
    }

    setSelectedStructureNodeId(nodeId);
    expandNodePath(nodeId);
  }

  function beginStructureEdit(nodeId: string) {
    const node = projectStructureNodes.find((entry) => entry.id === nodeId);
    if (!node) {
      return;
    }

    cancelChildStructureCreation();
    cancelSceneCreationForNode();
    setIsTopLevelStructureFormOpen(false);
    setSelectedStructureNodeId(nodeId);
    setActiveStructureEditNodeId(nodeId);
    setStructureEditTitle(node.title);
    setStructureEditType(node.type);
    setStructureEditCustomTypeLabel(node.customTypeLabel ?? '');
    expandNodePath(nodeId);
  }

  function saveStructureEdit(nodeId: string) {
    updateStructureNode(nodeId, {
      title: structureEditTitle,
      type: structureEditType,
      customTypeLabel: structureEditType === 'custom' ? structureEditCustomTypeLabel : null,
    });
    setSelectedStructureNodeId(nodeId);
    cancelStructureEdit();
  }

  function beginChildStructureCreation(nodeId: string) {
    const node = projectStructureNodes.find((entry) => entry.id === nodeId);
    if (!node) {
      return;
    }

    setSelectedStructureNodeId(nodeId);
    cancelStructureEdit();
    cancelSceneCreationForNode();
    setIsTopLevelStructureFormOpen(false);
    setActiveChildStructureParentId(node.id);
    setChildStructureTitle('');
    setChildStructureType('chapter');
    setChildStructureCustomTypeLabel('');
    expandNodePath(nodeId);
  }

  function cancelChildStructureCreation() {
    setActiveChildStructureParentId(null);
    setChildStructureTitle('');
    setChildStructureType('chapter');
    setChildStructureCustomTypeLabel('');
  }

  function createChildStructureNode(parentId: string) {
    if (!projectId) {
      return;
    }

    const created = createStructureNode(projectId, {
      title: childStructureTitle,
      type: childStructureType,
      customTypeLabel: childStructureType === 'custom' ? childStructureCustomTypeLabel : null,
      parentId,
    });

    setSelectedStructureNodeId(created.id);
    expandNodePath(created.id);
    cancelChildStructureCreation();
  }

  function cancelTopLevelStructureCreation() {
    setIsTopLevelStructureFormOpen(false);
    setTopLevelStructureTitle('');
    setTopLevelStructureType('chapter');
    setTopLevelStructureCustomTypeLabel('');
  }

  function createTopLevelStructureNode() {
    if (!projectId || !project) {
      return;
    }

    const created = createStructureNode(project.id, {
      title: topLevelStructureTitle,
      type: topLevelStructureType,
      customTypeLabel: topLevelStructureType === 'custom' ? topLevelStructureCustomTypeLabel : null,
      parentId: null,
    });

    setSelectedStructureNodeId(created.id);
    expandNodePath(created.id);
    cancelTopLevelStructureCreation();
  }

  function beginSceneCreationForNode(nodeId: string) {
    const node = projectStructureNodes.find((entry) => entry.id === nodeId);
    if (!node) {
      return;
    }

    cancelStructureEdit();
    cancelChildStructureCreation();
    setIsTopLevelStructureFormOpen(false);
    setActiveSceneCreateNodeId(nodeId);
    setDraftSceneTitle('');
    setSelectedStructureNodeId(node.id);
    expandNodePath(nodeId);
  }

  function cancelSceneCreationForNode() {
    setActiveSceneCreateNodeId(null);
    setDraftSceneTitle('');
  }

  function createSceneInNode(nodeId: string) {
    if (!projectId) {
      return;
    }

    createScene(projectId, draftSceneTitle, nodeId);
    setActiveSceneCreateNodeId(null);
    setDraftSceneTitle('');
    expandNodePath(nodeId);
  }

  function beginSceneRename(scene: Scene) {
    cancelStructureEdit();
    cancelChildStructureCreation();
    cancelSceneCreationForNode();
    setRenamingSceneId(scene.id);
    setRenamingSceneTitle(scene.title);
  }

  function cancelSceneRename() {
    setRenamingSceneId(null);
    setRenamingSceneTitle('');
  }

  function saveSceneRename(sceneId: string) {
    updateScene(sceneId, { title: renamingSceneTitle });
    cancelSceneRename();
  }

  function handleDeleteNode(nodeId: string) {
    const node = projectStructureNodes.find((entry) => entry.id === nodeId);
    if (!node) {
      return;
    }

    const confirmed = window.confirm(`Delete "${node.title}"? This cannot be undone.`);
    if (!confirmed) {
      return;
    }

    deleteStructureNode(nodeId);
    if (selectedStructureNodeId === nodeId) {
      setSelectedStructureNodeId(null);
    }
    if (activeStructureEditNodeId === nodeId) {
      cancelStructureEdit();
    }
    if (activeChildStructureParentId === nodeId) {
      cancelChildStructureCreation();
    }
    if (activeSceneCreateNodeId === nodeId) {
      cancelSceneCreationForNode();
    }
  }

  function handleDeleteScene(scene: Scene) {
    const confirmed = window.confirm(`Delete text block "${scene.title}"? This cannot be undone.`);
    if (!confirmed) {
      return;
    }

    deleteScene(scene.id);
    requestProjectSync(scene.projectId);
    if (renamingSceneId === scene.id) {
      cancelSceneRename();
    }
  }

  function closeCommandPalette() {
    setIsCommandPaletteOpen(false);
    setCommandQuery('');
  }

  // The command palette stays page-owned because it coordinates navigation,
  // inline tree state, export actions, and codex focus in one place.
  const commandPaletteItems = useMemo(() => {
    if (!project) {
      return [];
    }

    const items: Array<CommandPaletteItem & { keywords: string }> = [
      {
        id: 'open-preview',
        section: 'Navigate',
        title: 'Open book preview',
        subtitle: 'Read the project without editing controls.',
        keywords: 'preview read book manuscript',
        onSelect: () => {
          closeCommandPalette();
          navigate(`/projects/${project.id}/preview`);
        },
      },
      {
        id: 'export-story',
        section: 'Export',
        title: 'Export story TXT',
        subtitle: 'Create a plain text manuscript export.',
        keywords: 'export txt manuscript story',
        onSelect: () => {
          exportProjectStoryFile(project, projectStructureNodes, projectScenes);
          closeCommandPalette();
        },
      },
      {
        id: 'create-top-level-node',
        section: 'Create',
        title: 'Create top-level structure node',
        subtitle: 'Open the inline form at the top of the structure outline.',
        keywords: 'create node structure top level chapter section custom',
        onSelect: () => {
          closeCommandPalette();
          cancelStructureEdit();
          cancelChildStructureCreation();
          cancelSceneCreationForNode();
          setIsTopLevelStructureFormOpen(true);
        },
      },
    ];

    for (const node of projectStructureNodes) {
      items.push(
        {
          id: `jump-node-${node.id}`,
          section: 'Navigate',
          title: `Jump to node: ${node.title}`,
          subtitle: getStructureNodeTypeLabel(node),
          keywords: `${node.title} ${node.type} ${node.customTypeLabel ?? ''} structure node jump`,
          onSelect: () => {
            closeCommandPalette();
            handleSelectNode(node.id);
            expandNodePath(node.id);
          },
        },
        {
          id: `create-text-block-${node.id}`,
          section: 'Create',
          title: `Create text block in ${node.title}`,
          subtitle: `Open an inline text block form inside ${node.title}.`,
          keywords: `${node.title} create text block write`,
          onSelect: () => {
            closeCommandPalette();
            beginSceneCreationForNode(node.id);
          },
        },
        {
          id: `create-child-node-${node.id}`,
          section: 'Create',
          title: `Create child node under ${node.title}`,
          subtitle: `Open an inline child node form beneath ${node.title}.`,
          keywords: `${node.title} child node create nested`,
          onSelect: () => {
            closeCommandPalette();
            beginChildStructureCreation(node.id);
          },
        },
      );
    }

    for (const node of projectCodexNodes) {
      items.push(
        {
          id: `jump-codex-node-${node.id}`,
          section: 'Codex',
          title: `Jump to codex node: ${node.title}`,
          subtitle: getCodexNodeTypeLabel(node),
          keywords: `${node.title} ${node.type} ${node.customTypeLabel ?? ''} codex node tags ${node.tags.join(' ')}`,
          onSelect: () => {
            closeCommandPalette();
            handleSelectCodexNode(node.id);
            codexSectionRef.current?.scrollIntoView({ block: 'start' });
          },
        },
        {
          id: `create-codex-child-node-${node.id}`,
          section: 'Create',
          title: `Create codex child node under ${node.title}`,
          subtitle: `Open a nested codex node form inside ${node.title}.`,
          keywords: `${node.title} create codex child node nested`,
          onSelect: () => {
            closeCommandPalette();
            beginCodexNodeCreation(node.id);
            codexSectionRef.current?.scrollIntoView({ block: 'start' });
          },
        },
      );
    }

    for (const textBlock of projectScenes) {
      items.push({
        id: `jump-text-block-${textBlock.id}`,
        section: 'Navigate',
        title: `Jump to text block: ${textBlock.title}`,
        subtitle: structureNodeTitlesById.get(textBlock.structureNodeId) ?? 'Text block',
        keywords: `${textBlock.title} text block write scene`,
        onSelect: () => {
          closeCommandPalette();
          navigate(`/projects/${project.id}/scenes/${textBlock.id}`);
        },
      });
    }

    for (const entry of projectCodexEntries) {
      items.push({
        id: `jump-codex-${entry.id}`,
        section: 'Codex',
        title: `Jump to codex entry: ${entry.title}`,
        subtitle: entry.type,
        keywords: `${entry.title} codex ${entry.type}`,
        onSelect: () => {
          closeCommandPalette();
          setSelectedCodexId(entry.id);
          setSelectedCodexNodeId(entry.codexNodeId);
          codexSectionRef.current?.scrollIntoView({ block: 'start' });
        },
      });
    }

    const normalizedQuery = commandQuery.trim();
    if (!normalizedQuery) {
      return items.slice(0, 18);
    }

    return items
      .map((item) => ({
        item,
        score: Math.max(fuzzyScore(normalizedQuery, item.title), fuzzyScore(normalizedQuery, item.keywords)),
      }))
      .filter((entry) => entry.score >= 0)
      .sort((left, right) => right.score - left.score || left.item.title.localeCompare(right.item.title))
      .slice(0, 18)
      .map((entry) => entry.item);
  }, [
    codexSectionRef,
    commandQuery,
    navigate,
    project,
    projectCodexEntries,
    projectCodexNodes,
    projectScenes,
    projectStructureNodes,
    structureNodeTitlesById,
  ]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setIsCommandPaletteOpen((current) => {
          const next = !current;
          if (!next) {
            setCommandQuery('');
          }
          return next;
        });
        return;
      }

      if (event.key === 'Escape' && isCommandPaletteOpen) {
        event.preventDefault();
        closeCommandPalette();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCommandPaletteOpen]);

  useEffect(() => {
    if (!projectId) {
      return;
    }

    return () => {
      requestProjectSync(projectId);
    };
  }, [projectId, requestProjectSync]);

  if (!project) {
    return (
      <div className="app-panel rounded-3xl p-8 text-slate-300">
        <h2 className="text-lg font-medium text-white">Project not found</h2>
        <p className="mt-2 text-sm leading-6 text-slate-300">
          This project may have been deleted or the link may be outdated.
        </p>
        <Link to="/" className="app-link mt-4 inline-flex underline underline-offset-4">
          Return to dashboard
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link to="/" className="app-link text-sm underline underline-offset-4">
          Back to dashboard
        </Link>
        <div className="flex flex-wrap items-center gap-2">
          <SyncStatusBadge projectId={project.id} compact />
          <button
            type="button"
            onClick={() => setIsCommandPaletteOpen(true)}
            className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
          >
            Command palette
            <span className="ml-2 text-xs text-slate-400">{isMacPlatform() ? 'Cmd+K' : 'Ctrl+K'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              const confirmed = window.confirm(
                'Delete this project? This will also delete its structure nodes, text blocks, and codex entries.',
              );
              if (!confirmed) {
                return;
              }

              deleteProject(project.id);
              navigate('/');
            }}
            className="inline-flex items-center rounded-xl border border-rose-400/30 bg-rose-400/10 px-3 py-2 text-sm font-medium text-rose-200 transition hover:bg-rose-400/20 focus-visible:ring-2 focus-visible:ring-rose-300 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950"
          >
            Delete project
          </button>
        </div>
      </div>

      <section className="app-panel rounded-3xl p-6">
        <div>
          <p className="text-sm uppercase tracking-[0.18em] text-slate-400">Project</p>
          <label className="mt-4 block text-sm text-slate-300" htmlFor="project-title">
            Project title
          </label>
          <input
            id="project-title"
            className="app-focus-ring mt-2 w-full border-0 bg-transparent text-3xl font-semibold tracking-tight text-white placeholder:text-slate-600"
            value={project.name}
            onChange={(event) => updateProject(project.id, { name: event.target.value })}
            aria-label="Project title"
          />
          <p className="mt-3 text-sm text-slate-400">
            {projectSceneCount} text block{projectSceneCount === 1 ? '' : 's'}
          </p>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">
            Use the structure tree below as the workspace for adding text blocks, shaping hierarchy, and keeping the draft organized where it belongs.
          </p>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-3">
        <div className="app-panel-soft rounded-2xl px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Project words</p>
          <p className="mt-2 text-lg font-medium text-white">{projectWordCount.toLocaleString()}</p>
        </div>
        <div className="app-panel-soft rounded-2xl px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Text Blocks</p>
          <p className="mt-2 text-lg font-medium text-white">{projectSceneCount}</p>
        </div>
        <div className="app-panel-soft rounded-2xl px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Codex entries</p>
          <p className="mt-2 text-lg font-medium text-white">{codexEntryCount}</p>
        </div>
      </section>

      <StructureTreeSection
        projectId={project.id}
        structureNodes={projectStructureTree}
        structureNodeTitlesById={structureNodeTitlesById}
        flatNodeOptions={flatStructureNodeOptions}
        scenes={projectScenes}
        deleteableStructureNodeIds={deleteableStructureNodeIds}
        state={{
          selectedStructureNodeId,
          collapsedNodeIds,
          activeStructureEditNodeId,
          structureEditTitle,
          structureEditType,
          structureEditCustomTypeLabel,
          activeChildStructureParentId,
          childStructureTitle,
          childStructureType,
          childStructureCustomTypeLabel,
          activeSceneCreateNodeId,
          draftSceneTitle,
          renamingSceneId,
          renamingSceneTitle,
          isTopLevelStructureFormOpen,
          topLevelStructureTitle,
          topLevelStructureType,
          topLevelStructureCustomTypeLabel,
        }}
        actions={{
          onSelectNode: handleSelectNode,
          onToggleNodeCollapse: toggleNodeCollapse,
          onBeginEditNode: beginStructureEdit,
          onStructureEditTitleChange: setStructureEditTitle,
          onStructureEditTypeChange: setStructureEditType,
          onStructureEditCustomTypeLabelChange: setStructureEditCustomTypeLabel,
          onSaveNodeEdit: saveStructureEdit,
          onCancelNodeEdit: cancelStructureEdit,
          onCreateChildNodeHere: beginChildStructureCreation,
          onChildNodeTitleChange: setChildStructureTitle,
          onChildNodeTypeChange: setChildStructureType,
          onChildNodeCustomTypeLabelChange: setChildStructureCustomTypeLabel,
          onConfirmCreateChildNode: createChildStructureNode,
          onCancelCreateChildNode: cancelChildStructureCreation,
          onDeleteNode: handleDeleteNode,
          onBeginCreateSceneHere: beginSceneCreationForNode,
          onDraftSceneTitleChange: setDraftSceneTitle,
          onCreateSceneHere: createSceneInNode,
          onCancelCreateSceneHere: cancelSceneCreationForNode,
          onBeginRenameScene: beginSceneRename,
          onRenamingSceneTitleChange: setRenamingSceneTitle,
          onSaveRenamedScene: saveSceneRename,
          onCancelRenameScene: cancelSceneRename,
          onDeleteScene: handleDeleteScene,
          onMoveScene: (sceneId, nextStructureNodeId) =>
            updateScene(sceneId, { structureNodeId: nextStructureNodeId }),
          onToggleTopLevelStructureForm: () => {
            setIsTopLevelStructureFormOpen((current) => !current);
            cancelStructureEdit();
            cancelChildStructureCreation();
            cancelSceneCreationForNode();
          },
          onTopLevelStructureTitleChange: setTopLevelStructureTitle,
          onTopLevelStructureTypeChange: setTopLevelStructureType,
          onTopLevelStructureCustomTypeLabelChange: setTopLevelStructureCustomTypeLabel,
          onCreateTopLevelStructureNode: createTopLevelStructureNode,
          onCancelTopLevelStructureCreation: cancelTopLevelStructureCreation,
        }}
      />

      <CodexPanel
        projectId={project.id}
        sectionRef={codexSectionRef}
        nodes={projectCodexTree}
        flatNodeOptions={flatCodexNodeOptions}
        entries={projectCodexEntries}
        selectedCodexNodeId={selectedCodexNodeId}
        selectedCodexId={selectedCodexId}
        deleteableCodexNodeIds={deleteableCodexNodeIds}
        editorMode={codexEditorMode}
        defaultCodexNodeId={defaultCodexNode?.id ?? null}
        isEditingCodexEntry={isEditingCodexEntry}
        isEditingCodexNode={isEditingCodexNode}
        codexTitle={codexTitle}
        codexType={codexType}
        codexContent={codexContent}
        codexTags={codexTags}
        codexEntryNodeId={codexEntryNodeId}
        codexNodeParentId={codexNodeParentId}
        codexNodeTitle={codexNodeTitle}
        codexNodeType={codexNodeType}
        codexNodeCustomTypeLabel={codexNodeCustomTypeLabel}
        codexNodeTags={codexNodeTags}
        onSelectNode={handleSelectCodexNode}
        onCreateEntry={resetCodexForm}
        onEditNode={beginCodexNodeEdit}
        onCreateRootNode={() => beginCodexNodeCreation(null)}
        onCreateChildNode={beginCodexNodeCreation}
        onDeleteNode={handleDeleteCodexNode}
        onSelectEntry={setSelectedCodexId}
        onDeleteEntry={() => {
          if (!selectedCodexEntry) {
            return;
          }

          const confirmed = window.confirm('Delete this codex entry? This cannot be undone.');
          if (!confirmed) {
            return;
          }

          deleteCodexEntry(selectedCodexEntry.id);
          resetCodexForm();
        }}
        onEntrySubmit={(event) => {
          event.preventDefault();

          const tags = toTagList(codexTags);
          if (selectedCodexEntry) {
            updateCodexEntry(selectedCodexEntry.id, {
              codexNodeId: codexEntryNodeId ?? defaultCodexNode?.id ?? selectedCodexEntry.codexNodeId,
              title: codexTitle,
              type: codexType,
              content: codexContent,
              tags,
            });
            return;
          }

          const entry = createCodexEntry(project.id, {
            codexNodeId: codexEntryNodeId ?? defaultCodexNode?.id ?? undefined,
            title: codexTitle,
            type: codexType,
            content: codexContent,
            tags,
          });
          setSelectedCodexId(entry.id);
          setSelectedCodexNodeId(entry.codexNodeId);
        }}
        onNodeSubmit={(event) => {
          event.preventDefault();
          saveCodexNode();
        }}
        onCancelNodeEdit={cancelCodexNodeEdit}
        onTitleChange={setCodexTitle}
        onTypeChange={setCodexType}
        onTagsChange={setCodexTags}
        onContentChange={setCodexContent}
        onCodexEntryNodeChange={setCodexEntryNodeId}
        onCodexNodeParentChange={setCodexNodeParentId}
        onCodexNodeTitleChange={setCodexNodeTitle}
        onCodexNodeTypeChange={setCodexNodeType}
        onCodexNodeCustomTypeLabelChange={setCodexNodeCustomTypeLabel}
        onCodexNodeTagsChange={setCodexNodeTags}
      />

      <ProjectExportPanel
        projectId={project.id}
        hasCodexEntries={projectCodexEntries.length > 0}
        exportError={exportError}
        lastBackupExportAt={lastBackupExportAt}
        onExportBackup={() => {
          try {
            exportProjectBackupFile(
              project,
              projectStructureNodes,
              projectScenes,
              projectCodexNodes,
              projectCodexEntries,
              revisionSnapshots.filter((snapshot) => snapshot.projectId === project.id),
            );
            recordProjectBackupExport(project.id);
            setExportError('');
          } catch {
            setExportError('Could not export the project backup.');
          }
        }}
        onExportStory={() => {
          try {
            exportProjectStoryFile(project, projectStructureNodes, projectScenes);
            setExportError('');
          } catch {
            setExportError('Could not export the story text.');
          }
        }}
        onExportWiki={() => window.alert('Wiki export is planned, but PDF export is not implemented yet.')}
      />

      <CommandPalette
        isOpen={isCommandPaletteOpen}
        items={commandPaletteItems}
        query={commandQuery}
        onClose={closeCommandPalette}
        onQueryChange={setCommandQuery}
      />
    </div>
  );
}
