import { downloadTextFile } from './backup';
import { fetchBackendDiagnosticsExport, fetchBackendHealth } from './api';
import type { LoreLoomPersistedState } from './types';

function toFileStamp(iso: string) {
  return iso.replace(/[:.]/g, '-');
}

function isLocalStorageAvailable() {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return false;
    }

    const key = '__loreloom_diagnostics_test__';
    window.localStorage.setItem(key, '1');
    window.localStorage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}

async function getStorageEstimate() {
  if (typeof navigator !== 'undefined' && navigator.storage?.estimate) {
    try {
      const estimate = await navigator.storage.estimate();
      return {
        usageBytes: estimate.usage ?? null,
        quotaBytes: estimate.quota ?? null,
        source: 'navigator.storage.estimate',
      };
    } catch {
      // Fall through to the localStorage approximation below.
    }
  }

  if (typeof window !== 'undefined' && isLocalStorageAvailable()) {
    try {
      const serialized = window.localStorage.getItem('loreloom-storage') ?? '';
      return {
        usageBytes: new Blob([serialized]).size,
        quotaBytes: null,
        source: 'localStorage-approximation',
      };
    } catch {
      return {
        usageBytes: null,
        quotaBytes: null,
        source: 'unavailable',
      };
    }
  }

  return {
    usageBytes: null,
    quotaBytes: null,
    source: 'unavailable',
  };
}

function buildDiagnosticsSummary(state: LoreLoomPersistedState) {
  const projectIds = new Set(state.projects.map((project) => project.id));
  const syncEntries = Object.entries(state.sync.projects).filter(([projectId]) => projectIds.has(projectId));

  return {
    projectCount: state.projects.length,
    structureNodeCount: state.structureNodes.length,
    textBlockCount: state.scenes.length,
    codexNodeCount: state.codexNodes.length,
    codexEntryCount: state.codexEntries.length,
    revisionSnapshotCount: state.revisionSnapshots.length,
    dirtyProjectCount: syncEntries.filter(([, sync]) => sync.dirty).length,
    syncingProjectCount: syncEntries.filter(([, sync]) => sync.status === 'syncing').length,
    offlineProjectCount: syncEntries.filter(([, sync]) => sync.status === 'offline').length,
    conflictProjectCount: syncEntries.filter(([, sync]) => sync.status === 'conflict').length,
    pendingDeleteCount: state.sync.pendingDeletes.length,
    backendStatus: state.sync.backendStatus,
    hydrationState: state.sync.hydrationState,
  };
}

function buildProjectDiagnostics(state: LoreLoomPersistedState) {
  return state.projects.map((project) => {
    const sync = state.sync.projects[project.id];
    return {
      projectId: project.id,
      updatedAt: project.updatedAt,
      structureNodeCount: state.structureNodes.filter((node) => node.projectId === project.id).length,
      textBlockCount: state.scenes.filter((scene) => scene.projectId === project.id).length,
      codexNodeCount: state.codexNodes.filter((node) => node.projectId === project.id).length,
      codexEntryCount: state.codexEntries.filter((entry) => entry.projectId === project.id).length,
      revisionSnapshotCount: state.revisionSnapshots.filter((snapshot) => snapshot.projectId === project.id).length,
      sync: sync
        ? {
            dirty: sync.dirty,
            status: sync.status,
            serverRevision: sync.serverRevision,
            lastSyncAt: sync.lastSyncAt,
            error: sync.error,
          }
        : null,
    };
  });
}

export async function buildDiagnosticBundle(state: LoreLoomPersistedState) {
  const generatedAt = new Date().toISOString();
  const storageEstimate = await getStorageEstimate();
  const backendDiagnosticsResult = await fetchBackendDiagnosticsExport()
    .then((value) => ({ ok: true as const, value }))
    .catch((error) => ({ ok: false as const, error: error instanceof Error ? error.message : 'Request failed.' }));
  const backendHealthResult =
    backendDiagnosticsResult.ok
      ? { ok: true as const, value: backendDiagnosticsResult.value.backend.health }
      : await fetchBackendHealth()
          .then((value) => ({ ok: true as const, value }))
          .catch((error) => ({ ok: false as const, error: error instanceof Error ? error.message : 'Request failed.' }));

  return {
    format: 'LoreLoom Diagnostic Bundle',
    version: 1,
    generatedAt,
    app: {
      name: 'LoreLoom',
      version: __APP_VERSION__,
      buildTimestamp: __BUILD_TIMESTAMP__,
      mode: import.meta.env.MODE,
    },
    frontendEnvironment: {
      origin: typeof window !== 'undefined' ? window.location.origin : null,
      protocol: typeof window !== 'undefined' ? window.location.protocol : null,
      secureContext: typeof window !== 'undefined' ? window.isSecureContext : null,
      online: typeof navigator !== 'undefined' ? navigator.onLine : null,
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : null,
      language: typeof navigator !== 'undefined' ? navigator.language : null,
      platform:
        typeof navigator !== 'undefined' && 'userAgentData' in navigator
          ? null
          : typeof navigator !== 'undefined'
            ? navigator.platform
            : null,
      localStorageAvailable: isLocalStorageAvailable(),
      storageEstimate,
    },
    backend: {
      health: backendHealthResult.ok ? backendHealthResult.value : null,
      healthError: backendHealthResult.ok ? null : backendHealthResult.error,
      diagnosticsExport: backendDiagnosticsResult.ok ? backendDiagnosticsResult.value : null,
      diagnosticsExportError: backendDiagnosticsResult.ok ? null : backendDiagnosticsResult.error,
    },
    diagnostics: {
      summary: buildDiagnosticsSummary(state),
      recentEvents: state.diagnostics.events.slice(0, 50).map((event) => ({
        id: event.id,
        at: event.at,
        type: event.type,
        projectId: event.projectId ?? null,
        status: event.status ?? null,
        message: event.message ?? null,
      })),
      syncStatuses: buildProjectDiagnostics(state),
      syncErrorsAndConflicts: Object.entries(state.sync.projects)
        .filter(([, sync]) => sync.error || sync.status === 'conflict')
        .map(([projectId, sync]) => ({
          projectId,
          status: sync.status,
          error: sync.error,
          serverRevision: sync.serverRevision,
          lastSyncAt: sync.lastSyncAt,
        })),
    },
    privacy: {
      manuscriptTextIncluded: false,
      manuscriptTitlesIncluded: false,
      codexContentIncluded: false,
      codexTitlesIncluded: false,
      revisionSnapshotContentIncluded: false,
      searchQueriesIncluded: false,
    },
  };
}

export async function exportDiagnosticBundleFile(state: LoreLoomPersistedState) {
  const bundle = await buildDiagnosticBundle(state);
  const filename = `loreloom-diagnostic-bundle-${toFileStamp(bundle.generatedAt)}.json`;
  downloadTextFile(filename, `${JSON.stringify(bundle, null, 2)}\n`, 'application/json;charset=utf-8');
  return bundle;
}
