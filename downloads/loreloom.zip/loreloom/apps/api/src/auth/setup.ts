export function isSetupRequired(userCount: number): boolean {
  return userCount === 0;
}
