import path from 'node:path';
import { z } from 'zod';

const booleanFromEnvSchema = z.preprocess((value) => {
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();

    if (['1', 'true', 'yes', 'on'].includes(normalized)) {
      return true;
    }

    if (['0', 'false', 'no', 'off', ''].includes(normalized)) {
      return false;
    }
  }

  return value;
}, z.boolean());

const envSchema = z.object({
  APP_NAME: z.string().default('LoreLoom API'),
  APP_VERSION: z.string().default(process.env.npm_package_version ?? '0.1.0'),
  HOST: z.string().default('0.0.0.0'),
  PORT: z.coerce.number().int().positive().default(8787),
  DATABASE_PATH: z.string().optional(),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  MAX_REQUEST_BODY_BYTES: z.coerce.number().int().positive().default(2 * 1024 * 1024),
  DEV_CORS_ORIGIN: z.string().optional(),
  AUTH_COOKIE_NAME: z.string().default('loreloom_session'),
  AUTH_SESSION_DURATION_HOURS: z.coerce.number().int().positive().default(24 * 14),
  AUTH_SECURE_COOKIE: booleanFromEnvSchema.default(false),
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
});

export type AppConfig = {
  appName: string;
  appVersion: string;
  host: string;
  port: number;
  databasePath: string;
  logLevel: 'fatal' | 'error' | 'warn' | 'info' | 'debug' | 'trace' | 'silent';
  maxRequestBodyBytes: number;
  devCorsOrigin: string | null;
  authCookieName: string;
  authSessionDurationHours: number;
  authSecureCookie: boolean;
  nodeEnv: 'development' | 'test' | 'production';
};

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const parsed = envSchema.parse(env);

  return {
    appName: parsed.APP_NAME,
    appVersion: parsed.APP_VERSION,
    host: parsed.HOST,
    port: parsed.PORT,
    databasePath: parsed.DATABASE_PATH
      ? path.resolve(parsed.DATABASE_PATH)
      : path.resolve(process.cwd(), 'data', 'loreloom.sqlite'),
    logLevel: parsed.LOG_LEVEL,
    maxRequestBodyBytes: parsed.MAX_REQUEST_BODY_BYTES,
    devCorsOrigin: parsed.DEV_CORS_ORIGIN?.trim() ? parsed.DEV_CORS_ORIGIN.trim() : null,
    authCookieName: parsed.AUTH_COOKIE_NAME.trim() || 'loreloom_session',
    authSessionDurationHours: parsed.AUTH_SESSION_DURATION_HOURS,
    authSecureCookie: parsed.AUTH_SECURE_COOKIE,
    nodeEnv: parsed.NODE_ENV,
  };
}
