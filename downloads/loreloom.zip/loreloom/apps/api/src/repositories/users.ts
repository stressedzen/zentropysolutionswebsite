import type { SqliteDatabase } from '../db/pragmas.js';

export type UserRow = {
  id: string;
  username: string;
  password_hash: string;
  display_name: string | null;
  role: 'admin' | 'user';
  created_at: string;
  updated_at: string;
};

type RawUserRow = Omit<UserRow, 'role'> & {
  role: 'admin' | 'user' | 'member';
};

export type CreateUserInput = {
  id: string;
  username: string;
  passwordHash: string;
  displayName: string | null;
  role: UserRow['role'];
  createdAt: string;
  updatedAt: string;
};

export function countUsers(database: SqliteDatabase): number {
  const row = database.prepare('SELECT COUNT(*) AS count FROM users').get() as { count: number };
  return row.count;
}

function mapUserRow(row: RawUserRow | undefined): UserRow | null {
  if (!row) {
    return null;
  }

  return {
    ...row,
    role: row.role === 'member' ? 'user' : row.role,
  };
}

function toLegacyRole(role: UserRow['role']): 'admin' | 'member' {
  return role === 'admin' ? 'admin' : 'member';
}

export function findUserById(database: SqliteDatabase, userId: string): UserRow | null {
  return mapUserRow(
    database
      .prepare(
        `
          SELECT id, username, password_hash, display_name, role, created_at, updated_at
          FROM users
          WHERE id = ?
        `,
      )
      .get(userId) as RawUserRow | undefined,
  );
}

export function findUserByUsername(database: SqliteDatabase, username: string): UserRow | null {
  return mapUserRow(
    database
      .prepare(
        `
          SELECT id, username, password_hash, display_name, role, created_at, updated_at
          FROM users
          WHERE username = ?
        `,
      )
      .get(username) as RawUserRow | undefined,
  );
}

export function createUser(database: SqliteDatabase, input: CreateUserInput): UserRow {
  database
    .prepare(
      `
        INSERT INTO users (id, username, password_hash, display_name, role_legacy, role, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `,
    )
    .run(
      input.id,
      input.username,
      input.passwordHash,
      input.displayName,
      toLegacyRole(input.role),
      input.role,
      input.createdAt,
      input.updatedAt,
    );

  const createdUser = findUserById(database, input.id);

  if (!createdUser) {
    throw new Error(`User ${input.id} was not created.`);
  }

  return createdUser;
}

export function listUsers(database: SqliteDatabase): UserRow[] {
  return (
    database
      .prepare(
        `
          SELECT id, username, password_hash, display_name, role, created_at, updated_at
          FROM users
          ORDER BY created_at ASC, username ASC
        `,
      )
      .all() as RawUserRow[]
  )
    .map((row) => mapUserRow(row))
    .filter((row): row is UserRow => row !== null);
}

export function updateUserPasswordHash(
  database: SqliteDatabase,
  input: {
    userId: string;
    passwordHash: string;
    updatedAt: string;
  },
): boolean {
  const result = database
    .prepare(
      `
        UPDATE users
        SET password_hash = ?, updated_at = ?
        WHERE id = ?
      `,
    )
    .run(input.passwordHash, input.updatedAt, input.userId);

  return result.changes > 0;
}
