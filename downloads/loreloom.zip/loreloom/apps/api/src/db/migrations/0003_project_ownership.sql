ALTER TABLE projects
ADD COLUMN owner_user_id TEXT NULL REFERENCES users(id) ON DELETE RESTRICT;

CREATE INDEX IF NOT EXISTS projects_owner_user_id_idx ON projects(owner_user_id);
