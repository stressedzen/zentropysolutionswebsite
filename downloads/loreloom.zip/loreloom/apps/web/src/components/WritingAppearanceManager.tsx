import { useEffect } from 'react';
import {
  ensureInterfaceFontLoaded,
  ensureWritingFontLoaded,
  getAppearanceCssVariables,
} from '../lib/writingAppearance';
import { useLoreLoomStore } from '../store/useLoreLoomStore';

export default function WritingAppearanceManager() {
  const appearance = useLoreLoomStore((state) => state.appearance);

  useEffect(() => {
    void ensureInterfaceFontLoaded(appearance.interfaceFontId);
    void ensureWritingFontLoaded(appearance.writingFontId);
  }, [appearance.interfaceFontId, appearance.writingFontId]);

  useEffect(() => {
    if (typeof document === 'undefined') {
      return;
    }

    const root = document.documentElement;
    const variables = getAppearanceCssVariables(appearance);

    for (const [key, value] of Object.entries(variables)) {
      root.style.setProperty(key, value);
    }
  }, [appearance]);

  return null;
}
