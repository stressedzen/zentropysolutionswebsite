ALTER TABLE users RENAME COLUMN role TO role_legacy;

ALTER TABLE users
ADD COLUMN role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user'));

UPDATE users
SET role = CASE
  WHEN role_legacy = 'admin' THEN 'admin'
  ELSE 'user'
END;

DROP INDEX IF EXISTS users_role_idx;
CREATE INDEX IF NOT EXISTS users_role_idx ON users(role);
