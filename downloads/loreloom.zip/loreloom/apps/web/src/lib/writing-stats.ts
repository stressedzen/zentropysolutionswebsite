import type { Scene } from './types';

function normalizeWritingText(text: string) {
  return text.replace(/\u00a0/g, ' ').replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
}

export function stripHtmlToPlainText(html: string) {
  if (typeof document === 'undefined') {
    return normalizeWritingText(
      html
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/p>\s*<p[^>]*>/gi, '\n\n')
        .replace(/<[^>]*>/g, ''),
    );
  }

  const container = document.createElement('div');
  container.innerHTML = html;

  return normalizeWritingText(container.innerText || container.textContent || '');
}

export function countWords(text: string) {
  const normalized = normalizeWritingText(text);
  if (!normalized) {
    return 0;
  }

  return normalized.match(/\S+/g)?.length ?? 0;
}

export function countCharacters(text: string) {
  return normalizeWritingText(text).length;
}

export function estimateReadingTimeMinutes(wordCount: number) {
  if (wordCount <= 0) {
    return 0;
  }

  return Math.max(1, Math.ceil(wordCount / 200));
}

export function countHtmlWords(html: string) {
  return countWords(stripHtmlToPlainText(html));
}

export function countHtmlCharacters(html: string) {
  return countCharacters(stripHtmlToPlainText(html));
}

export function countProjectWords(scenes: Pick<Scene, 'content'>[]) {
  return scenes.reduce((total, scene) => total + countHtmlWords(scene.content), 0);
}

export function formatWritingDate(iso: string) {
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(new Date(iso));
}

export function formatRelativeBackupDate(iso: string | null) {
  if (!iso) {
    return 'Never';
  }

  const backupDate = new Date(iso);
  if (Number.isNaN(backupDate.getTime())) {
    return 'Unknown';
  }

  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfBackupDay = new Date(backupDate.getFullYear(), backupDate.getMonth(), backupDate.getDate());
  const diffDays = Math.floor((startOfToday.getTime() - startOfBackupDay.getTime()) / 86_400_000);

  if (diffDays <= 0) {
    return 'Today';
  }

  if (diffDays === 1) {
    return 'Yesterday';
  }

  return `${diffDays} days ago`;
}

export function isBackupReminderStale(iso: string | null, staleAfterDays = 14) {
  if (!iso) {
    return true;
  }

  const backupDate = new Date(iso);
  if (Number.isNaN(backupDate.getTime())) {
    return true;
  }

  const now = new Date();
  return now.getTime() - backupDate.getTime() >= staleAfterDays * 86_400_000;
}
