import type { FastifyReply, FastifyRequest } from 'fastify';
import type { AppConfig } from '../config.js';
import type { SqliteDatabase } from '../db/pragmas.js';
import { serializeClearedSessionCookie } from '../auth/sessions.js';
import { getCurrentAuthenticatedUser, type AuthenticatedUser } from '../services/auth-service.js';

export type AuthenticatedRequest = FastifyRequest & {
  currentUser: AuthenticatedUser;
};

function clearAuthCookie(reply: FastifyReply, config: Pick<AppConfig, 'authCookieName' | 'authSecureCookie'>) {
  reply.header(
    'Set-Cookie',
    serializeClearedSessionCookie(config.authCookieName, {
      secure: config.authSecureCookie,
    }),
  );
}

export async function requireAuthenticatedUser(
  request: FastifyRequest,
  reply: FastifyReply,
  database: SqliteDatabase,
  config: Pick<AppConfig, 'authCookieName' | 'authSecureCookie'>,
): Promise<AuthenticatedUser | null> {
  const authResult = getCurrentAuthenticatedUser(database, request.headers.cookie, config);

  if (authResult.clearCookie) {
    clearAuthCookie(reply, config);
  }

  if (!authResult.authenticated || !authResult.user) {
    await reply.code(401).send({
      error: 'unauthorized',
      message: 'Authentication is required.',
    });
    return null;
  }

  return authResult.user;
}

export async function requireAdminUser(
  request: FastifyRequest,
  reply: FastifyReply,
  database: SqliteDatabase,
  config: Pick<AppConfig, 'authCookieName' | 'authSecureCookie'>,
): Promise<AuthenticatedUser | null> {
  const currentUser = await requireAuthenticatedUser(request, reply, database, config);

  if (!currentUser) {
    return null;
  }

  if (currentUser.role !== 'admin') {
    await reply.code(403).send({
      error: 'forbidden',
      message: 'Admin access is required.',
    });
    return null;
  }

  return currentUser;
}
