import type { SqliteDatabase } from '../db/pragmas.js';
import { createTemporaryPassword, hashPassword } from '../auth/passwords.js';
import { createUserId } from '../auth/sessions.js';
import { createUser, findUserById, findUserByUsername, listUsers, updateUserPasswordHash, type UserRow } from '../repositories/users.js';
import { deleteSessionsByUserId } from '../repositories/sessions.js';

export type AdminUserSummary = {
  id: string;
  username: string;
  displayName: string | null;
  role: UserRow['role'];
  createdAt: string;
  updatedAt: string;
};

export type CreateManagedUserInput = {
  username: string;
  displayName: string | null;
  role: UserRow['role'];
};

export type CreateManagedUserResult =
  | {
      status: 'created';
      user: AdminUserSummary;
      temporaryPassword: string;
    }
  | {
      status: 'username_taken';
    };

export type ResetManagedUserPasswordResult =
  | {
      status: 'reset';
      user: AdminUserSummary;
      temporaryPassword: string;
    }
  | {
      status: 'not_found';
    };

function normalizeUsername(username: string) {
  return username.trim().toLowerCase();
}

function mapAdminUser(user: UserRow): AdminUserSummary {
  return {
    id: user.id,
    username: user.username,
    displayName: user.display_name,
    role: user.role,
    createdAt: user.created_at,
    updatedAt: user.updated_at,
  };
}

export function getAdminUserList(database: SqliteDatabase): AdminUserSummary[] {
  return listUsers(database).map(mapAdminUser);
}

export async function createManagedUser(
  database: SqliteDatabase,
  input: CreateManagedUserInput,
): Promise<CreateManagedUserResult> {
  const nowIso = new Date().toISOString();
  const normalizedUsername = normalizeUsername(input.username);

  if (findUserByUsername(database, normalizedUsername)) {
    return {
      status: 'username_taken',
    };
  }

  const temporaryPassword = createTemporaryPassword();
  const passwordHash = await hashPassword(temporaryPassword);

  let createdUser: UserRow;

  try {
    createdUser = database.transaction(() =>
      createUser(database, {
        id: createUserId(),
        username: normalizedUsername,
        passwordHash,
        displayName: input.displayName,
        role: input.role,
        createdAt: nowIso,
        updatedAt: nowIso,
      }),
    )();
  } catch (error) {
    if (error instanceof Error && error.message.includes('UNIQUE constraint failed: users.username')) {
      return {
        status: 'username_taken',
      };
    }

    throw error;
  }

  return {
    status: 'created',
    user: mapAdminUser(createdUser),
    temporaryPassword,
  };
}

export async function resetManagedUserPassword(
  database: SqliteDatabase,
  userId: string,
): Promise<ResetManagedUserPasswordResult> {
  const existingUser = findUserById(database, userId);

  if (!existingUser) {
    return {
      status: 'not_found',
    };
  }

  const temporaryPassword = createTemporaryPassword();
  const passwordHash = await hashPassword(temporaryPassword);
  const updatedAt = new Date().toISOString();

  database.transaction(() => {
    updateUserPasswordHash(database, {
      userId,
      passwordHash,
      updatedAt,
    });
    deleteSessionsByUserId(database, userId);
  })();

  const updatedUser = findUserById(database, userId);

  if (!updatedUser) {
    return {
      status: 'not_found',
    };
  }

  return {
    status: 'reset',
    user: mapAdminUser(updatedUser),
    temporaryPassword,
  };
}
