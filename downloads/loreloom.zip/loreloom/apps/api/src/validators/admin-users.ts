import { z } from 'zod';
import { displayNameSchema, usernameSchema } from './auth.js';

export const adminUserRoleSchema = z.enum(['admin', 'user']);

export const adminUserCreateBodySchema = z.object({
  username: usernameSchema,
  displayName: displayNameSchema.optional(),
  role: adminUserRoleSchema.default('user'),
});

export const adminUserParamsSchema = z.object({
  id: z.string().trim().min(1, 'User id is required.'),
});
