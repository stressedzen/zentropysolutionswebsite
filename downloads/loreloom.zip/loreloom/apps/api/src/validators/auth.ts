import { z } from 'zod';

const usernamePattern = /^[a-zA-Z0-9_-]+$/;
export const usernameSchema = z
  .string()
  .trim()
  .min(3, 'Username must be at least 3 characters.')
  .max(64, 'Username must be 64 characters or fewer.')
  .regex(usernamePattern, 'Username may only contain letters, numbers, underscores, and hyphens.');

const setupPasswordSchema = z.string().min(6, 'Password must be at least 6 characters.');
export const displayNameSchema = z
  .string()
  .trim()
  .max(120, 'Display name must be 120 characters or fewer.');

export const setupStatusResponseSchema = z.object({
  setupRequired: z.boolean(),
});

export const setupAdminBodySchema = z
  .object({
    username: usernameSchema,
    password: setupPasswordSchema,
    passwordConfirmation: z.string().optional(),
    displayName: displayNameSchema.optional(),
  })
  .superRefine((value, context) => {
    if (value.passwordConfirmation !== undefined && value.password !== value.passwordConfirmation) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['passwordConfirmation'],
        message: 'Password confirmation must match the password.',
      });
    }
  });

export const loginBodySchema = z.object({
  username: usernameSchema,
  password: z.string().min(1, 'Password is required.'),
});

export const changePasswordBodySchema = z
  .object({
    currentPassword: z.string().min(1, 'Current password is required.'),
    newPassword: setupPasswordSchema,
    passwordConfirmation: z.string().min(1, 'Password confirmation is required.'),
  })
  .superRefine((value, context) => {
    if (value.newPassword !== value.passwordConfirmation) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['passwordConfirmation'],
        message: 'Password confirmation must match the new password.',
      });
    }
  });
