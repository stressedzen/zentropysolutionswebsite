import type {
  LoreLoomWritingAppearanceState,
  WritingEditorWidth,
  InterfaceFontId,
  WritingFontId,
  WritingFontSize,
  WritingLineSpacing,
} from './types';

export type WritingFontOption = {
  id: WritingFontId;
  label: string;
  category: 'Sans' | 'Serif' | 'Monospace';
  family: string;
};

type FontLoaderId = WritingFontId | InterfaceFontId;

const ALL_FONT_OPTIONS: WritingFontOption[] = [
  {
    id: 'system-sans',
    label: 'System Sans',
    category: 'Sans',
    family:
      'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  },
  {
    id: 'inter',
    label: 'Inter',
    category: 'Sans',
    family: '"Inter", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  },
  {
    id: 'source-sans-3',
    label: 'Source Sans 3',
    category: 'Sans',
    family: '"Source Sans 3", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  },
  {
    id: 'ibm-plex-sans',
    label: 'IBM Plex Sans',
    category: 'Sans',
    family: '"IBM Plex Sans", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  },
  {
    id: 'atkinson-hyperlegible',
    label: 'Atkinson Hyperlegible',
    category: 'Sans',
    family:
      '"Atkinson Hyperlegible", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  },
  {
    id: 'literata',
    label: 'Literata',
    category: 'Serif',
    family: '"Literata", Georgia, "Times New Roman", serif',
  },
  {
    id: 'merriweather',
    label: 'Merriweather',
    category: 'Serif',
    family: '"Merriweather", Georgia, "Times New Roman", serif',
  },
  {
    id: 'source-serif-4',
    label: 'Source Serif 4',
    category: 'Serif',
    family: '"Source Serif 4", Georgia, "Times New Roman", serif',
  },
  {
    id: 'ibm-plex-serif',
    label: 'IBM Plex Serif',
    category: 'Serif',
    family: '"IBM Plex Serif", Georgia, "Times New Roman", serif',
  },
  {
    id: 'jetbrains-mono',
    label: 'JetBrains Mono',
    category: 'Monospace',
    family: '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
  },
  {
    id: 'ibm-plex-mono',
    label: 'IBM Plex Mono',
    category: 'Monospace',
    family: '"IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
  },
];

export const INTERFACE_FONT_OPTIONS = ALL_FONT_OPTIONS.filter((option) => option.category === 'Sans');
export const WRITING_FONT_OPTIONS = ALL_FONT_OPTIONS;

export const WRITING_FONT_SIZE_OPTIONS: Array<{ id: WritingFontSize; label: string }> = [
  { id: 'small', label: 'Small' },
  { id: 'medium', label: 'Medium' },
  { id: 'large', label: 'Large' },
  { id: 'extra-large', label: 'Extra Large' },
];

export const WRITING_LINE_SPACING_OPTIONS: Array<{ id: WritingLineSpacing; label: string }> = [
  { id: 'compact', label: 'Compact' },
  { id: 'comfortable', label: 'Comfortable' },
  { id: 'spacious', label: 'Spacious' },
];

export const WRITING_EDITOR_WIDTH_OPTIONS: Array<{ id: WritingEditorWidth; label: string }> = [
  { id: 'narrow', label: 'Narrow' },
  { id: 'standard', label: 'Standard' },
  { id: 'wide', label: 'Wide' },
];

export const DEFAULT_WRITING_APPEARANCE: LoreLoomWritingAppearanceState = {
  interfaceFontId: 'inter',
  writingFontId: 'literata',
  fontSize: 'medium',
  lineSpacing: 'comfortable',
  editorWidth: 'standard',
};

const fontLoaders: Record<FontLoaderId, (() => Promise<unknown>) | null> = {
  'system-sans': null,
  inter: () =>
    Promise.all([
      import('@fontsource/inter/latin-400.css'),
      import('@fontsource/inter/latin-ext-400.css'),
      import('@fontsource/inter/latin-700.css'),
      import('@fontsource/inter/latin-ext-700.css'),
    ]),
  'source-sans-3': () =>
    Promise.all([
      import('@fontsource/source-sans-3/latin-400.css'),
      import('@fontsource/source-sans-3/latin-ext-400.css'),
      import('@fontsource/source-sans-3/latin-700.css'),
      import('@fontsource/source-sans-3/latin-ext-700.css'),
    ]),
  'ibm-plex-sans': () =>
    Promise.all([
      import('@fontsource/ibm-plex-sans/latin-400.css'),
      import('@fontsource/ibm-plex-sans/latin-ext-400.css'),
      import('@fontsource/ibm-plex-sans/latin-600.css'),
      import('@fontsource/ibm-plex-sans/latin-ext-600.css'),
    ]),
  'atkinson-hyperlegible': () =>
    Promise.all([
      import('@fontsource/atkinson-hyperlegible/latin-400.css'),
      import('@fontsource/atkinson-hyperlegible/latin-ext-400.css'),
      import('@fontsource/atkinson-hyperlegible/latin-700.css'),
      import('@fontsource/atkinson-hyperlegible/latin-ext-700.css'),
    ]),
  literata: () =>
    Promise.all([
      import('@fontsource/literata/latin-400.css'),
      import('@fontsource/literata/latin-ext-400.css'),
      import('@fontsource/literata/latin-700.css'),
      import('@fontsource/literata/latin-ext-700.css'),
    ]),
  merriweather: () =>
    Promise.all([
      import('@fontsource/merriweather/latin-400.css'),
      import('@fontsource/merriweather/latin-ext-400.css'),
      import('@fontsource/merriweather/latin-700.css'),
      import('@fontsource/merriweather/latin-ext-700.css'),
    ]),
  'source-serif-4': () =>
    Promise.all([
      import('@fontsource/source-serif-4/latin-400.css'),
      import('@fontsource/source-serif-4/latin-ext-400.css'),
      import('@fontsource/source-serif-4/latin-700.css'),
      import('@fontsource/source-serif-4/latin-ext-700.css'),
    ]),
  'ibm-plex-serif': () =>
    Promise.all([
      import('@fontsource/ibm-plex-serif/latin-400.css'),
      import('@fontsource/ibm-plex-serif/latin-ext-400.css'),
      import('@fontsource/ibm-plex-serif/latin-600.css'),
      import('@fontsource/ibm-plex-serif/latin-ext-600.css'),
    ]),
  'jetbrains-mono': () =>
    Promise.all([
      import('@fontsource/jetbrains-mono/latin-400.css'),
      import('@fontsource/jetbrains-mono/latin-ext-400.css'),
      import('@fontsource/jetbrains-mono/latin-700.css'),
      import('@fontsource/jetbrains-mono/latin-ext-700.css'),
    ]),
  'ibm-plex-mono': () =>
    Promise.all([
      import('@fontsource/ibm-plex-mono/latin-400.css'),
      import('@fontsource/ibm-plex-mono/latin-ext-400.css'),
      import('@fontsource/ibm-plex-mono/latin-600.css'),
      import('@fontsource/ibm-plex-mono/latin-ext-600.css'),
    ]),
};

const loadedFonts = new Set<FontLoaderId>();

function ensureFontLoaded(fontId: FontLoaderId) {
  if (loadedFonts.has(fontId)) {
    return Promise.resolve();
  }

  const loader = fontLoaders[fontId];
  if (!loader) {
    loadedFonts.add(fontId);
    return Promise.resolve();
  }

  return loader().then(() => {
    loadedFonts.add(fontId);
  });
}

export function getInterfaceFontOption(fontId: InterfaceFontId) {
  return INTERFACE_FONT_OPTIONS.find((option) => option.id === fontId) ?? INTERFACE_FONT_OPTIONS[0];
}

export function getWritingFontOption(fontId: WritingFontId) {
  return WRITING_FONT_OPTIONS.find((option) => option.id === fontId) ?? WRITING_FONT_OPTIONS[0];
}

export function getAppearanceCssVariables(appearance: LoreLoomWritingAppearanceState) {
  return {
    '--interface-font-family': getInterfaceFontOption(appearance.interfaceFontId).family,
    '--writing-font-family': getWritingFontOption(appearance.writingFontId).family,
    '--writing-font-size': getWritingFontSizeValue(appearance.fontSize),
    '--writing-line-height': getWritingLineHeightValue(appearance.lineSpacing),
    '--writing-content-max-width': getWritingWidthValue(appearance.editorWidth),
  } as Record<string, string>;
}

export const getWritingAppearanceCssVariables = getAppearanceCssVariables;

export async function ensureInterfaceFontLoaded(fontId: InterfaceFontId) {
  await ensureFontLoaded(fontId);
}

export async function ensureWritingFontLoaded(fontId: WritingFontId) {
  await ensureFontLoaded(fontId);
}

function getWritingFontSizeValue(fontSize: WritingFontSize) {
  switch (fontSize) {
    case 'small':
      return '0.95rem';
    case 'medium':
      return '1.05rem';
    case 'large':
      return '1.18rem';
    case 'extra-large':
      return '1.32rem';
  }
}

function getWritingLineHeightValue(lineSpacing: WritingLineSpacing) {
  switch (lineSpacing) {
    case 'compact':
      return '1.58';
    case 'comfortable':
      return '1.74';
    case 'spacious':
      return '1.92';
  }
}

function getWritingWidthValue(editorWidth: WritingEditorWidth) {
  switch (editorWidth) {
    case 'narrow':
      return '42rem';
    case 'standard':
      return '52rem';
    case 'wide':
      return '64rem';
  }
}
