import type { Scene } from './types';
import { createId } from './id';

export function nowIso() {
  return new Date().toISOString();
}

export function makeId() {
  return createId();
}

export function defaultSceneContent(sceneTitle: string) {
  return `<p>${sceneTitle ? `Start writing "${sceneTitle}".` : 'Start writing your text block.'}</p>`;
}

export function sortByUpdatedThenCreated<T extends { updatedAt: string; createdAt: string }>(items: T[]) {
  return [...items].sort((left, right) => {
    const updated = right.updatedAt.localeCompare(left.updatedAt);
    if (updated !== 0) {
      return updated;
    }

    return right.createdAt.localeCompare(left.createdAt);
  });
}

export function scenePreview(scene: Scene) {
  const stripped = scene.content.replace(/<[^>]*>/g, '').trim();
  return stripped || 'No content yet';
}
