import { useCallback, useEffect, useMemo, useRef } from 'react';
import {
  ApiClientError,
  type ApiCodexEntry,
  deleteRemoteProject,
  fetchProjectBundle,
  listProjectSummaries,
  uploadProjectBundle,
} from '../lib/api';
import type { LoreLoomState } from '../lib/types';
import { useLoreLoomStore } from '../store/useLoreLoomStore';

const PROJECT_SYNC_DEBOUNCE_MS = 1800;

function bundleToProjectState(bundle: {
  project: LoreLoomState['projects'][number];
  structureNodes: LoreLoomState['structureNodes'];
  scenes: LoreLoomState['scenes'];
  codexNodes: LoreLoomState['codexNodes'];
  codexEntries: ApiCodexEntry[];
  revisionSnapshots: LoreLoomState['revisionSnapshots'];
}): LoreLoomState {
  const fallbackCodexNodeId = bundle.codexNodes[0]?.id ?? `codex-root:${bundle.project.id}`;

  return {
    projects: [bundle.project],
    structureNodes: bundle.structureNodes,
    scenes: bundle.scenes,
    codexNodes: bundle.codexNodes,
    codexEntries: bundle.codexEntries.map((entry) => ({
      ...entry,
      codexNodeId: entry.codexNodeId ?? fallbackCodexNodeId,
    })),
    revisionSnapshots: bundle.revisionSnapshots,
  };
}

export default function ProjectSyncManager() {
  const projects = useLoreLoomStore((state) => state.projects);
  const projectSync = useLoreLoomStore((state) => state.sync.projects);
  const pendingDeletes = useLoreLoomStore((state) => state.sync.pendingDeletes);
  const setBackendStatus = useLoreLoomStore((state) => state.setBackendStatus);
  const setHydrationState = useLoreLoomStore((state) => state.setHydrationState);
  const applyRemoteProjectBundle = useLoreLoomStore((state) => state.applyRemoteProjectBundle);
  const markProjectSyncing = useLoreLoomStore((state) => state.markProjectSyncing);
  const markProjectSyncSuccess = useLoreLoomStore((state) => state.markProjectSyncSuccess);
  const markProjectSyncOffline = useLoreLoomStore((state) => state.markProjectSyncOffline);
  const markProjectSyncConflict = useLoreLoomStore((state) => state.markProjectSyncConflict);
  const clearPendingDelete = useLoreLoomStore((state) => state.clearPendingDelete);
  const recordDiagnosticEvent = useLoreLoomStore((state) => state.recordDiagnosticEvent);

  const dirtyProjectIds = useMemo(
    () =>
      projects
        .map((project) => project.id)
        .filter((projectId) => {
          const syncMeta = projectSync[projectId];
          return syncMeta?.dirty && syncMeta.status !== 'conflict';
        }),
    [projectSync, projects],
  );

  const syncTimersRef = useRef<Map<string, number>>(new Map());
  const syncingProjectIdsRef = useRef<Set<string>>(new Set());
  const deletingProjectIdsRef = useRef<Set<string>>(new Set());
  const hydratingRef = useRef(false);
  const handledSyncRequestTokensRef = useRef<Map<string, number>>(new Map());

  const syncProjectNow = useCallback(
    async (projectId: string, options?: { keepalive?: boolean }) => {
      if (syncingProjectIdsRef.current.has(projectId) || pendingDeletes.includes(projectId)) {
        return;
      }

      const currentState = useLoreLoomStore.getState();
      const syncMeta = currentState.sync.projects[projectId];
      if (!syncMeta?.dirty || syncMeta.status === 'conflict') {
        return;
      }

      const bundleState = currentState.getProjectBundle(projectId);
      const project = bundleState?.projects[0];
      if (!bundleState || !project) {
        return;
      }

      syncingProjectIdsRef.current.add(projectId);
      recordDiagnosticEvent({
        type: 'sync_started',
        projectId,
        status: 'syncing',
      });
      const syncedChangeToken = markProjectSyncing(projectId);
      const baseRevision = useLoreLoomStore.getState().sync.projects[projectId]?.serverRevision ?? 0;

      try {
        const result = await uploadProjectBundle(
          projectId,
          baseRevision,
          {
            project,
            structureNodes: bundleState.structureNodes,
            scenes: bundleState.scenes,
            codexNodes: bundleState.codexNodes,
            codexEntries: bundleState.codexEntries,
            revisionSnapshots: bundleState.revisionSnapshots,
          },
          options,
        );
        setBackendStatus('online');
        markProjectSyncSuccess(projectId, result.serverRevision, new Date().toISOString(), syncedChangeToken);
        recordDiagnosticEvent({
          type: 'sync_succeeded',
          projectId,
          status: 'ok',
        });
      } catch (error) {
        if (error instanceof ApiClientError && error.status === 409) {
          setBackendStatus('online');
          markProjectSyncConflict(projectId);
          recordDiagnosticEvent({
            type: 'sync_conflict',
            projectId,
            status: 'conflict',
            message: 'Backend revision conflict detected.',
          });
        } else {
          markProjectSyncOffline(projectId, error instanceof Error ? error.message : undefined);
          recordDiagnosticEvent({
            type: 'sync_offline',
            projectId,
            status: 'offline',
            message: error instanceof Error ? error.message : 'Backend unavailable during project sync.',
          });
        }
      } finally {
        syncingProjectIdsRef.current.delete(projectId);
      }
    },
    [
      clearPendingDelete,
      markProjectSyncConflict,
      markProjectSyncOffline,
      markProjectSyncSuccess,
      markProjectSyncing,
      pendingDeletes,
      recordDiagnosticEvent,
      setBackendStatus,
    ],
  );

  const flushPendingDeletes = useCallback(
    async (options?: { keepalive?: boolean }) => {
      const deletes = [...useLoreLoomStore.getState().sync.pendingDeletes];

      for (const projectId of deletes) {
        if (deletingProjectIdsRef.current.has(projectId)) {
          continue;
        }

        deletingProjectIdsRef.current.add(projectId);
        recordDiagnosticEvent({
          type: 'delete_sync_started',
          projectId,
          status: 'syncing',
        });
        try {
          await deleteRemoteProject(projectId, options);
          setBackendStatus('online');
          clearPendingDelete(projectId);
          recordDiagnosticEvent({
            type: 'delete_sync_succeeded',
            projectId,
            status: 'ok',
          });
        } catch (error) {
          setBackendStatus('offline');
          recordDiagnosticEvent({
            type: 'delete_sync_failed',
            projectId,
            status: 'error',
            message: error instanceof Error ? error.message : 'Backend unavailable during project delete sync.',
          });
          if (error instanceof ApiClientError && error.status && error.status >= 400 && error.status < 500) {
            clearPendingDelete(projectId);
          }
        } finally {
          deletingProjectIdsRef.current.delete(projectId);
        }
      }
    },
    [clearPendingDelete, recordDiagnosticEvent, setBackendStatus],
  );

  const hydrateFromBackend = useCallback(async () => {
    if (hydratingRef.current) {
      return;
    }

    hydratingRef.current = true;
    setHydrationState('hydrating');
    recordDiagnosticEvent({
      type: 'backend_hydration_started',
      status: 'syncing',
    });

    try {
      const summaries = await listProjectSummaries();
      setBackendStatus('online');

      for (const summary of summaries) {
        const currentState = useLoreLoomStore.getState();
        const syncMeta = currentState.sync.projects[summary.id];
        const hasLocalProject = currentState.projects.some((project) => project.id === summary.id);
        const pendingDelete = currentState.sync.pendingDeletes.includes(summary.id);

        if (pendingDelete || syncMeta?.dirty || syncMeta?.status === 'conflict' || syncMeta?.status === 'syncing') {
          continue;
        }

        if (hasLocalProject && syncMeta?.serverRevision === summary.serverRevision) {
          continue;
        }

        const bundle = await fetchProjectBundle(summary.id);
        applyRemoteProjectBundle(bundleToProjectState(bundle), summary.id, bundle.serverRevision);
      }
      recordDiagnosticEvent({
        type: 'backend_hydration_succeeded',
        status: 'ok',
      });
    } catch {
      setBackendStatus('offline');
      recordDiagnosticEvent({
        type: 'backend_hydration_failed',
        status: 'error',
        message: 'Backend hydration could not complete.',
      });
    } finally {
      setHydrationState('ready');
      hydratingRef.current = false;
    }
  }, [applyRemoteProjectBundle, recordDiagnosticEvent, setBackendStatus, setHydrationState]);

  const flushAllDirtyProjects = useCallback(
    async (options?: { keepalive?: boolean }) => {
      const currentDirtyProjectIds = [...dirtyProjectIds];
      for (const projectId of currentDirtyProjectIds) {
        await syncProjectNow(projectId, options);
      }
    },
    [dirtyProjectIds, syncProjectNow],
  );

  useEffect(() => {
    void hydrateFromBackend();
  }, [hydrateFromBackend]);

  useEffect(() => {
    for (const [projectId, timerId] of syncTimersRef.current.entries()) {
      if (!dirtyProjectIds.includes(projectId)) {
        window.clearTimeout(timerId);
        syncTimersRef.current.delete(projectId);
      }
    }

    for (const projectId of dirtyProjectIds) {
      const syncMeta = projectSync[projectId];
      if (!syncMeta || syncMeta.status === 'syncing' || syncMeta.status === 'conflict') {
        continue;
      }

      const existingTimer = syncTimersRef.current.get(projectId);
      if (existingTimer) {
        window.clearTimeout(existingTimer);
      }

      const timerId = window.setTimeout(() => {
        syncTimersRef.current.delete(projectId);
        void syncProjectNow(projectId);
      }, PROJECT_SYNC_DEBOUNCE_MS);

      syncTimersRef.current.set(projectId, timerId);
    }

    return () => {
      for (const timerId of syncTimersRef.current.values()) {
        window.clearTimeout(timerId);
      }
      syncTimersRef.current.clear();
    };
  }, [dirtyProjectIds, projectSync, syncProjectNow]);

  useEffect(() => {
    const activeProjectIds = new Set(projects.map((project) => project.id));

    for (const [projectId] of handledSyncRequestTokensRef.current.entries()) {
      if (!activeProjectIds.has(projectId)) {
        handledSyncRequestTokensRef.current.delete(projectId);
      }
    }

    for (const projectId of activeProjectIds) {
      const syncMeta = projectSync[projectId];
      if (!syncMeta?.dirty || syncMeta.status === 'conflict') {
        continue;
      }

      const handledToken = handledSyncRequestTokensRef.current.get(projectId) ?? 0;
      if (syncMeta.syncRequestToken <= handledToken) {
        continue;
      }

      handledSyncRequestTokensRef.current.set(projectId, syncMeta.syncRequestToken);
      recordDiagnosticEvent({
        type: 'sync_requested',
        projectId,
        status: syncMeta.status,
      });

      const existingTimer = syncTimersRef.current.get(projectId);
      if (existingTimer) {
        window.clearTimeout(existingTimer);
        syncTimersRef.current.delete(projectId);
      }

      void syncProjectNow(projectId);
    }
  }, [projectSync, projects, recordDiagnosticEvent, syncProjectNow]);

  useEffect(() => {
    if (pendingDeletes.length === 0) {
      return;
    }

    void flushPendingDeletes();
  }, [flushPendingDeletes, pendingDeletes]);

  useEffect(() => {
    const handleOnline = () => {
      void hydrateFromBackend();
      void flushPendingDeletes();
      void flushAllDirtyProjects();
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState !== 'visible') {
        return;
      }

      void hydrateFromBackend();
      void flushPendingDeletes();
      void flushAllDirtyProjects();
    };

    const handlePageHide = () => {
      void flushPendingDeletes({ keepalive: true });
      void flushAllDirtyProjects({ keepalive: true });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('focus', handleOnline);
    window.addEventListener('pagehide', handlePageHide);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('focus', handleOnline);
      window.removeEventListener('pagehide', handlePageHide);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [flushAllDirtyProjects, flushPendingDeletes, hydrateFromBackend]);

  return null;
}
