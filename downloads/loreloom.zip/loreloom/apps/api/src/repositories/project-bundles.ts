import type { SqliteDatabase } from '../db/pragmas.js';
import type {
  CodexEntry,
  CodexNode,
  Project,
  ProjectBundle,
  ProjectBundleWithRevision,
  ProjectSummary,
  RevisionSnapshot,
  Scene,
  StructureNode,
} from '../validators/project-bundle.js';

const DEFAULT_CODEX_NODE_TITLE = 'Codex';
const DEFAULT_CODEX_NODE_TYPE = 'codex';

type ProjectRow = {
  id: string;
  owner_user_id: string | null;
  name: string;
  server_revision: number;
  created_at: string;
  updated_at: string;
};

type StructureNodeRow = {
  id: string;
  project_id: string;
  parent_id: string | null;
  type: StructureNode['type'];
  custom_type_label: string | null;
  title: string;
  order_index: number;
  created_at: string;
  updated_at: string;
};

type SceneRow = {
  id: string;
  project_id: string;
  structure_node_id: string;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
};

type CodexNodeRow = {
  id: string;
  project_id: string;
  parent_id: string | null;
  type: CodexNode['type'];
  title: string;
  custom_type_label: string | null;
  tags_json: string;
  order_index: number;
  created_at: string;
  updated_at: string;
};

type CodexEntryRow = {
  id: string;
  project_id: string;
  codex_node_id: string | null;
  title: string;
  type: CodexEntry['type'];
  content: string;
  tags_json: string;
  created_at: string;
  updated_at: string;
};

type RevisionSnapshotRow = {
  id: string;
  scene_id: string;
  project_id: string;
  title: string;
  content: string;
  created_at: string;
};

function mapProjectRow(row: ProjectRow): ProjectSummary {
  return {
    id: row.id,
    name: row.name,
    serverRevision: row.server_revision,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mapProjectForBundle(row: ProjectRow): Project {
  return {
    id: row.id,
    name: row.name,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mapStructureNodeRow(row: StructureNodeRow): StructureNode {
  return {
    id: row.id,
    projectId: row.project_id,
    parentId: row.parent_id,
    type: row.type,
    customTypeLabel: row.custom_type_label,
    title: row.title,
    orderIndex: row.order_index,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mapSceneRow(row: SceneRow): Scene {
  return {
    id: row.id,
    projectId: row.project_id,
    structureNodeId: row.structure_node_id,
    title: row.title,
    content: row.content,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mapCodexNodeRow(row: CodexNodeRow): CodexNode {
  let tags: string[] = [];

  try {
    const parsed = JSON.parse(row.tags_json) as unknown;
    if (Array.isArray(parsed) && parsed.every((tag) => typeof tag === 'string')) {
      tags = parsed;
    }
  } catch {
    tags = [];
  }

  return {
    id: row.id,
    projectId: row.project_id,
    parentId: row.parent_id,
    type: row.type,
    title: row.title,
    customTypeLabel: row.custom_type_label,
    tags,
    orderIndex: row.order_index,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mapCodexEntryRow(row: CodexEntryRow): CodexEntry {
  let tags: string[] = [];

  try {
    const parsed = JSON.parse(row.tags_json) as unknown;
    if (Array.isArray(parsed) && parsed.every((tag) => typeof tag === 'string')) {
      tags = parsed;
    }
  } catch {
    tags = [];
  }

  return {
    id: row.id,
    projectId: row.project_id,
    codexNodeId: row.codex_node_id,
    title: row.title,
    type: row.type,
    content: row.content,
    tags,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function createDefaultCodexNode(project: Pick<ProjectRow, 'id' | 'created_at' | 'updated_at'>): CodexNode {
  return {
    id: `codex-root:${project.id}`,
    projectId: project.id,
    parentId: null,
    type: DEFAULT_CODEX_NODE_TYPE,
    title: DEFAULT_CODEX_NODE_TITLE,
    customTypeLabel: null,
    tags: [],
    orderIndex: 0,
    createdAt: project.created_at,
    updatedAt: project.updated_at,
  };
}

function normalizeBundleCodex(project: Project, bundle: Pick<ProjectBundle, 'codexNodes' | 'codexEntries'>) {
  const providedNodes = bundle.codexNodes
    .filter((node) => node.projectId === project.id)
    .map((node) => ({
      ...node,
      parentId: node.parentId ?? null,
      customTypeLabel: node.customTypeLabel ?? null,
      tags: Array.isArray(node.tags) ? node.tags : [],
    }));
  const defaultNode =
    providedNodes[0] ??
    ({
      id: `codex-root:${project.id}`,
      projectId: project.id,
      parentId: null,
      type: DEFAULT_CODEX_NODE_TYPE,
      title: DEFAULT_CODEX_NODE_TITLE,
      customTypeLabel: null,
      tags: [],
      orderIndex: 0,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt,
    } satisfies CodexNode);

  const nodes = providedNodes.length > 0 ? providedNodes : [defaultNode];
  const validNodeIds = new Set(nodes.map((node) => node.id));

  return {
    codexNodes: nodes.map((node) => ({
      ...node,
      parentId: node.parentId && node.parentId !== node.id && validNodeIds.has(node.parentId) ? node.parentId : null,
    })),
    codexEntries: bundle.codexEntries.map((entry) => ({
      ...entry,
      codexNodeId: entry.codexNodeId && validNodeIds.has(entry.codexNodeId) ? entry.codexNodeId : defaultNode.id,
      tags: Array.isArray(entry.tags) ? entry.tags : [],
    })),
  };
}

function ensureLegacyCodexNodes(database: SqliteDatabase, project: ProjectRow) {
  const defaultNodeId = `codex-root:${project.id}`;
  const codexState = database
    .prepare(
      `
        SELECT
          EXISTS(
            SELECT 1
            FROM codex_entries
            WHERE project_id = ?
            LIMIT 1
          ) AS has_entries,
          EXISTS(
            SELECT 1
            FROM codex_entries
            WHERE project_id = ? AND codex_node_id IS NULL
            LIMIT 1
          ) AS has_unassigned_entries,
          EXISTS(
            SELECT 1
            FROM codex_nodes
            WHERE project_id = ?
            LIMIT 1
          ) AS has_nodes
      `,
    )
    .get(project.id, project.id, project.id) as {
      has_entries: number;
      has_unassigned_entries: number;
      has_nodes: number;
    };

  if (!codexState.has_entries || (codexState.has_nodes && !codexState.has_unassigned_entries)) {
    return null;
  }

  database
    .prepare(
      `
        INSERT INTO codex_nodes (
          id,
          project_id,
          parent_id,
          type,
          title,
          custom_type_label,
          tags_json,
          order_index,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO NOTHING
      `,
    )
    .run(
      defaultNodeId,
      project.id,
      null,
      DEFAULT_CODEX_NODE_TYPE,
      DEFAULT_CODEX_NODE_TITLE,
      null,
      JSON.stringify([]),
      0,
      project.created_at,
      project.updated_at,
    );

  database
    .prepare(
      `
        UPDATE codex_entries
        SET codex_node_id = ?
        WHERE project_id = ? AND codex_node_id IS NULL
      `,
    )
    .run(defaultNodeId, project.id);

  return defaultNodeId;
}

function mapRevisionSnapshotRow(row: RevisionSnapshotRow): RevisionSnapshot {
  return {
    id: row.id,
    sceneId: row.scene_id,
    projectId: row.project_id,
    title: row.title,
    content: row.content,
    createdAt: row.created_at,
  };
}

export function listProjectSummaries(database: SqliteDatabase): ProjectSummary[] {
  const rows = database
    .prepare(
      `
        SELECT id, owner_user_id, name, server_revision, created_at, updated_at
        FROM projects
        ORDER BY updated_at DESC, created_at DESC, id DESC
      `,
    )
    .all() as ProjectRow[];

  return rows.map(mapProjectRow);
}

export type ProjectOwnershipState = 'missing' | 'unowned' | 'owned_by_user' | 'owned_by_other';

export function getProjectOwnershipState(
  database: SqliteDatabase,
  projectId: string,
  ownerUserId: string,
): ProjectOwnershipState {
  const row = database
    .prepare(
      `
        SELECT owner_user_id
        FROM projects
        WHERE id = ?
      `,
    )
    .get(projectId) as Pick<ProjectRow, 'owner_user_id'> | undefined;

  if (!row) {
    return 'missing';
  }

  if (row.owner_user_id === null) {
    return 'unowned';
  }

  return row.owner_user_id === ownerUserId ? 'owned_by_user' : 'owned_by_other';
}

export function assignUnownedProjectsToOwner(database: SqliteDatabase, ownerUserId: string): number {
  const result = database
    .prepare(
      `
        UPDATE projects
        SET owner_user_id = ?
        WHERE owner_user_id IS NULL
      `,
    )
    .run(ownerUserId);

  return result.changes;
}

export function listOwnedProjectSummaries(database: SqliteDatabase, ownerUserId: string): ProjectSummary[] {
  const rows = database
    .prepare(
      `
        SELECT id, owner_user_id, name, server_revision, created_at, updated_at
        FROM projects
        WHERE owner_user_id = ?
        ORDER BY updated_at DESC, created_at DESC, id DESC
      `,
    )
    .all(ownerUserId) as ProjectRow[];

  return rows.map(mapProjectRow);
}

export function getProjectBundle(
  database: SqliteDatabase,
  projectId: string,
): ProjectBundleWithRevision | null {
  const projectRow = database
    .prepare(
      `
        SELECT id, owner_user_id, name, server_revision, created_at, updated_at
        FROM projects
        WHERE id = ?
      `,
    )
    .get(projectId) as ProjectRow | undefined;

  if (!projectRow) {
    return null;
  }

  ensureLegacyCodexNodes(database, projectRow);

  const structureNodes = (
    database
      .prepare(
        `
          SELECT id, project_id, parent_id, type, custom_type_label, title, order_index, created_at, updated_at
          FROM structure_nodes
          WHERE project_id = ?
          ORDER BY order_index ASC, created_at ASC, id ASC
        `,
      )
      .all(projectId) as StructureNodeRow[]
  ).map(mapStructureNodeRow);

  const scenes = (
    database
      .prepare(
        `
          SELECT id, project_id, structure_node_id, title, content, created_at, updated_at
          FROM text_blocks
          WHERE project_id = ?
          ORDER BY created_at ASC, id ASC
        `,
      )
      .all(projectId) as SceneRow[]
  ).map(mapSceneRow);

  const codexNodes = (
    database
      .prepare(
        `
          SELECT id, project_id, parent_id, type, title, custom_type_label, tags_json, order_index, created_at, updated_at
          FROM codex_nodes
          WHERE project_id = ?
          ORDER BY parent_id IS NOT NULL ASC, parent_id ASC, order_index ASC, created_at ASC, id ASC
        `,
      )
      .all(projectId) as CodexNodeRow[]
  ).map(mapCodexNodeRow);

  const codexEntries = (
    database
      .prepare(
        `
          SELECT id, project_id, codex_node_id, title, type, content, tags_json, created_at, updated_at
          FROM codex_entries
          WHERE project_id = ?
          ORDER BY updated_at DESC, created_at DESC, id DESC
        `,
      )
      .all(projectId) as CodexEntryRow[]
  ).map(mapCodexEntryRow);

  const revisionSnapshots = (
    database
      .prepare(
        `
          SELECT id, scene_id, project_id, title, content, created_at
          FROM revision_snapshots
          WHERE project_id = ?
          ORDER BY created_at DESC, id DESC
        `,
      )
      .all(projectId) as RevisionSnapshotRow[]
  ).map(mapRevisionSnapshotRow);

  return {
    project: mapProjectForBundle(projectRow),
    serverRevision: projectRow.server_revision,
    structureNodes,
    scenes,
    codexNodes,
    codexEntries,
    revisionSnapshots,
  };
}

export function getOwnedProjectBundle(
  database: SqliteDatabase,
  projectId: string,
  ownerUserId: string,
): ProjectBundleWithRevision | null {
  const projectRow = database
    .prepare(
      `
        SELECT id, owner_user_id, name, server_revision, created_at, updated_at
        FROM projects
        WHERE id = ? AND owner_user_id = ?
      `,
    )
    .get(projectId, ownerUserId) as ProjectRow | undefined;

  if (!projectRow) {
    return null;
  }

  ensureLegacyCodexNodes(database, projectRow);

  const structureNodes = (
    database
      .prepare(
        `
          SELECT id, project_id, parent_id, type, custom_type_label, title, order_index, created_at, updated_at
          FROM structure_nodes
          WHERE project_id = ?
          ORDER BY order_index ASC, created_at ASC, id ASC
        `,
      )
      .all(projectId) as StructureNodeRow[]
  ).map(mapStructureNodeRow);

  const scenes = (
    database
      .prepare(
        `
          SELECT id, project_id, structure_node_id, title, content, created_at, updated_at
          FROM text_blocks
          WHERE project_id = ?
          ORDER BY created_at ASC, id ASC
        `,
      )
      .all(projectId) as SceneRow[]
  ).map(mapSceneRow);

  const codexNodes = (
    database
      .prepare(
        `
          SELECT id, project_id, parent_id, type, title, custom_type_label, tags_json, order_index, created_at, updated_at
          FROM codex_nodes
          WHERE project_id = ?
          ORDER BY parent_id IS NOT NULL ASC, parent_id ASC, order_index ASC, created_at ASC, id ASC
        `,
      )
      .all(projectId) as CodexNodeRow[]
  ).map(mapCodexNodeRow);

  const codexEntries = (
    database
      .prepare(
        `
          SELECT id, project_id, codex_node_id, title, type, content, tags_json, created_at, updated_at
          FROM codex_entries
          WHERE project_id = ?
          ORDER BY updated_at DESC, created_at DESC, id DESC
        `,
      )
      .all(projectId) as CodexEntryRow[]
  ).map(mapCodexEntryRow);

  const revisionSnapshots = (
    database
      .prepare(
        `
          SELECT id, scene_id, project_id, title, content, created_at
          FROM revision_snapshots
          WHERE project_id = ?
          ORDER BY created_at DESC, id DESC
        `,
      )
      .all(projectId) as RevisionSnapshotRow[]
  ).map(mapRevisionSnapshotRow);

  return {
    project: mapProjectForBundle(projectRow),
    serverRevision: projectRow.server_revision,
    structureNodes,
    scenes,
    codexNodes,
    codexEntries,
    revisionSnapshots,
  };
}

export function replaceProjectBundle(
  database: SqliteDatabase,
  bundle: ProjectBundle,
  ownerUserId: string,
  serverRevision: number,
) {
  const transaction = database.transaction(() => {
    const normalizedCodex = normalizeBundleCodex(bundle.project, bundle);

    database.prepare('DELETE FROM projects WHERE id = ? AND owner_user_id = ?').run(bundle.project.id, ownerUserId);

    database
      .prepare(
        `
          INSERT INTO projects (id, owner_user_id, name, server_revision, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?)
        `,
      )
      .run(
        bundle.project.id,
        ownerUserId,
        bundle.project.name,
        serverRevision,
        bundle.project.createdAt,
        bundle.project.updatedAt,
      );

    const insertStructureNode = database.prepare(
      `
        INSERT INTO structure_nodes (
          id,
          project_id,
          parent_id,
          type,
          custom_type_label,
          title,
          order_index,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
    );

    for (const node of bundle.structureNodes) {
      insertStructureNode.run(
        node.id,
        node.projectId,
        node.parentId,
        node.type,
        node.customTypeLabel,
        node.title,
        node.orderIndex,
        node.createdAt,
        node.updatedAt,
      );
    }

    const insertScene = database.prepare(
      `
        INSERT INTO text_blocks (
          id,
          project_id,
          structure_node_id,
          title,
          content,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `,
    );

    for (const scene of bundle.scenes) {
      insertScene.run(
        scene.id,
        scene.projectId,
        scene.structureNodeId,
        scene.title,
        scene.content,
        scene.createdAt,
        scene.updatedAt,
      );
    }

    const insertCodexNode = database.prepare(
      `
        INSERT INTO codex_nodes (
          id,
          project_id,
          parent_id,
          type,
          title,
          custom_type_label,
          tags_json,
          order_index,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
    );

    for (const codexNode of normalizedCodex.codexNodes) {
      insertCodexNode.run(
        codexNode.id,
        codexNode.projectId,
        codexNode.parentId,
        codexNode.type,
        codexNode.title,
        codexNode.customTypeLabel,
        JSON.stringify(codexNode.tags),
        codexNode.orderIndex,
        codexNode.createdAt,
        codexNode.updatedAt,
      );
    }

    const insertCodexEntry = database.prepare(
      `
        INSERT INTO codex_entries (
          id,
          project_id,
          codex_node_id,
          title,
          type,
          content,
          tags_json,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
    );

    for (const codexEntry of bundle.codexEntries) {
      insertCodexEntry.run(
        codexEntry.id,
        codexEntry.projectId,
        codexEntry.codexNodeId,
        codexEntry.title,
        codexEntry.type,
        codexEntry.content,
        JSON.stringify(Array.isArray(codexEntry.tags) ? codexEntry.tags : []),
        codexEntry.createdAt,
        codexEntry.updatedAt,
      );
    }

    const insertSnapshot = database.prepare(
      `
        INSERT INTO revision_snapshots (
          id,
          scene_id,
          project_id,
          title,
          content,
          created_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
      `,
    );

    for (const snapshot of bundle.revisionSnapshots) {
      insertSnapshot.run(
        snapshot.id,
        snapshot.sceneId,
        snapshot.projectId,
        snapshot.title,
        snapshot.content,
        snapshot.createdAt,
      );
    }
  });

  transaction();
}

export function deleteOwnedProjectBundle(database: SqliteDatabase, projectId: string, ownerUserId: string): boolean {
  let deleted = false;
  const transaction = database.transaction(() => {
    const result = database.prepare('DELETE FROM projects WHERE id = ? AND owner_user_id = ?').run(projectId, ownerUserId);
    deleted = result.changes > 0;
  });

  transaction();

  return deleted;
}
