import { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import { buildStructureNodeTree, getStructureNodeTypeLabel, type StructureNodeTreeItem } from '../lib/structure';
import { useLoreLoomStore } from '../store/useLoreLoomStore';

function TextBlockSection({
  node,
  depth,
  textBlocksByNodeId,
}: {
  node: StructureNodeTreeItem;
  depth: number;
  textBlocksByNodeId: Map<string, Array<{ id: string; title: string; content: string }>>;
}) {
  const textBlocks = textBlocksByNodeId.get(node.id) ?? [];
  const headingClassName =
    depth === 0
      ? 'text-3xl font-semibold tracking-tight text-white'
      : depth === 1
        ? 'text-2xl font-semibold tracking-tight text-white'
        : depth === 2
          ? 'text-xl font-semibold tracking-tight text-white'
          : 'text-lg font-semibold tracking-tight text-white';

  return (
    <section className="writing-body space-y-6">
      <header className="space-y-2">
        <p className="text-xs uppercase tracking-[0.18em] text-slate-500">{getStructureNodeTypeLabel(node)}</p>
        <h2 className={headingClassName}>{node.title}</h2>
      </header>

      {textBlocks.length > 0 ? (
        <div className="writing-column space-y-8">
          {textBlocks.map((textBlock) => (
            <article key={textBlock.id} className="writing-reading-surface space-y-4">
              <h3 className="text-xl font-medium tracking-tight text-slate-100">{textBlock.title}</h3>
              <div
                className="prose prose-invert max-w-none prose-headings:text-white prose-p:text-slate-200 prose-strong:text-white prose-li:text-slate-200"
                dangerouslySetInnerHTML={{ __html: textBlock.content || '<p>No content yet.</p>' }}
              />
            </article>
          ))}
        </div>
      ) : null}

      {node.children.length > 0 ? (
        <div className="space-y-10 border-l border-[color:var(--app-border)] pl-5">
          {node.children.map((child) => (
            <TextBlockSection key={child.id} node={child} depth={depth + 1} textBlocksByNodeId={textBlocksByNodeId} />
          ))}
        </div>
      ) : null}
    </section>
  );
}

export default function ProjectPreviewPage() {
  const { projectId } = useParams();
  const projects = useLoreLoomStore((state) => state.projects);
  const structureNodes = useLoreLoomStore((state) => state.structureNodes);
  const scenes = useLoreLoomStore((state) => state.scenes);

  const project = useMemo(
    () => (projectId ? projects.find((entry) => entry.id === projectId) : undefined),
    [projectId, projects],
  );

  const projectStructureNodes = useMemo(() => {
    if (!projectId) {
      return [];
    }

    return structureNodes
      .filter((node) => node.projectId === projectId)
      .sort((left, right) => {
        if (left.parentId !== right.parentId) {
          if (left.parentId === null) {
            return -1;
          }
          if (right.parentId === null) {
            return 1;
          }

          const parentCompare = left.parentId.localeCompare(right.parentId);
          if (parentCompare !== 0) {
            return parentCompare;
          }
        }

        if (left.orderIndex !== right.orderIndex) {
          return left.orderIndex - right.orderIndex;
        }

        const createdCompare = left.createdAt.localeCompare(right.createdAt);
        if (createdCompare !== 0) {
          return createdCompare;
        }

        return left.id.localeCompare(right.id);
      });
  }, [projectId, structureNodes]);

  const projectTextBlocks = useMemo(() => {
    if (!projectId) {
      return [];
    }

    return scenes
      .filter((scene) => scene.projectId === projectId)
      .sort((left, right) => {
        const updated = right.updatedAt.localeCompare(left.updatedAt);
        if (updated !== 0) {
          return updated;
        }

        return right.createdAt.localeCompare(left.createdAt);
      });
  }, [projectId, scenes]);

  const structureTree = useMemo(
    () => buildStructureNodeTree(projectStructureNodes),
    [projectStructureNodes],
  );

  const textBlocksByNodeId = useMemo(() => {
    const nodeIds = new Set(projectStructureNodes.map((node) => node.id));
    const fallbackNodeId = projectStructureNodes[0]?.id;
    const grouped = new Map<string, Array<{ id: string; title: string; content: string }>>();

    for (const textBlock of projectTextBlocks) {
      const key = nodeIds.has(textBlock.structureNodeId) ? textBlock.structureNodeId : fallbackNodeId;
      if (!key) {
        continue;
      }

      const list = grouped.get(key) ?? [];
      list.push({
        id: textBlock.id,
        title: textBlock.title,
        content: textBlock.content,
      });
      grouped.set(key, list);
    }

    return grouped;
  }, [projectStructureNodes, projectTextBlocks]);

  if (!project) {
    return (
      <div className="app-panel rounded-3xl p-8 text-slate-300">
        <h2 className="text-lg font-medium text-white">Project preview not found</h2>
        <p className="mt-2 text-sm leading-6 text-slate-300">
          This project may have been deleted or the link may be outdated.
        </p>
        <Link to="/" className="app-link mt-4 inline-flex underline underline-offset-4">
          Return to dashboard
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link to={`/projects/${project.id}`} className="app-link text-sm underline underline-offset-4">
          Back to project
        </Link>
        <span className="text-sm text-slate-400">Read-only preview</span>
      </div>

      <section className="app-panel-inset rounded-3xl px-6 py-8 sm:px-10">
        <header className="border-b border-[color:var(--app-border)] pb-6">
          <p className="text-sm uppercase tracking-[0.18em] text-slate-500">Book Preview</p>
          <h1 className="mt-3 text-4xl font-semibold tracking-tight text-white">{project.name}</h1>
        </header>

        {structureTree.length === 0 ? (
          <div className="py-10 text-slate-300">
            <h2 className="text-xl font-medium text-white">Nothing to preview yet</h2>
            <p className="mt-3 text-sm leading-6 text-slate-300">
              Add structure nodes and text blocks to generate a reading preview for this project.
            </p>
          </div>
        ) : (
          <div className="space-y-12 py-10">
            {structureTree.map((node) => (
              <TextBlockSection key={node.id} node={node} depth={0} textBlocksByNodeId={textBlocksByNodeId} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
