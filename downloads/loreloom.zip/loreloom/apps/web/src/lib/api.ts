import type { LoreLoomState, Project } from './types';

export const API_UNAUTHORIZED_EVENT = 'loreloom:api-unauthorized';

export type ApiCodexEntry = Omit<LoreLoomState['codexEntries'][number], 'codexNodeId'> & {
  codexNodeId?: string;
};

export type ApiProjectSummary = Project & {
  serverRevision: number;
};

export type AuthenticatedUser = {
  id: string;
  username: string;
  displayName: string | null;
  role: 'admin' | 'user';
};

export type AdminUserSummary = {
  id: string;
  username: string;
  displayName: string | null;
  role: 'admin' | 'user';
  createdAt: string;
  updatedAt: string;
};

export type SetupStatusResponse = {
  setupRequired: boolean;
};

export type SetupAdminRequest = {
  username: string;
  password: string;
  passwordConfirmation?: string;
  displayName?: string;
};

export type LoginRequest = {
  username: string;
  password: string;
};

export type ChangePasswordRequest = {
  currentPassword: string;
  newPassword: string;
  passwordConfirmation: string;
};

export type CreateAdminManagedUserRequest = {
  username: string;
  displayName?: string;
  role: 'admin' | 'user';
};

export type AuthSessionResponse =
  | {
      authenticated: false;
    }
  | {
      authenticated: true;
      user: AuthenticatedUser;
    };

export type ApiProjectBundlePayload = {
  project: Project;
  structureNodes: LoreLoomState['structureNodes'];
  scenes: LoreLoomState['scenes'];
  codexNodes: LoreLoomState['codexNodes'];
  codexEntries: LoreLoomState['codexEntries'];
  revisionSnapshots: LoreLoomState['revisionSnapshots'];
};

export type ApiProjectBundleResponse = {
  project: Project;
  structureNodes: LoreLoomState['structureNodes'];
  scenes: LoreLoomState['scenes'];
  codexNodes: LoreLoomState['codexNodes'];
  codexEntries: ApiCodexEntry[];
  revisionSnapshots: LoreLoomState['revisionSnapshots'];
  serverRevision: number;
};

export type PutProjectBundleResponse = {
  ok: true;
  serverRevision: number;
  updatedAt: string;
};

export type CreateAdminManagedUserResponse = {
  user: AdminUserSummary;
  temporaryPassword: string;
};

export type ResetAdminUserPasswordResponse = {
  user: AdminUserSummary;
  temporaryPassword: string;
};

export type BackendHealthResponse = {
  status: string;
  appName: string;
  timestamp: string;
};

export type BackendDiagnosticsExportResponse = {
  format: 'LoreLoom Diagnostic Bundle';
  version: number;
  generatedAt: string;
  diagnosticsEnabled: boolean;
  backend: {
    appName: string;
    appVersion: string;
    status: string;
    health: BackendHealthResponse;
    config: {
      nodeEnv: string;
      logLevel: string;
      maxRequestBodyBytes: number;
      databasePath: string;
      devCorsOriginConfigured: boolean;
    };
  };
};

export type RevisionConflictResponse = {
  error: 'revision_conflict';
  serverRevision: number;
  bundle: ApiProjectBundleResponse;
};

export class ApiClientError extends Error {
  status: number | null;
  data: unknown;

  constructor(message: string, options?: { status?: number | null; data?: unknown }) {
    super(message);
    this.name = 'ApiClientError';
    this.status = options?.status ?? null;
    this.data = options?.data;
  }
}

function resolveApiUrl(path: string) {
  const configuredBase = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.trim().replace(/\/$/, '') ?? '';
  return `${configuredBase}${path}`;
}

async function parseJsonResponse(response: Response) {
  const text = await response.text();
  if (!text) {
    return null;
  }

  try {
    return JSON.parse(text) as unknown;
  } catch {
    return text;
  }
}

async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;

  try {
    response = await fetch(resolveApiUrl(path), {
      credentials: 'include',
      ...init,
      headers: {
        Accept: 'application/json',
        ...(init?.body ? { 'Content-Type': 'application/json' } : {}),
        ...init?.headers,
      },
    });
  } catch (error) {
    throw new ApiClientError(error instanceof Error ? error.message : 'Could not reach the LoreLoom API.');
  }

  const data = await parseJsonResponse(response);

  if (!response.ok) {
    if (response.status === 401 && path !== '/api/auth/login' && typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent(API_UNAUTHORIZED_EVENT, {
          detail: {
            path,
            method: init?.method ?? 'GET',
          },
        }),
      );
    }

    const message =
      typeof data === 'object' && data !== null && 'message' in data && typeof data.message === 'string'
        ? data.message
        : `Request failed with status ${response.status}.`;
    throw new ApiClientError(message, {
      status: response.status,
      data,
    });
  }

  return data as T;
}

export async function listProjectSummaries() {
  const response = await requestJson<{ projects: ApiProjectSummary[] }>('/api/projects');
  return response.projects;
}

export async function fetchSetupStatus() {
  return requestJson<SetupStatusResponse>('/api/setup/status');
}

export async function createFirstAdminAccount(payload: SetupAdminRequest) {
  return requestJson<Extract<AuthSessionResponse, { authenticated: true }>>('/api/setup/admin', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function loginWithPassword(payload: LoginRequest) {
  return requestJson<Extract<AuthSessionResponse, { authenticated: true }>>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function logoutCurrentSession() {
  return requestJson<{ authenticated: false; ok: true }>('/api/auth/logout', {
    method: 'POST',
  });
}

export async function fetchCurrentAuthSession() {
  return requestJson<AuthSessionResponse>('/api/auth/me');
}

export async function changePassword(payload: ChangePasswordRequest) {
  return requestJson<Extract<AuthSessionResponse, { authenticated: true }>>('/api/auth/change-password', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function fetchAdminUsers() {
  return requestJson<{ users: AdminUserSummary[] }>('/api/admin/users');
}

export async function createAdminManagedUser(payload: CreateAdminManagedUserRequest) {
  return requestJson<CreateAdminManagedUserResponse>('/api/admin/users', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function resetAdminManagedUserPassword(userId: string) {
  return requestJson<ResetAdminUserPasswordResponse>(`/api/admin/users/${userId}/reset-password`, {
    method: 'POST',
  });
}

export async function fetchBackendHealth() {
  return requestJson<BackendHealthResponse>('/health');
}

export async function fetchBackendDiagnosticsExport() {
  return requestJson<BackendDiagnosticsExportResponse>('/api/diagnostics/export');
}

export async function fetchProjectBundle(projectId: string) {
  return requestJson<ApiProjectBundleResponse>(`/api/projects/${projectId}/bundle`);
}

export async function uploadProjectBundle(
  projectId: string,
  baseRevision: number,
  bundle: ApiProjectBundlePayload,
  options?: { keepalive?: boolean },
) {
  return requestJson<PutProjectBundleResponse>(`/api/projects/${projectId}/bundle`, {
    method: 'PUT',
    body: JSON.stringify({
      baseRevision,
      bundle,
    }),
    keepalive: options?.keepalive,
  });
}

export async function deleteRemoteProject(projectId: string, options?: { keepalive?: boolean }) {
  return requestJson<{ ok: true }>(`/api/projects/${projectId}`, {
    method: 'DELETE',
    keepalive: options?.keepalive,
  });
}
