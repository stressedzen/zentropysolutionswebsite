import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { ZodError } from 'zod';
import type { AppConfig } from '../config.js';
import type { SqliteDatabase } from '../db/pragmas.js';
import { createManagedUser, getAdminUserList, resetManagedUserPassword } from '../services/admin-users-service.js';
import { adminUserCreateBodySchema, adminUserParamsSchema } from '../validators/admin-users.js';
import { requireAdminUser, type AuthenticatedRequest } from './auth-guard.js';

function sendValidationError(reply: FastifyReply, error: ZodError) {
  return reply.code(400).send({
    error: 'invalid_request',
    message: 'Please fix the highlighted fields and try again.',
    issues: error.issues.map((issue) => ({
      path: issue.path.join('.'),
      message: issue.message,
    })),
  });
}

export async function registerAdminUserRoutes(
  app: FastifyInstance,
  database: SqliteDatabase,
  config: Pick<AppConfig, 'authCookieName' | 'authSecureCookie'>,
) {
  const requireAdmin = async (request: FastifyRequest, reply: FastifyReply) => {
    const currentUser = await requireAdminUser(request, reply, database, config);
    if (!currentUser) {
      return;
    }

    (request as AuthenticatedRequest).currentUser = currentUser;
  };

  app.get('/api/admin/users', { preHandler: requireAdmin }, async () => {
    return {
      users: getAdminUserList(database),
    };
  });

  app.post('/api/admin/users', { preHandler: requireAdmin }, async (request, reply) => {
    const bodyResult = adminUserCreateBodySchema.safeParse(request.body);

    if (!bodyResult.success) {
      return sendValidationError(reply, bodyResult.error);
    }

    const result = await createManagedUser(database, {
      username: bodyResult.data.username,
      displayName: bodyResult.data.displayName?.trim() ? bodyResult.data.displayName.trim() : null,
      role: bodyResult.data.role,
    });

    if (result.status === 'username_taken') {
      return reply.code(409).send({
        error: 'username_taken',
        message: 'That username is already in use on this LoreLoom instance.',
      });
    }

    return reply.code(201).send({
      user: result.user,
      temporaryPassword: result.temporaryPassword,
    });
  });

  app.post('/api/admin/users/:id/reset-password', { preHandler: requireAdmin }, async (request, reply) => {
    const paramsResult = adminUserParamsSchema.safeParse(request.params);

    if (!paramsResult.success) {
      return sendValidationError(reply, paramsResult.error);
    }

    const result = await resetManagedUserPassword(database, paramsResult.data.id);

    if (result.status === 'not_found') {
      return reply.code(404).send({
        error: 'not_found',
        message: 'That user was not found.',
      });
    }

    return {
      user: result.user,
      temporaryPassword: result.temporaryPassword,
    };
  });
}
