import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import {
  API_UNAUTHORIZED_EVENT,
  ApiClientError,
  createFirstAdminAccount,
  fetchCurrentAuthSession,
  fetchSetupStatus,
  loginWithPassword,
  logoutCurrentSession,
  type AuthenticatedUser,
} from '../lib/api';
import type { LoreLoomPersistedState } from '../lib/types';
import { useLoreLoomStore } from '../store/useLoreLoomStore';
import LoreLoomLogo from './LoreLoomLogo';
import PasswordField from './PasswordField';

type AuthGateState = {
  setupRequired: boolean;
  authenticated: boolean;
  currentUser: AuthenticatedUser | null;
  loading: boolean;
  error: string | null;
};

type AuthGateProps = {
  children: (auth: { currentUser: AuthenticatedUser; logout: () => Promise<void> }) => ReactNode;
};

type SetupFormState = {
  username: string;
  displayName: string;
  password: string;
  passwordConfirmation: string;
};

type LoginFormState = {
  username: string;
  password: string;
};

type ValidationIssue = {
  path?: string;
  message: string;
};

type ScreenFrameProps = {
  title: string;
  subtitle: string;
  children: ReactNode;
  footer?: ReactNode;
};

const initialAuthState: AuthGateState = {
  setupRequired: false,
  authenticated: false,
  currentUser: null,
  loading: true,
  error: null,
};

const USER_CACHE_PREFIX = 'loreloom-user-cache:';
const USER_CACHE_OWNER_KEY = 'loreloom-user-cache-owner';

function getCacheStorage() {
  if (typeof window === 'undefined') {
    return null;
  }

  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function getUserCacheKey(userId: string) {
  return `${USER_CACHE_PREFIX}${userId}`;
}

function saveUserScopedSnapshot(userId: string) {
  const storage = getCacheStorage();
  if (!storage) {
    return;
  }

  try {
    storage.setItem(getUserCacheKey(userId), JSON.stringify(useLoreLoomStore.getState().getPersistedSnapshot()));
    storage.setItem(USER_CACHE_OWNER_KEY, userId);
  } catch {
    // Ignore cache write failures and continue with the in-memory state.
  }
}

function readUserScopedSnapshot(userId: string): Partial<LoreLoomPersistedState> | null {
  const storage = getCacheStorage();
  if (!storage) {
    return null;
  }

  try {
    const raw = storage.getItem(getUserCacheKey(userId));
    if (!raw) {
      return null;
    }

    const parsed = JSON.parse(raw) as Partial<LoreLoomPersistedState> | null;
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

function getActiveUserCacheOwner() {
  const storage = getCacheStorage();
  if (!storage) {
    return null;
  }

  const owner = storage.getItem(USER_CACHE_OWNER_KEY);
  return owner?.trim() ? owner.trim() : null;
}

function ScreenFrame({ title, subtitle, children, footer }: ScreenFrameProps) {
  return (
    <div className="app-shell min-h-screen text-slate-100">
      <div className="mx-auto flex min-h-screen max-w-5xl items-center px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid w-full gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <section className="app-panel rounded-3xl p-6 sm:p-8">
            <div className="mb-8 space-y-3">
              <LoreLoomLogo className="h-12 sm:h-14" />
              <h1 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">{title}</h1>
              <p className="max-w-2xl text-sm leading-7 text-slate-300 sm:text-base">{subtitle}</p>
            </div>
            {children}
          </section>
          <aside className="app-panel-inset rounded-3xl p-6 sm:p-8">
            <div className="space-y-4 text-sm leading-7 text-slate-300">
              <p className="text-base font-semibold text-white">Local, self-hosted account access</p>
              <p>
                LoreLoom still keeps your browser-local writing data on this machine. Signing in only gates
                access to this self-hosted instance.
              </p>
              <p>
                This flow is intentionally small and local-account focused. There is no cloud account,
                third-party identity provider, or public signup here.
              </p>
              {footer ? <div className="app-panel-soft rounded-2xl p-4">{footer}</div> : null}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

function LoadingScreen() {
  return (
    <ScreenFrame
      title="Checking this LoreLoom instance"
      subtitle="We’re checking whether this self-hosted instance still needs first-run setup or whether there is a local account session ready to resume."
      footer={<p className="text-slate-300">Local projects remain in the browser while account access is checked.</p>}
    >
      <div className="app-panel-inset rounded-2xl px-4 py-5 text-sm text-slate-300">
        Loading account access…
      </div>
    </ScreenFrame>
  );
}

function ErrorScreen({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <ScreenFrame
      title="Couldn’t reach the LoreLoom API"
      subtitle="The frontend is running, but it could not complete the local account check. Your browser-local writing data is still untouched."
      footer={
        <div className="space-y-2">
          <p className="text-white">Helpful checks</p>
          <ul className="space-y-1 text-slate-300">
            <li>Make sure the LoreLoom API is running.</li>
            <li>Confirm the web app can still reach `/api` and `/health`.</li>
            <li>Try again after the backend finishes starting up.</li>
          </ul>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="rounded-2xl border border-rose-400/30 bg-rose-500/10 px-4 py-4 text-sm text-rose-100">
          {message}
        </div>
        <button
          type="button"
          onClick={onRetry}
          className="app-button-primary app-focus-ring inline-flex rounded-xl px-4 py-2 text-sm font-medium"
        >
          Retry
        </button>
      </div>
    </ScreenFrame>
  );
}

function SetupScreen({
  error,
  submitting,
  onSubmit,
}: {
  error: string | null;
  submitting: boolean;
  onSubmit: (values: SetupFormState) => Promise<void>;
}) {
  const [form, setForm] = useState<SetupFormState>({
    username: '',
    displayName: '',
    password: '',
    passwordConfirmation: '',
  });

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    await onSubmit(form);
  };

  return (
    <ScreenFrame
      title="Create the first admin account"
      subtitle="This LoreLoom instance does not have any users yet. Create the first local admin account to finish setup and unlock the writing workspace."
      footer={
        <p className="text-slate-300">
          Existing projects on this instance will later be treated as belonging to this first admin during
          ownership migration.
        </p>
      }
    >
      <form className="space-y-5" onSubmit={handleSubmit}>
        <div className="grid gap-5 sm:grid-cols-2">
          <label className="space-y-2 text-sm text-slate-200">
            <span>Username</span>
            <input
              value={form.username}
              onChange={(event) => setForm((current) => ({ ...current, username: event.target.value }))}
              className="app-input app-focus-ring w-full rounded-xl px-4 py-3 text-sm"
              placeholder="writer_admin"
              autoComplete="username"
              autoCapitalize="none"
              autoCorrect="off"
            />
          </label>
          <label className="space-y-2 text-sm text-slate-200">
            <span>Display name (optional)</span>
            <input
              value={form.displayName}
              onChange={(event) => setForm((current) => ({ ...current, displayName: event.target.value }))}
              className="app-input app-focus-ring w-full rounded-xl px-4 py-3 text-sm"
              placeholder="Alex Writer"
              autoComplete="nickname"
            />
          </label>
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <PasswordField
            label="Password"
            value={form.password}
            onChange={(password) => setForm((current) => ({ ...current, password }))}
            placeholder="At least 6 characters"
            autoComplete="new-password"
            helperText="Local account passwords must be at least 6 characters."
          />
          <PasswordField
            label="Confirm password"
            value={form.passwordConfirmation}
            onChange={(passwordConfirmation) =>
              setForm((current) => ({ ...current, passwordConfirmation }))
            }
            placeholder="Repeat password"
            autoComplete="new-password"
          />
        </div>
        {error ? (
          <div className="whitespace-pre-line rounded-2xl border border-rose-400/30 bg-rose-500/10 px-4 py-4 text-sm text-rose-100">
            {error}
          </div>
        ) : null}
        <button
          type="submit"
          disabled={submitting}
          className="app-button-primary app-focus-ring inline-flex rounded-xl px-4 py-2 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-70"
        >
          {submitting ? 'Creating admin…' : 'Create admin'}
        </button>
      </form>
    </ScreenFrame>
  );
}

function LoginScreen({
  error,
  submitting,
  onSubmit,
}: {
  error: string | null;
  submitting: boolean;
  onSubmit: (values: LoginFormState) => Promise<void>;
}) {
  const [form, setForm] = useState<LoginFormState>({
    username: '',
    password: '',
  });

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    await onSubmit(form);
  };

  return (
    <ScreenFrame
      title="Sign in to this LoreLoom instance"
      subtitle="Use the local account for this self-hosted LoreLoom install. Your browser-local writing state stays on this machine unless you export or sync it elsewhere."
    >
      <form className="space-y-5" onSubmit={handleSubmit}>
        <label className="block space-y-2 text-sm text-slate-200">
          <span>Username</span>
          <input
            value={form.username}
            onChange={(event) => setForm((current) => ({ ...current, username: event.target.value }))}
            className="app-input app-focus-ring w-full rounded-xl px-4 py-3 text-sm"
            placeholder="writer_admin"
            autoComplete="username"
            autoCapitalize="none"
            autoCorrect="off"
          />
        </label>
        <PasswordField
          label="Password"
          value={form.password}
          onChange={(password) => setForm((current) => ({ ...current, password }))}
          placeholder="Your local account password"
          autoComplete="current-password"
          helperText="Local account passwords are at least 6 characters long."
        />
        {error ? (
          <div className="rounded-2xl border border-rose-400/30 bg-rose-500/10 px-4 py-4 text-sm text-rose-100">
            {error}
          </div>
        ) : null}
        <button
          type="submit"
          disabled={submitting}
          className="app-button-primary app-focus-ring inline-flex rounded-xl px-4 py-2 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-70"
        >
          {submitting ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </ScreenFrame>
  );
}

function getApiErrorMessage(error: unknown) {
  if (error instanceof ApiClientError) {
    if (error.status === 401) {
      return 'The username or password was not accepted.';
    }

    if (
      error.status === 400 &&
      typeof error.data === 'object' &&
      error.data !== null &&
      'error' in error.data &&
      error.data.error === 'invalid_request'
    ) {
      const data = error.data as {
        error?: unknown;
        message?: unknown;
        issues?: unknown;
      };

      const issues = Array.isArray(data.issues)
        ? data.issues.filter(
            (issue): issue is ValidationIssue =>
              typeof issue === 'object' &&
              issue !== null &&
              'message' in issue &&
              typeof (issue as { message?: unknown }).message === 'string',
          )
        : [];

      if (issues.length > 0) {
        return issues
          .map((issue) => issue.message)
          .filter(Boolean)
          .join('\n');
      }

      if (typeof data.message === 'string' && data.message.trim()) {
        return data.message;
      }
    }

    if (error.status === 409 && typeof error.data === 'object' && error.data && 'error' in error.data) {
      if (error.data.error === 'setup_already_completed') {
        return 'This LoreLoom instance has already completed first-run setup. Please sign in instead.';
      }
    }

    return error.message;
  }

  return error instanceof Error ? error.message : 'Something went wrong while talking to the LoreLoom API.';
}

export default function AuthGate({ children }: AuthGateProps) {
  const [state, setState] = useState<AuthGateState>(initialAuthState);
  const [submitting, setSubmitting] = useState(false);
  const currentUserIdRef = useRef<string | null>(null);

  const switchWorkspace = useCallback((nextUserId: string | null, options?: { preserveLegacyIfNoOwner?: boolean }) => {
    const currentUserId = currentUserIdRef.current;

    if (currentUserId && currentUserId !== nextUserId) {
      saveUserScopedSnapshot(currentUserId);
      useLoreLoomStore.getState().replacePersistedSnapshot();
    }

    if (!nextUserId) {
      currentUserIdRef.current = null;
      return;
    }

    if (currentUserId === nextUserId) {
      return;
    }

    const userSnapshot = readUserScopedSnapshot(nextUserId);
    if (userSnapshot) {
      useLoreLoomStore.getState().replacePersistedSnapshot(userSnapshot);
      currentUserIdRef.current = nextUserId;
      return;
    }

    const activeOwner = getActiveUserCacheOwner();
    if (!activeOwner && options?.preserveLegacyIfNoOwner) {
      saveUserScopedSnapshot(nextUserId);
      currentUserIdRef.current = nextUserId;
      return;
    }

    useLoreLoomStore.getState().replacePersistedSnapshot();
    saveUserScopedSnapshot(nextUserId);
    currentUserIdRef.current = nextUserId;
  }, []);

  const refreshAuth = useCallback(async (options?: { preserveView?: boolean }) => {
    setState((current) => ({
      ...current,
      loading: options?.preserveView ? current.loading : true,
      error: null,
    }));

    try {
      const setup = await fetchSetupStatus();

      if (setup.setupRequired) {
        setState({
          setupRequired: true,
          authenticated: false,
          currentUser: null,
          loading: false,
          error: null,
        });
        return;
      }

      const session = await fetchCurrentAuthSession();

      if (session.authenticated) {
        switchWorkspace(session.user.id, {
          preserveLegacyIfNoOwner: true,
        });
        setState({
          setupRequired: false,
          authenticated: true,
          currentUser: session.user,
          loading: false,
          error: null,
        });
        return;
      }

      switchWorkspace(null);
      setState({
        setupRequired: false,
        authenticated: false,
        currentUser: null,
        loading: false,
        error: null,
      });
    } catch (error) {
      setState((current) => ({
        ...current,
        loading: false,
        error: getApiErrorMessage(error),
      }));
    }
  }, []);

  useEffect(() => {
    void refreshAuth();
  }, [refreshAuth]);

  useEffect(() => {
    const handleUnauthorized = () => {
      void refreshAuth({ preserveView: true });
    };

    window.addEventListener(API_UNAUTHORIZED_EVENT, handleUnauthorized);

    return () => {
      window.removeEventListener(API_UNAUTHORIZED_EVENT, handleUnauthorized);
    };
  }, [refreshAuth]);

  useEffect(() => {
    const handleWindowFocus = () => {
      void refreshAuth({ preserveView: true });
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        void refreshAuth({ preserveView: true });
      }
    };

    window.addEventListener('focus', handleWindowFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('focus', handleWindowFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [refreshAuth]);

  const handleSetupSubmit = useCallback(async (values: SetupFormState) => {
    setSubmitting(true);
    setState((current) => ({ ...current, error: null }));

    try {
      const session = await createFirstAdminAccount({
        username: values.username.trim(),
        displayName: values.displayName.trim() || undefined,
        password: values.password,
        passwordConfirmation: values.passwordConfirmation,
      });

      switchWorkspace(session.user.id, {
        preserveLegacyIfNoOwner: true,
      });
      setState({
        setupRequired: false,
        authenticated: true,
        currentUser: session.user,
        loading: false,
        error: null,
      });
    } catch (error) {
      setState((current) => ({
        ...current,
        error: getApiErrorMessage(error),
      }));
    } finally {
      setSubmitting(false);
    }
  }, [switchWorkspace]);

  const handleLoginSubmit = useCallback(async (values: LoginFormState) => {
    setSubmitting(true);
    setState((current) => ({ ...current, error: null }));

    try {
      const session = await loginWithPassword({
        username: values.username.trim(),
        password: values.password,
      });

      switchWorkspace(session.user.id, {
        preserveLegacyIfNoOwner: true,
      });
      setState({
        setupRequired: false,
        authenticated: true,
        currentUser: session.user,
        loading: false,
        error: null,
      });
    } catch (error) {
      setState((current) => ({
        ...current,
        error: getApiErrorMessage(error),
      }));
    } finally {
      setSubmitting(false);
    }
  }, [switchWorkspace]);

  const handleLogout = useCallback(async () => {
    setSubmitting(true);

    try {
      await logoutCurrentSession();
    } finally {
      switchWorkspace(null);
      setSubmitting(false);
      setState({
        setupRequired: false,
        authenticated: false,
        currentUser: null,
        loading: false,
        error: null,
      });
    }
  }, [switchWorkspace]);

  if (state.loading) {
    return <LoadingScreen />;
  }

  if (state.error && !state.setupRequired && !state.authenticated) {
    return <ErrorScreen message={state.error} onRetry={() => void refreshAuth()} />;
  }

  if (state.setupRequired) {
    return <SetupScreen error={state.error} submitting={submitting} onSubmit={handleSetupSubmit} />;
  }

  if (!state.authenticated || !state.currentUser) {
    return <LoginScreen error={state.error} submitting={submitting} onSubmit={handleLoginSubmit} />;
  }

  return <>{children({ currentUser: state.currentUser, logout: handleLogout })}</>;
}
