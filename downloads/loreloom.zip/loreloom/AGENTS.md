# AGENTS.md

## Project

LoreLoom is a lightweight, self-hostable writing and worldbuilding platform.

The app must:
- work without AI
- run cheaply on low-power hardware such as Raspberry Pi
- avoid vendor lock-in
- support clean export
- keep AI optional and provider-agnostic
- prefer simple architecture over clever architecture

## Current phase

Build the first vertical slice:

- React + Vite + TypeScript web app
- dashboard
- project creation
- scene creation
- scene editor
- local persistence
- no backend yet
- no auth yet
- no AI yet

## Preferred stack

- React
- TypeScript
- Vite
- Tailwind
- Zustand
- TipTap
- localStorage or IndexedDB for first prototype

## Coding style

- Keep components small.
- Keep data models explicit.
- Avoid premature abstraction.
- Avoid generated complexity.
- Do not add backend services unless asked.
- Do not add AI dependencies unless asked.
- Do not add authentication unless asked.

## First milestone

A user can:
1. create a project
2. create a scene
3. write text
4. refresh the browser
5. see the content still saved
