import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { PersistStorage, StorageValue } from 'zustand/middleware';
import { importProjectBackupIntoState } from '../lib/backup';
import {
  createDefaultCodexNode,
  findDefaultCodexNode,
  getNextCodexOrderIndex,
  getSortedCodexNodesForProject,
} from '../lib/codex';
import {
  createDefaultStructureNode,
  findDefaultStructureNode,
  getNextStructureOrderIndex,
  getSortedStructureNodesForProject,
} from '../lib/structure';
import { defaultSceneContent, makeId, nowIso } from '../lib/storage';
import { DEFAULT_WRITING_APPEARANCE } from '../lib/writingAppearance';
import { stripHtmlToPlainText } from '../lib/writing-stats';
import type {
  BackendStatus,
  CodexEntry,
  CodexNode,
  DiagnosticEvent,
  DiagnosticEventType,
  InterfaceFontId,
  LoreLoomBackupState,
  LoreLoomDiagnosticsState,
  LoreLoomPersistedState,
  LoreLoomState,
  LoreLoomSyncState,
  LoreLoomWritingAppearanceState,
  Project,
  ProjectBackup,
  ProjectSyncMeta,
  RevisionSnapshot,
  Scene,
  StructureNode,
  WritingFontId,
} from '../lib/types';

type LoreLoomStore = LoreLoomPersistedState & {
  getPersistedSnapshot: () => LoreLoomPersistedState;
  replacePersistedSnapshot: (snapshot?: Partial<LoreLoomPersistedState>) => void;
  updateWritingAppearance: (updates: Partial<LoreLoomWritingAppearanceState>) => void;
  recordProjectBackupExport: (projectId: string, exportedAt?: string) => void;
  createProject: (name: string) => Project;
  createStructureNode: (
    projectId: string,
    node: Omit<StructureNode, 'id' | 'projectId' | 'orderIndex' | 'createdAt' | 'updatedAt'>,
  ) => StructureNode;
  createScene: (projectId: string, title: string, structureNodeId?: string) => Scene;
  createSceneAfter: (sceneId: string, title?: string) => Scene | undefined;
  createRevisionSnapshotForScene: (
    sceneId: string,
    sessionStart: { title: string; content: string },
  ) => RevisionSnapshot | undefined;
  restoreRevisionSnapshot: (snapshotId: string) => RevisionSnapshot | undefined;
  updateProject: (projectId: string, updates: Partial<Pick<Project, 'name'>>) => void;
  updateStructureNode: (
    nodeId: string,
    updates: Partial<Pick<StructureNode, 'title' | 'type' | 'customTypeLabel'>>,
  ) => void;
  updateScene: (
    sceneId: string,
    updates: Partial<Pick<Scene, 'title' | 'content' | 'structureNodeId'>>,
  ) => void;
  createCodexEntry: (
    projectId: string,
    entry: Omit<CodexEntry, 'id' | 'projectId' | 'codexNodeId' | 'createdAt' | 'updatedAt'> & {
      codexNodeId?: string;
    },
  ) => CodexEntry;
  createCodexNode: (
    projectId: string,
    node: Omit<CodexNode, 'id' | 'projectId' | 'orderIndex' | 'createdAt' | 'updatedAt'>,
  ) => CodexNode;
  updateCodexNode: (
    nodeId: string,
    updates: Partial<Pick<CodexNode, 'title' | 'type' | 'customTypeLabel' | 'tags'>>,
  ) => void;
  updateCodexEntry: (
    entryId: string,
    updates: Partial<Pick<CodexEntry, 'title' | 'type' | 'content' | 'tags' | 'codexNodeId'>>,
  ) => void;
  getCodexEntryById: (entryId: string) => CodexEntry | undefined;
  getCodexEntriesForProject: (projectId: string) => CodexEntry[];
  deleteProject: (projectId: string) => void;
  deleteStructureNode: (nodeId: string) => void;
  deleteScene: (sceneId: string) => void;
  deleteCodexNode: (nodeId: string) => void;
  deleteCodexEntry: (entryId: string) => void;
  importProjectBackup: (backup: ProjectBackup) => Project;
  getProjectById: (projectId: string) => Project | undefined;
  getStructureNodeById: (nodeId: string) => StructureNode | undefined;
  getStructureNodesForProject: (projectId: string) => StructureNode[];
  getCodexNodesForProject: (projectId: string) => CodexNode[];
  getSceneById: (sceneId: string) => Scene | undefined;
  getScenesForProject: (projectId: string) => Scene[];
  getRevisionSnapshotsForScene: (sceneId: string) => RevisionSnapshot[];
  getProjectBundle: (projectId: string) => LoreLoomState | undefined;
  applyRemoteProjectBundle: (state: LoreLoomState, projectId: string, serverRevision: number) => void;
  requestProjectSync: (projectId: string) => void;
  markProjectSyncing: (projectId: string) => number;
  markProjectSyncSuccess: (
    projectId: string,
    serverRevision: number,
    syncedAt: string,
    syncedChangeToken: number,
  ) => void;
  markProjectSyncOffline: (projectId: string, error?: string) => void;
  markProjectSyncConflict: (projectId: string, error?: string) => void;
  setBackendStatus: (status: BackendStatus) => void;
  setHydrationState: (status: LoreLoomSyncState['hydrationState']) => void;
  clearPendingDelete: (projectId: string) => void;
  recordDiagnosticEvent: (event: {
    type: DiagnosticEventType;
    projectId?: string | null;
    status?: DiagnosticEvent['status'];
    message?: string | null;
  }) => void;
};

type RawStorage = {
  getItem: (name: string) => string | null;
  setItem: (name: string, value: string) => void;
  removeItem: (name: string) => void;
};

const memoryStorage = new Map<string, string>();

function createMemoryStorage(): RawStorage {
  return {
    getItem: (name) => memoryStorage.get(name) ?? null,
    setItem: (name, value) => {
      memoryStorage.set(name, value);
    },
    removeItem: (name) => {
      memoryStorage.delete(name);
    },
  };
}

function getRawStorage(): RawStorage {
  if (typeof window === 'undefined') {
    return createMemoryStorage();
  }

  try {
    const testKey = '__loreloom_storage_test__';
    window.localStorage.setItem(testKey, '1');
    window.localStorage.removeItem(testKey);
    return window.localStorage;
  } catch {
    return createMemoryStorage();
  }
}

function createSafePersistStorage<T>(): PersistStorage<T> {
  const storage = getRawStorage();

  return {
    getItem: (name) => {
      try {
        const raw = storage.getItem(name);
        if (raw === null) {
          return null;
        }

        const parsed = JSON.parse(raw) as StorageValue<T> | null;
        if (!parsed || typeof parsed !== 'object' || !('state' in parsed)) {
          storage.removeItem(name);
          return null;
        }

        return parsed;
      } catch {
        storage.removeItem(name);
        return null;
      }
    },
    setItem: (name, value) => {
      try {
        storage.setItem(name, JSON.stringify(value));
      } catch {
        createMemoryStorage().setItem(name, JSON.stringify(value));
      }
    },
    removeItem: (name) => {
      try {
        storage.removeItem(name);
      } catch {
        // Ignore storage cleanup failures and fall back to the in-memory copy.
      }

      createMemoryStorage().removeItem(name);
    },
  };
}

function createEmptySyncState(): LoreLoomSyncState {
  return {
    projects: {},
    pendingDeletes: [],
    backendStatus: 'unknown',
    hydrationState: 'idle',
  };
}

function createEmptyDiagnosticsState(): LoreLoomDiagnosticsState {
  return {
    events: [],
  };
}

function createEmptyBackupsState(): LoreLoomBackupState {
  return {
    lastProjectBackupExportAt: null,
    projectBackupExports: {},
  };
}

function createDefaultWritingAppearanceState(): LoreLoomWritingAppearanceState {
  return {
    ...DEFAULT_WRITING_APPEARANCE,
  };
}

const LEGACY_INTERFACE_FONT_IDS = new Set<InterfaceFontId>([
  'system-sans',
  'inter',
  'source-sans-3',
  'ibm-plex-sans',
  'atkinson-hyperlegible',
]);

function createDefaultProjectSyncMeta(partial?: Partial<ProjectSyncMeta>): ProjectSyncMeta {
  return {
    dirty: false,
    status: 'idle',
    serverRevision: null,
    lastSyncAt: null,
    error: null,
    changeToken: 0,
    syncRequestToken: 0,
    ...partial,
  };
}

function upsertProjectSyncMeta(
  sync: LoreLoomSyncState,
  projectId: string,
  updater: (current: ProjectSyncMeta) => ProjectSyncMeta,
): LoreLoomSyncState {
  const current = createDefaultProjectSyncMeta(sync.projects[projectId]);
  return {
    ...sync,
    projects: {
      ...sync.projects,
      [projectId]: updater(current),
    },
  };
}

function markProjectDirty(sync: LoreLoomSyncState, projectId: string): LoreLoomSyncState {
  return upsertProjectSyncMeta(sync, projectId, (current) => ({
    ...current,
    dirty: true,
    status: current.status === 'conflict' ? 'conflict' : current.status === 'offline' ? 'offline' : 'idle',
    error: current.status === 'conflict' ? current.error : null,
    changeToken: current.changeToken + 1,
  }));
}

function normalizeSyncState(
  sync: Partial<LoreLoomSyncState> | undefined,
  projects: Project[],
  treatExistingProjectsAsDirty: boolean,
): LoreLoomSyncState {
  const projectIds = new Set(projects.map((project) => project.id));

  if (!sync) {
    const nextSync = createEmptySyncState();
    for (const project of projects) {
      nextSync.projects[project.id] = createDefaultProjectSyncMeta({
        dirty: treatExistingProjectsAsDirty,
        changeToken: treatExistingProjectsAsDirty ? 1 : 0,
      });
    }
    return nextSync;
  }

  const nextProjects: Record<string, ProjectSyncMeta> = {};

  for (const project of projects) {
    nextProjects[project.id] = createDefaultProjectSyncMeta(
      sync.projects?.[project.id] ?? {
        dirty: true,
        changeToken: 1,
      },
    );
  }

  return {
    projects: nextProjects,
    pendingDeletes: Array.from(
      new Set((sync.pendingDeletes ?? []).filter((projectId): projectId is string => typeof projectId === 'string')),
    ),
    backendStatus: sync.backendStatus === 'online' || sync.backendStatus === 'offline' ? sync.backendStatus : 'unknown',
    hydrationState:
      sync.hydrationState === 'hydrating' || sync.hydrationState === 'ready' ? sync.hydrationState : 'idle',
  };
}

function normalizeBackupsState(
  backups: Partial<LoreLoomBackupState> | undefined,
  projects: Project[],
): LoreLoomBackupState {
  const projectIds = new Set(projects.map((project) => project.id));

  return {
    lastProjectBackupExportAt:
      typeof backups?.lastProjectBackupExportAt === 'string' && backups.lastProjectBackupExportAt
        ? backups.lastProjectBackupExportAt
        : null,
    projectBackupExports: Object.fromEntries(
      Object.entries(backups?.projectBackupExports ?? {}).filter(
        ([projectId, exportedAt]) => projectIds.has(projectId) && typeof exportedAt === 'string' && exportedAt,
      ),
    ),
  };
}

function normalizeWritingAppearanceState(
  appearance: Partial<LoreLoomWritingAppearanceState> | undefined,
): LoreLoomWritingAppearanceState {
  const legacyFontId = (appearance as Partial<LoreLoomWritingAppearanceState> & { fontId?: WritingFontId })
    ?.fontId;
  const interfaceFontId: InterfaceFontId =
    appearance?.interfaceFontId ??
    (legacyFontId && LEGACY_INTERFACE_FONT_IDS.has(legacyFontId as InterfaceFontId)
      ? (legacyFontId as InterfaceFontId)
      : DEFAULT_WRITING_APPEARANCE.interfaceFontId);

  return {
    interfaceFontId,
    writingFontId: appearance?.writingFontId ?? legacyFontId ?? DEFAULT_WRITING_APPEARANCE.writingFontId,
    fontSize: appearance?.fontSize ?? DEFAULT_WRITING_APPEARANCE.fontSize,
    lineSpacing: appearance?.lineSpacing ?? DEFAULT_WRITING_APPEARANCE.lineSpacing,
    editorWidth: appearance?.editorWidth ?? DEFAULT_WRITING_APPEARANCE.editorWidth,
  };
}

function normalizeState(state?: Partial<LoreLoomPersistedState>): LoreLoomPersistedState {
  const projects = state?.projects ?? [];
  const sourceCodexNodes = state?.codexNodes ?? [];
  const codexEntries = state?.codexEntries ?? [];
  const sourceStructureNodes = state?.structureNodes ?? [];
  const sourceScenes = state?.scenes ?? [];
  const revisionSnapshots = state?.revisionSnapshots ?? [];

  const structureNodes: StructureNode[] = [];
  const scenes: Scene[] = [];
  const normalizedCodexNodes: CodexNode[] = [];
  const normalizedCodexEntries: CodexEntry[] = [];

  for (const project of projects) {
    const projectNodes = getSortedStructureNodesForProject(sourceStructureNodes, project.id).map((node) => ({
      ...node,
      customTypeLabel: node.customTypeLabel ?? null,
    }));
    const projectScenes = sourceScenes
      .filter((scene) => scene.projectId === project.id)
      .map((scene) => ({ ...scene }));

    let defaultNodeId = projectNodes[0]?.id ?? null;

    if (!defaultNodeId && projectScenes.length > 0) {
      const defaultNode = createDefaultStructureNode(project.id, project.createdAt);
      projectNodes.push({
        ...defaultNode,
        customTypeLabel: defaultNode.customTypeLabel ?? null,
      });
      defaultNodeId = defaultNode.id;
    }

    structureNodes.push(...projectNodes);

    const projectCodexNodes: CodexNode[] = getSortedCodexNodesForProject(sourceCodexNodes, project.id).map((node) => ({
      ...node,
      parentId: node.parentId ?? null,
      customTypeLabel: node.customTypeLabel ?? null,
      tags: Array.isArray(node.tags) ? node.tags.filter((tag): tag is string => typeof tag === 'string') : [],
    }));
    let defaultCodexNodeId = projectCodexNodes[0]?.id ?? null;

    if (!defaultCodexNodeId) {
      const defaultCodexNode = createDefaultCodexNode(project.id, project.createdAt);
      projectCodexNodes.push(defaultCodexNode);
      defaultCodexNodeId = defaultCodexNode.id;
    }

    const validProjectCodexNodeIds = new Set(projectCodexNodes.map((node) => node.id));
    normalizedCodexNodes.push(
      ...projectCodexNodes.map((node) => ({
        ...node,
        parentId:
          node.parentId && node.parentId !== node.id && validProjectCodexNodeIds.has(node.parentId) ? node.parentId : null,
      })),
    );

    const projectCodexEntries = codexEntries
      .filter((entry) => entry.projectId === project.id)
      .filter(
        (entry): entry is CodexEntry =>
          typeof entry?.id === 'string' &&
          typeof entry?.projectId === 'string' &&
          typeof entry?.title === 'string' &&
          typeof entry?.type === 'string' &&
          typeof entry?.content === 'string' &&
          Array.isArray(entry?.tags) &&
          typeof entry?.createdAt === 'string' &&
          typeof entry?.updatedAt === 'string',
      )
      .map((entry) => ({
        ...entry,
        codexNodeId:
          typeof entry.codexNodeId === 'string' && validProjectCodexNodeIds.has(entry.codexNodeId)
            ? entry.codexNodeId
            : (defaultCodexNodeId ?? entry.codexNodeId),
        tags: entry.tags.filter((tag): tag is string => typeof tag === 'string'),
      }));
    normalizedCodexEntries.push(...projectCodexEntries);

    for (const scene of projectScenes) {
      const sceneStructureNodeId =
        scene.structureNodeId && projectNodes.some((node) => node.id === scene.structureNodeId)
          ? scene.structureNodeId
          : defaultNodeId;

      scenes.push({
        ...scene,
        structureNodeId: sceneStructureNodeId ?? scene.structureNodeId,
      });
    }
  }

  return {
    projects,
    structureNodes,
    scenes,
    codexNodes: normalizedCodexNodes,
    codexEntries: normalizedCodexEntries,
    revisionSnapshots: clampAllSnapshots(
      revisionSnapshots.filter(
        (snapshot): snapshot is RevisionSnapshot =>
          typeof snapshot?.id === 'string' &&
          typeof snapshot?.sceneId === 'string' &&
          typeof snapshot?.projectId === 'string' &&
          typeof snapshot?.title === 'string' &&
          typeof snapshot?.content === 'string' &&
          typeof snapshot?.createdAt === 'string' &&
          scenes.some((scene) => scene.id === snapshot.sceneId && scene.projectId === snapshot.projectId),
        ),
    ),
    sync: normalizeSyncState(state?.sync, projects, true),
    diagnostics: {
      events: Array.isArray(state?.diagnostics?.events)
        ? state.diagnostics.events
            .filter(
              (event): event is DiagnosticEvent =>
                typeof event?.id === 'string' &&
                typeof event?.at === 'string' &&
                typeof event?.type === 'string' &&
                (event.projectId === undefined || event.projectId === null || typeof event.projectId === 'string') &&
                (event.status === undefined || event.status === null || typeof event.status === 'string') &&
                (event.message === undefined || event.message === null || typeof event.message === 'string'),
            )
            .slice(0, 100)
        : [],
    },
    backups: normalizeBackupsState(state?.backups, projects),
    appearance: normalizeWritingAppearanceState(state?.appearance),
  };
}

function getProjectStructureNodes(state: LoreLoomState, projectId: string) {
  return getSortedStructureNodesForProject(state.structureNodes, projectId);
}

function getProjectCodexNodes(state: LoreLoomState, projectId: string) {
  return getSortedCodexNodesForProject(state.codexNodes, projectId);
}

function updateProjectTimestamp(projects: Project[], projectId: string, updatedAt: string) {
  return projects.map((project) => (project.id === projectId ? { ...project, updatedAt } : project));
}

function sortScenesInDisplayOrder(scenes: Scene[]) {
  return [...scenes].sort((left, right) => {
    const updated = right.updatedAt.localeCompare(left.updatedAt);
    if (updated !== 0) {
      return updated;
    }

    return right.createdAt.localeCompare(left.createdAt);
  });
}

function timestampBetween(currentIso: string, nextIso?: string) {
  const currentMs = new Date(currentIso).getTime();
  const nextMs = nextIso ? new Date(nextIso).getTime() : Number.NEGATIVE_INFINITY;

  if (!Number.isFinite(currentMs)) {
    return nowIso();
  }

  if (Number.isFinite(nextMs) && currentMs - nextMs > 1) {
    return new Date(Math.floor((currentMs + nextMs) / 2)).toISOString();
  }

  return new Date(currentMs - 1).toISOString();
}

function sortSnapshotsNewestFirst(snapshots: RevisionSnapshot[]) {
  return [...snapshots].sort(
    (left, right) => right.createdAt.localeCompare(left.createdAt) || right.id.localeCompare(left.id),
  );
}

function clampSnapshotsPerScene(snapshots: RevisionSnapshot[], sceneId: string, limit = 25) {
  const newestForScene = sortSnapshotsNewestFirst(snapshots).filter((snapshot) => snapshot.sceneId === sceneId);
  if (newestForScene.length <= limit) {
    return snapshots;
  }

  const allowedIds = new Set(newestForScene.slice(0, limit).map((snapshot) => snapshot.id));
  return snapshots.filter((snapshot) => snapshot.sceneId !== sceneId || allowedIds.has(snapshot.id));
}

function clampAllSnapshots(snapshots: RevisionSnapshot[], limit = 25) {
  const sceneIds = new Set(snapshots.map((snapshot) => snapshot.sceneId));
  let nextSnapshots = snapshots;

  for (const sceneId of sceneIds) {
    nextSnapshots = clampSnapshotsPerScene(nextSnapshots, sceneId, limit);
  }

  return nextSnapshots;
}

function isEffectivelyEmptySnapshot(title: string, content: string) {
  return !title.trim() && !stripHtmlToPlainText(content);
}

function hasMeaningfulSnapshotChange(
  scene: Scene,
  sessionStart: { title: string; content: string },
  latestSnapshot: RevisionSnapshot | undefined,
) {
  const currentPlainText = stripHtmlToPlainText(scene.content);
  const sessionStartPlainText = stripHtmlToPlainText(sessionStart.content);
  const titleChanged = scene.title !== sessionStart.title;
  const contentChanged = currentPlainText !== sessionStartPlainText;
  const hasMinimumContent = currentPlainText.length >= 25;

  if (isEffectivelyEmptySnapshot(scene.title, scene.content)) {
    return false;
  }

  if (latestSnapshot && latestSnapshot.title === scene.title && latestSnapshot.content === scene.content) {
    return false;
  }

  if (titleChanged) {
    return true;
  }

  if (contentChanged && hasMinimumContent) {
    return true;
  }

  if (!latestSnapshot && hasMinimumContent) {
    return true;
  }

  return false;
}

function createSnapshotRecord(scene: Scene, createdAt = nowIso()): RevisionSnapshot {
  return {
    id: makeId(),
    sceneId: scene.id,
    projectId: scene.projectId,
    title: scene.title,
    content: scene.content,
    createdAt,
  };
}

function appendDiagnosticEvent(
  diagnostics: LoreLoomDiagnosticsState,
  event: Omit<DiagnosticEvent, 'id' | 'at'>,
) {
  const nextEvent: DiagnosticEvent = {
    id: makeId(),
    at: nowIso(),
    ...event,
  };

  return {
    ...diagnostics,
    events: [nextEvent, ...diagnostics.events].slice(0, 100),
  };
}

function getProjectDataState(state: LoreLoomPersistedState, projectId: string): LoreLoomState | undefined {
  const project = state.projects.find((entry) => entry.id === projectId);
  if (!project) {
    return undefined;
  }

  return {
    projects: [project],
    structureNodes: state.structureNodes.filter((node) => node.projectId === projectId),
    scenes: state.scenes.filter((scene) => scene.projectId === projectId),
    codexNodes: state.codexNodes.filter((node) => node.projectId === projectId),
    codexEntries: state.codexEntries.filter((entry) => entry.projectId === projectId),
    revisionSnapshots: state.revisionSnapshots.filter((snapshot) => snapshot.projectId === projectId),
  };
}

function replaceProjectDataState(
  state: LoreLoomPersistedState,
  incoming: LoreLoomState,
  projectId: string,
  serverRevision: number,
): LoreLoomPersistedState {
  const project = incoming.projects.find((entry) => entry.id === projectId);
  if (!project) {
    return state;
  }

  return {
    ...state,
    projects: [project, ...state.projects.filter((entry) => entry.id !== projectId)],
    structureNodes: [
      ...incoming.structureNodes.filter((node) => node.projectId === projectId),
      ...state.structureNodes.filter((node) => node.projectId !== projectId),
    ],
    scenes: [
      ...incoming.scenes.filter((scene) => scene.projectId === projectId),
      ...state.scenes.filter((scene) => scene.projectId !== projectId),
    ],
    codexNodes: [
      ...incoming.codexNodes.filter((node) => node.projectId === projectId),
      ...state.codexNodes.filter((node) => node.projectId !== projectId),
    ],
    codexEntries: [
      ...incoming.codexEntries.filter((entry) => entry.projectId === projectId),
      ...state.codexEntries.filter((entry) => entry.projectId !== projectId),
    ],
    revisionSnapshots: [
      ...incoming.revisionSnapshots.filter((snapshot) => snapshot.projectId === projectId),
      ...state.revisionSnapshots.filter((snapshot) => snapshot.projectId !== projectId),
    ],
    sync: upsertProjectSyncMeta(
      {
        ...state.sync,
        backendStatus: 'online',
      },
      projectId,
      (current) => ({
        ...current,
        dirty: false,
        status: 'idle',
        serverRevision,
        lastSyncAt: nowIso(),
        error: null,
      }),
    ),
  };
}

export const useLoreLoomStore = create<LoreLoomStore>()(
  persist(
    (set, get) => ({
      projects: [],
      structureNodes: [],
      scenes: [],
      codexNodes: [],
      codexEntries: [],
      revisionSnapshots: [],
      sync: createEmptySyncState(),
      diagnostics: createEmptyDiagnosticsState(),
      backups: createEmptyBackupsState(),
      appearance: createDefaultWritingAppearanceState(),
      getPersistedSnapshot: () => {
        const state = get();
        return {
          projects: state.projects,
          structureNodes: state.structureNodes,
          scenes: state.scenes,
          codexNodes: state.codexNodes,
          codexEntries: state.codexEntries,
          revisionSnapshots: state.revisionSnapshots,
          sync: state.sync,
          diagnostics: state.diagnostics,
          backups: state.backups,
          appearance: state.appearance,
        };
      },
      replacePersistedSnapshot: (snapshot) => {
        set((state) => ({
          ...state,
          ...normalizeState(snapshot),
        }));
      },
      updateWritingAppearance: (updates) => {
        set((state) => ({
          appearance: normalizeWritingAppearanceState({
            ...state.appearance,
            ...updates,
          }),
        }));
      },
      recordProjectBackupExport: (projectId, exportedAt = nowIso()) => {
        set((state) => ({
          backups: {
            lastProjectBackupExportAt: exportedAt,
            projectBackupExports: {
              ...state.backups.projectBackupExports,
              [projectId]: exportedAt,
            },
          },
        }));
      },
      createProject: (name) => {
        const trimmed = name.trim();
        const timestamp = nowIso();
        const project: Project = {
          id: makeId(),
          name: trimmed || 'Untitled Project',
          createdAt: timestamp,
          updatedAt: timestamp,
        };
        const defaultStructureNode = createDefaultStructureNode(project.id, timestamp);
        const defaultCodexNode = createDefaultCodexNode(project.id, timestamp);

        set((state) => ({
          projects: [project, ...state.projects],
          structureNodes: [defaultStructureNode, ...state.structureNodes],
          codexNodes: [defaultCodexNode, ...state.codexNodes],
          sync: upsertProjectSyncMeta(state.sync, project.id, (current) => ({
            ...current,
            dirty: true,
            changeToken: current.changeToken + 1,
          })),
        }));

        return project;
      },
      createStructureNode: (projectId, node) => {
        const timestamp = nowIso();
        const parentId = node.parentId || null;
        const existingParent = parentId
          ? get().structureNodes.find((candidate) => candidate.id === parentId && candidate.projectId === projectId)
          : null;
        const structureNode: StructureNode = {
          id: makeId(),
          projectId,
          parentId: existingParent ? existingParent.id : null,
          type: node.type,
          customTypeLabel: node.type === 'custom' ? node.customTypeLabel?.trim() || null : null,
          title: node.title.trim() || 'Untitled Structure Node',
          orderIndex: getNextStructureOrderIndex(
            get().structureNodes.filter((candidate) => candidate.projectId === projectId),
            existingParent ? existingParent.id : null,
          ),
          createdAt: timestamp,
          updatedAt: timestamp,
        };

        set((state) => ({
          structureNodes: [structureNode, ...state.structureNodes],
          projects: updateProjectTimestamp(state.projects, projectId, timestamp),
          sync: markProjectDirty(state.sync, projectId),
        }));

        return structureNode;
      },
      createScene: (projectId, title, structureNodeId) => {
        const timestamp = nowIso();
        const trimmed = title.trim();
        const projectNodes = getProjectStructureNodes(get(), projectId);
        const defaultStructureNode = findDefaultStructureNode(projectNodes, projectId);
        let targetStructureNode =
          structureNodeId !== undefined
            ? projectNodes.find((node) => node.id === structureNodeId) ?? defaultStructureNode
            : defaultStructureNode;
        let structureNodeToInsert: StructureNode | null = null;

        if (!targetStructureNode) {
          structureNodeToInsert = createDefaultStructureNode(projectId, timestamp);
          targetStructureNode = structureNodeToInsert;
        }

        const scene: Scene = {
          id: makeId(),
          projectId,
          structureNodeId: targetStructureNode.id,
          title: trimmed || 'Untitled Scene',
          content: defaultSceneContent(trimmed || 'Untitled Scene'),
          createdAt: timestamp,
          updatedAt: timestamp,
        };

        set((state) => ({
          structureNodes:
            structureNodeToInsert && !state.structureNodes.some((node) => node.id === structureNodeToInsert.id)
              ? [structureNodeToInsert, ...state.structureNodes]
              : state.structureNodes,
          scenes: [scene, ...state.scenes],
          projects: updateProjectTimestamp(state.projects, projectId, timestamp),
          sync: markProjectDirty(state.sync, projectId),
        }));

        return scene;
      },
      createSceneAfter: (sceneId, title) => {
        const sourceScene = get().scenes.find((candidate) => candidate.id === sceneId);
        if (!sourceScene) {
          return undefined;
        }

        const trimmed = title?.trim();
        const siblingScenes = sortScenesInDisplayOrder(
          get().scenes.filter(
            (candidate) =>
              candidate.projectId === sourceScene.projectId && candidate.structureNodeId === sourceScene.structureNodeId,
          ),
        );
        const sourceIndex = siblingScenes.findIndex((candidate) => candidate.id === sceneId);
        const nextSibling = sourceIndex >= 0 ? siblingScenes[sourceIndex + 1] : undefined;
        const relativeTimestamp = timestampBetween(sourceScene.updatedAt, nextSibling?.updatedAt);
        const scene: Scene = {
          id: makeId(),
          projectId: sourceScene.projectId,
          structureNodeId: sourceScene.structureNodeId,
          title: trimmed || 'Untitled Text Block',
          content: defaultSceneContent(trimmed || 'Untitled Text Block'),
          createdAt: timestampBetween(sourceScene.createdAt, nextSibling?.createdAt),
          updatedAt: relativeTimestamp,
        };
        const projectUpdatedAt = nowIso();

        set((state) => ({
          scenes: [scene, ...state.scenes],
          projects: updateProjectTimestamp(state.projects, sourceScene.projectId, projectUpdatedAt),
          sync: markProjectDirty(state.sync, sourceScene.projectId),
        }));

        return scene;
      },
      createRevisionSnapshotForScene: (sceneId, sessionStart) => {
        let createdSnapshot: RevisionSnapshot | undefined;

        set((state) => {
          const scene = state.scenes.find((candidate) => candidate.id === sceneId);
          if (!scene) {
            return {};
          }

          const latestSnapshot = sortSnapshotsNewestFirst(
            state.revisionSnapshots.filter((snapshot) => snapshot.sceneId === sceneId),
          )[0];

          if (!hasMeaningfulSnapshotChange(scene, sessionStart, latestSnapshot)) {
            return {};
          }

          createdSnapshot = createSnapshotRecord(scene);
          return {
            revisionSnapshots: clampSnapshotsPerScene([createdSnapshot, ...state.revisionSnapshots], sceneId),
            sync: markProjectDirty(state.sync, scene.projectId),
          };
        });

        return createdSnapshot;
      },
      restoreRevisionSnapshot: (snapshotId) => {
        let preservedSnapshot: RevisionSnapshot | undefined;

        set((state) => {
          const snapshot = state.revisionSnapshots.find((candidate) => candidate.id === snapshotId);
          if (!snapshot) {
            return {};
          }

          const scene = state.scenes.find((candidate) => candidate.id === snapshot.sceneId);
          if (!scene) {
            return {};
          }

          if (scene.title === snapshot.title && scene.content === snapshot.content) {
            return {};
          }

          const latestSnapshot = sortSnapshotsNewestFirst(
            state.revisionSnapshots.filter((candidate) => candidate.sceneId === scene.id),
          )[0];
          const currentMatchesLatest =
            latestSnapshot !== undefined &&
            latestSnapshot.title === scene.title &&
            latestSnapshot.content === scene.content;
          const updatedAt = nowIso();
          const nextSnapshots = [...state.revisionSnapshots];

          if (!isEffectivelyEmptySnapshot(scene.title, scene.content) && !currentMatchesLatest) {
            preservedSnapshot = createSnapshotRecord(scene, updatedAt);
            nextSnapshots.unshift(preservedSnapshot);
          }

          return {
            scenes: state.scenes.map((candidate) =>
              candidate.id === scene.id
                ? {
                    ...candidate,
                    title: snapshot.title,
                    content: snapshot.content,
                    updatedAt,
                  }
                : candidate,
            ),
            revisionSnapshots: clampSnapshotsPerScene(nextSnapshots, scene.id),
            projects: updateProjectTimestamp(state.projects, scene.projectId, updatedAt),
            sync: markProjectDirty(state.sync, scene.projectId),
          };
        });

        return preservedSnapshot;
      },
      createCodexEntry: (projectId, entry) => {
        const timestamp = nowIso();
        const projectCodexNodes = getProjectCodexNodes(get(), projectId);
        const defaultCodexNode = findDefaultCodexNode(projectCodexNodes, projectId);
        const requestedCodexNode =
          entry.codexNodeId !== undefined
            ? projectCodexNodes.find((candidate) => candidate.id === entry.codexNodeId) ?? null
            : null;
        const targetCodexNode = requestedCodexNode ?? defaultCodexNode;
        const codexNodeToInsert = targetCodexNode ? null : createDefaultCodexNode(projectId, timestamp);
        const codexEntry: CodexEntry = {
          id: makeId(),
          projectId,
          codexNodeId: targetCodexNode?.id ?? codexNodeToInsert?.id ?? makeId(),
          title: entry.title.trim() || 'Untitled Codex Entry',
          type: entry.type,
          content: entry.content.trim() || '',
          tags: entry.tags,
          createdAt: timestamp,
          updatedAt: timestamp,
        };

        set((state) => ({
          codexNodes:
            codexNodeToInsert && !state.codexNodes.some((node) => node.id === codexNodeToInsert.id)
              ? [codexNodeToInsert, ...state.codexNodes]
              : state.codexNodes,
          codexEntries: [codexEntry, ...state.codexEntries],
          projects: updateProjectTimestamp(state.projects, projectId, timestamp),
          sync: markProjectDirty(state.sync, projectId),
        }));

        return codexEntry;
      },
      createCodexNode: (projectId, node) => {
        const timestamp = nowIso();
        const parentId = node.parentId || null;
        const existingParent = parentId
          ? get().codexNodes.find((candidate) => candidate.id === parentId && candidate.projectId === projectId)
          : null;
        const codexNode: CodexNode = {
          id: makeId(),
          projectId,
          parentId: existingParent ? existingParent.id : null,
          type: node.type,
          customTypeLabel: node.type === 'custom' ? node.customTypeLabel?.trim() || null : null,
          title: node.title.trim() || 'Untitled Codex Node',
          tags: Array.from(new Set((node.tags ?? []).map((tag) => tag.trim()).filter(Boolean))),
          orderIndex: getNextCodexOrderIndex(
            get().codexNodes.filter((candidate) => candidate.projectId === projectId),
            existingParent ? existingParent.id : null,
          ),
          createdAt: timestamp,
          updatedAt: timestamp,
        };

        set((state) => ({
          codexNodes: [codexNode, ...state.codexNodes],
          projects: updateProjectTimestamp(state.projects, projectId, timestamp),
          sync: markProjectDirty(state.sync, projectId),
        }));

        return codexNode;
      },
      updateCodexNode: (nodeId, updates) => {
        const updatedAt = nowIso();

        set((state) => {
          const node = state.codexNodes.find((candidate) => candidate.id === nodeId);
          if (!node) {
            return {};
          }

          return {
            codexNodes: state.codexNodes.map((candidate) =>
              candidate.id === nodeId
                ? {
                    ...candidate,
                    ...updates,
                    title: updates.title !== undefined ? updates.title.trim() || candidate.title : candidate.title,
                    type: updates.type ?? candidate.type,
                    customTypeLabel:
                      updates.type === 'custom' || (updates.type === undefined && candidate.type === 'custom')
                        ? updates.customTypeLabel !== undefined
                          ? updates.customTypeLabel?.trim() || null
                          : candidate.customTypeLabel ?? null
                        : null,
                    tags:
                      updates.tags !== undefined
                        ? Array.from(new Set(updates.tags.map((tag) => tag.trim()).filter(Boolean)))
                        : candidate.tags,
                    updatedAt,
                  }
                : candidate,
            ),
            projects: updateProjectTimestamp(state.projects, node.projectId, updatedAt),
            sync: markProjectDirty(state.sync, node.projectId),
          };
        });
      },
      updateCodexEntry: (entryId, updates) => {
        const updatedAt = nowIso();

        set((state) => {
          const entry = state.codexEntries.find((candidate) => candidate.id === entryId);
          if (!entry) {
            return {};
          }

          return {
            codexEntries: state.codexEntries.map((candidate) =>
              candidate.id === entryId
                ? {
                    ...candidate,
                    ...updates,
                    codexNodeId:
                      updates.codexNodeId &&
                      state.codexNodes.some(
                        (node) => node.id === updates.codexNodeId && node.projectId === candidate.projectId,
                      )
                        ? updates.codexNodeId
                        : candidate.codexNodeId,
                    title:
                      updates.title !== undefined ? updates.title.trim() || 'Untitled Codex Entry' : candidate.title,
                    content: updates.content ?? candidate.content,
                    tags: updates.tags ?? candidate.tags,
                    updatedAt,
                  }
                : candidate,
            ),
            projects: updateProjectTimestamp(state.projects, entry.projectId, updatedAt),
            sync: markProjectDirty(state.sync, entry.projectId),
          };
        });
      },
      updateProject: (projectId, updates) => {
        const updatedAt = nowIso();

        set((state) => ({
          projects: state.projects.map((project) =>
            project.id === projectId
              ? {
                  ...project,
                  ...updates,
                  name: updates.name?.trim() || project.name,
                  updatedAt,
                }
              : project,
          ),
          sync: markProjectDirty(state.sync, projectId),
        }));
      },
      updateStructureNode: (nodeId, updates) => {
        const updatedAt = nowIso();

        set((state) => {
          const node = state.structureNodes.find((candidate) => candidate.id === nodeId);
          if (!node) {
            return {};
          }

          return {
            structureNodes: state.structureNodes.map((candidate) =>
              candidate.id === nodeId
                ? {
                    ...candidate,
                    ...updates,
                    title: updates.title !== undefined ? updates.title.trim() || candidate.title : candidate.title,
                    type: updates.type ?? candidate.type,
                    customTypeLabel:
                      updates.type === 'custom' || (updates.type === undefined && candidate.type === 'custom')
                        ? updates.customTypeLabel !== undefined
                          ? updates.customTypeLabel?.trim() || null
                          : candidate.customTypeLabel ?? null
                        : null,
                    updatedAt,
                  }
                : candidate,
            ),
            projects: updateProjectTimestamp(state.projects, node.projectId, updatedAt),
            sync: markProjectDirty(state.sync, node.projectId),
          };
        });
      },
      updateScene: (sceneId, updates) => {
        const updatedAt = nowIso();

        set((state) => {
          const scene = state.scenes.find((candidate) => candidate.id === sceneId);
          if (!scene) {
            return {};
          }

          const nextStructureNodeId =
            updates.structureNodeId !== undefined
              ? state.structureNodes.find(
                  (candidate) => candidate.id === updates.structureNodeId && candidate.projectId === scene.projectId,
                )?.id ?? scene.structureNodeId
              : scene.structureNodeId;

          return {
            scenes: state.scenes.map((candidate) =>
              candidate.id === sceneId
                ? {
                    ...candidate,
                    ...updates,
                    title: updates.title !== undefined ? updates.title.trim() || 'Untitled Scene' : candidate.title,
                    content: updates.content ?? candidate.content,
                    structureNodeId: nextStructureNodeId,
                    updatedAt,
                  }
                : candidate,
            ),
            projects: updateProjectTimestamp(state.projects, scene.projectId, updatedAt),
            sync: markProjectDirty(state.sync, scene.projectId),
          };
        });
      },
      deleteProject: (projectId) => {
        set((state) => ({
          projects: state.projects.filter((project) => project.id !== projectId),
          structureNodes: state.structureNodes.filter((node) => node.projectId !== projectId),
          scenes: state.scenes.filter((scene) => scene.projectId !== projectId),
          codexNodes: state.codexNodes.filter((node) => node.projectId !== projectId),
          codexEntries: state.codexEntries.filter((entry) => entry.projectId !== projectId),
          revisionSnapshots: state.revisionSnapshots.filter((snapshot) => snapshot.projectId !== projectId),
          backups: {
            ...state.backups,
            projectBackupExports: Object.fromEntries(
              Object.entries(state.backups.projectBackupExports).filter(([candidateProjectId]) => candidateProjectId !== projectId),
            ),
          },
          sync: {
            ...state.sync,
            projects: Object.fromEntries(
              Object.entries(state.sync.projects).filter(([candidateProjectId]) => candidateProjectId !== projectId),
            ),
            pendingDeletes: state.sync.pendingDeletes.includes(projectId)
              ? state.sync.pendingDeletes
              : [...state.sync.pendingDeletes, projectId],
          },
        }));
      },
      deleteStructureNode: (nodeId) => {
        const node = get().structureNodes.find((candidate) => candidate.id === nodeId);
        if (!node) {
          return;
        }

        const hasScenes = get().scenes.some((scene) => scene.structureNodeId === nodeId);
        const hasChildren = get().structureNodes.some((candidate) => candidate.parentId === nodeId);
        if (hasScenes || hasChildren) {
          return;
        }

        const updatedAt = nowIso();

        set((state) => ({
          structureNodes: state.structureNodes.filter((candidate) => candidate.id !== nodeId),
          projects: updateProjectTimestamp(state.projects, node.projectId, updatedAt),
          sync: markProjectDirty(state.sync, node.projectId),
        }));
      },
      deleteScene: (sceneId) => {
        const scene = get().scenes.find((entry) => entry.id === sceneId);
        if (!scene) {
          return;
        }

        const updatedAt = nowIso();

        set((state) => ({
          scenes: state.scenes.filter((entry) => entry.id !== sceneId),
          revisionSnapshots: state.revisionSnapshots.filter((snapshot) => snapshot.sceneId !== sceneId),
          projects: updateProjectTimestamp(state.projects, scene.projectId, updatedAt),
          sync: markProjectDirty(state.sync, scene.projectId),
        }));
      },
      deleteCodexNode: (nodeId) => {
        const node = get().codexNodes.find((candidate) => candidate.id === nodeId);
        if (!node) {
          return;
        }

        const projectNodes = get().codexNodes.filter((candidate) => candidate.projectId === node.projectId);
        const defaultNode = findDefaultCodexNode(projectNodes, node.projectId);
        const isDefaultNode = defaultNode?.id === nodeId;
        const hasChildren = get().codexNodes.some((candidate) => candidate.parentId === nodeId);
        const hasEntries = get().codexEntries.some((entry) => entry.codexNodeId === nodeId);
        if (isDefaultNode || hasChildren || hasEntries) {
          return;
        }

        const updatedAt = nowIso();

        set((state) => ({
          codexNodes: state.codexNodes.filter((candidate) => candidate.id !== nodeId),
          projects: updateProjectTimestamp(state.projects, node.projectId, updatedAt),
          sync: markProjectDirty(state.sync, node.projectId),
        }));
      },
      deleteCodexEntry: (entryId) => {
        const entry = get().codexEntries.find((candidate) => candidate.id === entryId);
        if (!entry) {
          return;
        }

        const updatedAt = nowIso();

        set((state) => ({
          codexEntries: state.codexEntries.filter((candidate) => candidate.id !== entryId),
          projects: updateProjectTimestamp(state.projects, entry.projectId, updatedAt),
          sync: markProjectDirty(state.sync, entry.projectId),
        }));
      },
      importProjectBackup: (backup) => {
        let importedProject: Project = backup.project;

        set((state) => {
          const result = importProjectBackupIntoState(state, backup);
          importedProject = result.project;
          return {
            ...result.state,
            sync: upsertProjectSyncMeta(state.sync, result.project.id, (current) => ({
              ...current,
              dirty: true,
              status: 'idle',
              error: null,
              changeToken: current.changeToken + 1,
            })),
          };
        });

        return importedProject;
      },
      getProjectById: (projectId) => get().projects.find((project) => project.id === projectId),
      getStructureNodeById: (nodeId) => get().structureNodes.find((node) => node.id === nodeId),
      getStructureNodesForProject: (projectId) => getProjectStructureNodes(get(), projectId),
      getCodexNodesForProject: (projectId) => getProjectCodexNodes(get(), projectId),
      getSceneById: (sceneId) => get().scenes.find((scene) => scene.id === sceneId),
      getCodexEntryById: (entryId) => get().codexEntries.find((entry) => entry.id === entryId),
      getScenesForProject: (projectId) =>
        get().scenes.filter((scene) => scene.projectId === projectId).sort((left, right) => {
          const updated = right.updatedAt.localeCompare(left.updatedAt);
          if (updated !== 0) {
            return updated;
          }

          return right.createdAt.localeCompare(left.createdAt);
        }),
      getRevisionSnapshotsForScene: (sceneId) =>
        sortSnapshotsNewestFirst(get().revisionSnapshots.filter((snapshot) => snapshot.sceneId === sceneId)),
      getCodexEntriesForProject: (projectId) =>
        get().codexEntries.filter((entry) => entry.projectId === projectId).sort((left, right) => {
          const updated = right.updatedAt.localeCompare(left.updatedAt);
          if (updated !== 0) {
            return updated;
          }

          return right.createdAt.localeCompare(left.createdAt);
        }),
      getProjectBundle: (projectId) => getProjectDataState(get(), projectId),
      applyRemoteProjectBundle: (incomingState, projectId, serverRevision) => {
        set((state) => replaceProjectDataState(state, incomingState, projectId, serverRevision));
      },
      requestProjectSync: (projectId) => {
        set((state) => ({
          sync: upsertProjectSyncMeta(state.sync, projectId, (current) => ({
            ...current,
            syncRequestToken: current.syncRequestToken + 1,
          })),
        }));
      },
      markProjectSyncing: (projectId) => {
        const currentChangeToken =
          get().sync.projects[projectId]?.changeToken ?? createDefaultProjectSyncMeta().changeToken;

        set((state) => ({
          sync: upsertProjectSyncMeta(state.sync, projectId, (current) => ({
            ...current,
            status: 'syncing',
            error: null,
          })),
        }));

        return currentChangeToken;
      },
      markProjectSyncSuccess: (projectId, serverRevision, syncedAt, syncedChangeToken) => {
        set((state) => ({
          sync: upsertProjectSyncMeta(state.sync, projectId, (current) => ({
            ...current,
            dirty: current.changeToken !== syncedChangeToken,
            status: 'idle',
            serverRevision,
            lastSyncAt: syncedAt,
            error: null,
          })),
        }));
      },
      markProjectSyncOffline: (projectId, error) => {
        set((state) => ({
          sync: {
            ...upsertProjectSyncMeta(state.sync, projectId, (current) => ({
              ...current,
              status: 'offline',
              error: error ?? 'The backend is currently unavailable.',
            })),
            backendStatus: 'offline',
          },
        }));
      },
      markProjectSyncConflict: (projectId, error) => {
        set((state) => ({
          sync: {
            ...upsertProjectSyncMeta(state.sync, projectId, (current) => ({
              ...current,
              dirty: true,
              status: 'conflict',
              error: error ?? 'The backend has a newer version of this project.',
            })),
            backendStatus: 'online',
          },
        }));
      },
      setBackendStatus: (status) => {
        set((state) => ({
          sync: {
            ...state.sync,
            backendStatus: status,
          },
        }));
      },
      setHydrationState: (status) => {
        set((state) => ({
          sync: {
            ...state.sync,
            hydrationState: status,
          },
        }));
      },
      clearPendingDelete: (projectId) => {
        set((state) => ({
          sync: {
            ...state.sync,
            pendingDeletes: state.sync.pendingDeletes.filter((candidate) => candidate !== projectId),
          },
        }));
      },
      recordDiagnosticEvent: (event) => {
        set((state) => ({
          diagnostics: appendDiagnosticEvent(state.diagnostics, {
            type: event.type,
            projectId: event.projectId ?? null,
            status: event.status ?? null,
            message: event.message ?? null,
          }),
        }));
      },
    }),
    {
      name: 'loreloom-storage',
      storage: createSafePersistStorage<LoreLoomPersistedState>(),
      version: 9,
      migrate: (persistedState) => normalizeState(persistedState as Partial<LoreLoomPersistedState> | undefined),
    },
  ),
);
