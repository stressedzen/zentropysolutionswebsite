import { useId, useState } from 'react';

type PasswordFieldProps = {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  autoComplete?: string;
  helperText?: string;
  name?: string;
};

export default function PasswordField({
  label,
  value,
  onChange,
  placeholder,
  autoComplete,
  helperText,
  name,
}: PasswordFieldProps) {
  const fieldId = useId();
  const [visible, setVisible] = useState(false);

  return (
    <div className="block space-y-2 text-sm text-slate-200">
      <label htmlFor={fieldId}>
        <span>{label}</span>
      </label>
      <div className="relative">
        <input
          id={fieldId}
          name={name}
          type={visible ? 'text' : 'password'}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className="app-input app-focus-ring w-full rounded-xl px-4 py-3 pr-20 text-sm"
          placeholder={placeholder}
          autoComplete={autoComplete}
        />
        <button
          type="button"
          onClick={() => setVisible((current) => !current)}
          aria-label={visible ? `Hide ${label.toLowerCase()}` : `Show ${label.toLowerCase()}`}
          aria-pressed={visible}
          className="absolute inset-y-0 right-0 inline-flex items-center rounded-r-xl border-l border-[color:var(--app-border)] px-3 text-xs font-medium text-slate-200 transition hover:bg-white/[0.05] focus:outline-none focus:ring-2 focus:ring-[rgba(198,154,84,0.28)]"
        >
          {visible ? 'Hide' : 'Show'}
        </button>
      </div>
      {helperText ? <p className="text-xs leading-5 text-slate-400">{helperText}</p> : null}
    </div>
  );
}
