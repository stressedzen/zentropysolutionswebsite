import { buildApp } from './app.js';
import { loadConfig } from './config.js';
import { createDatabase } from './db/client.js';
import { runMigrations } from './db/migrate.js';

async function main() {
  const config = loadConfig();
  const database = createDatabase(config.databasePath);

  runMigrations(database);

  const app = await buildApp({
    config,
    database,
  });

  try {
    await app.listen({
      host: config.host,
      port: config.port,
    });
  } catch (error) {
    app.log.error(error);
    await app.close();
    process.exitCode = 1;
  }
}

main();
