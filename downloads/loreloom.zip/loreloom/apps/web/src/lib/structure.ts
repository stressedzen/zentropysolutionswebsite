import { makeId, nowIso } from './storage';
import type { Scene, StructureNode, StructureNodeType } from './types';

export const DEFAULT_STRUCTURE_NODE_TITLE = 'Chapter 1';
export const DEFAULT_STRUCTURE_NODE_TYPE: StructureNodeType = 'chapter';

export type StructureNodeTreeItem = StructureNode & {
  children: StructureNodeTreeItem[];
};

export function createDefaultStructureNode(projectId: string, timestamp = nowIso()): StructureNode {
  return {
    id: makeId(),
    projectId,
    parentId: null,
    type: DEFAULT_STRUCTURE_NODE_TYPE,
    customTypeLabel: null,
    title: DEFAULT_STRUCTURE_NODE_TITLE,
    orderIndex: 0,
    createdAt: timestamp,
    updatedAt: timestamp,
  };
}

export function getStructureNodeTypeLabel(node: Pick<StructureNode, 'type' | 'customTypeLabel'>) {
  if (node.type === 'custom') {
    return node.customTypeLabel?.trim() || 'Custom';
  }

  switch (node.type) {
    case 'book':
      return 'Book';
    case 'part':
      return 'Part';
    case 'act':
      return 'Act';
    case 'chapter':
      return 'Chapter';
    case 'sequence':
      return 'Sequence';
    case 'section':
      return 'Section';
  }
}

function compareStructureNodes(left: StructureNode, right: StructureNode) {
  if (left.orderIndex !== right.orderIndex) {
    return left.orderIndex - right.orderIndex;
  }

  const created = left.createdAt.localeCompare(right.createdAt);
  if (created !== 0) {
    return created;
  }

  return left.title.localeCompare(right.title);
}

export function getNextStructureOrderIndex(nodes: StructureNode[], parentId: string | null) {
  return nodes
    .filter((node) => node.parentId === parentId)
    .reduce((max, node) => Math.max(max, node.orderIndex), -1) + 1;
}

export function getSortedStructureNodesForProject(nodes: StructureNode[], projectId: string) {
  return nodes
    .filter((node) => node.projectId === projectId)
    .sort(compareStructureNodes);
}

export function buildStructureNodeTree(nodes: StructureNode[]): StructureNodeTreeItem[] {
  const byId = new Map(nodes.map((node) => [node.id, node]));
  const grouped = new Map<string | null, StructureNode[]>();

  for (const node of nodes) {
    const parentId = node.parentId && byId.has(node.parentId) ? node.parentId : null;
    const current = grouped.get(parentId) ?? [];
    current.push(node);
    grouped.set(parentId, current);
  }

  const build = (parentId: string | null): StructureNodeTreeItem[] => {
    const children = (grouped.get(parentId) ?? []).slice().sort(compareStructureNodes);
    return children.map((node) => ({
      ...node,
      children: build(node.id),
    }));
  };

  return build(null);
}

export function flattenStructureNodeTree(nodes: StructureNodeTreeItem[]) {
  const flat: Array<{ node: StructureNodeTreeItem; depth: number }> = [];

  const visit = (list: StructureNodeTreeItem[], depth: number) => {
    for (const node of list) {
      flat.push({ node, depth });
      visit(node.children, depth + 1);
    }
  };

  visit(nodes, 0);
  return flat;
}

export function sortStructureNodesForExport(nodes: StructureNode[]) {
  return flattenStructureNodeTree(buildStructureNodeTree(nodes)).map(({ node }) => ({
    id: node.id,
    projectId: node.projectId,
    parentId: node.parentId,
    type: node.type,
    customTypeLabel: node.customTypeLabel ?? null,
    title: node.title,
    orderIndex: node.orderIndex,
    createdAt: node.createdAt,
    updatedAt: node.updatedAt,
  }));
}

export function findDefaultStructureNode(nodes: StructureNode[], projectId: string) {
  const projectNodes = getSortedStructureNodesForProject(nodes, projectId);
  return projectNodes[0] ?? null;
}

export function findStructureNodeByScene(nodes: StructureNode[], scene: Pick<Scene, 'structureNodeId'>) {
  return nodes.find((node) => node.id === scene.structureNodeId) ?? null;
}
