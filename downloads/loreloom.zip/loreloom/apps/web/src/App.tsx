import { Link, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import AuthGate from './components/AuthGate';
import LoreLoomLogo from './components/LoreLoomLogo';
import ProjectSyncManager from './components/ProjectSyncManager';
import SyncStatusBadge from './components/SyncStatusBadge';
import WritingAppearanceManager from './components/WritingAppearanceManager';
import type { AuthenticatedUser } from './lib/api';
import DashboardPage from './pages/DashboardPage';
import DiagnosticsPage from './pages/DiagnosticsPage';
import AdminUsersPage from './pages/AdminUsersPage';
import AccountSettingsPage from './pages/AccountSettingsPage';
import ProjectPage from './pages/ProjectPage';
import ProjectPreviewPage from './pages/ProjectPreviewPage';
import ScenePage from './pages/ScenePage';

function Shell({
  children,
  currentUser,
  onLogout,
}: {
  children: ReactNode;
  currentUser: AuthenticatedUser;
  onLogout: () => Promise<void>;
}) {
  const location = useLocation();
  const isFocusMode =
    location.pathname.includes('/scenes/') && new URLSearchParams(location.search).get('focus') === '1';
  const userLabel = currentUser.displayName?.trim() || currentUser.username;
  const isAdmin = currentUser.role === 'admin';

  return (
    <div className="app-shell min-h-screen text-slate-100">
      <div className={`mx-auto flex min-h-screen w-full flex-col ${isFocusMode ? 'max-w-7xl px-4 py-4 sm:px-6 lg:px-8' : 'max-w-6xl px-4 py-6 sm:px-6 lg:px-8'}`}>
        {!isFocusMode ? (
          <header className="app-nav mb-6 flex flex-col gap-2 rounded-2xl px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
            <Link to="/" className="inline-flex shrink-0 items-center">
              <LoreLoomLogo className="h-12 sm:h-[3.25rem]" />
            </Link>
            <div className="flex flex-wrap items-center gap-3">
              {isAdmin ? (
                <Link to="/admin/users" className="app-link text-sm underline underline-offset-4">
                  Admin
                </Link>
              ) : null}
              <Link to="/settings" className="app-link text-sm underline underline-offset-4">
                Account
              </Link>
              <Link to="/diagnostics" className="app-link text-sm underline underline-offset-4">
                Diagnostics
              </Link>
              <span className="text-sm text-slate-400">Signed in as {userLabel}</span>
              <button
                type="button"
                onClick={() => {
                  void onLogout();
                }}
                className="app-link text-sm underline underline-offset-4"
              >
                Log out
              </button>
              <SyncStatusBadge />
            </div>
          </header>
        ) : null}
        <main className="flex-1">{children}</main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthGate>
      {({ currentUser, logout }) => (
        <Shell currentUser={currentUser} onLogout={logout}>
          <WritingAppearanceManager />
          <ProjectSyncManager />
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route
              path="/admin/users"
              element={currentUser.role === 'admin' ? <AdminUsersPage /> : <Navigate to="/" replace />}
            />
            <Route path="/settings" element={<AccountSettingsPage currentUser={currentUser} />} />
            <Route path="/diagnostics" element={<DiagnosticsPage />} />
            <Route path="/projects/:projectId" element={<ProjectPage />} />
            <Route path="/projects/:projectId/preview" element={<ProjectPreviewPage />} />
            <Route path="/projects/:projectId/scenes/:sceneId" element={<ScenePage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Shell>
      )}
    </AuthGate>
  );
}
