CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  server_revision INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS projects_updated_at_idx ON projects(updated_at);

CREATE TABLE IF NOT EXISTS structure_nodes (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  parent_id TEXT NULL,
  type TEXT NOT NULL,
  custom_type_label TEXT NULL,
  title TEXT NOT NULL,
  order_index INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_id) REFERENCES structure_nodes(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS structure_nodes_project_id_idx ON structure_nodes(project_id);
CREATE INDEX IF NOT EXISTS structure_nodes_parent_id_idx ON structure_nodes(parent_id);
CREATE INDEX IF NOT EXISTS structure_nodes_project_parent_order_idx
  ON structure_nodes(project_id, parent_id, order_index);

CREATE TABLE IF NOT EXISTS text_blocks (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  structure_node_id TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (structure_node_id) REFERENCES structure_nodes(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS text_blocks_project_id_idx ON text_blocks(project_id);
CREATE INDEX IF NOT EXISTS text_blocks_structure_node_id_idx ON text_blocks(structure_node_id);
CREATE INDEX IF NOT EXISTS text_blocks_updated_at_idx ON text_blocks(updated_at);

CREATE TABLE IF NOT EXISTS codex_entries (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  title TEXT NOT NULL,
  type TEXT NOT NULL,
  content TEXT NOT NULL,
  tags_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS codex_entries_project_id_idx ON codex_entries(project_id);
CREATE INDEX IF NOT EXISTS codex_entries_updated_at_idx ON codex_entries(updated_at);
CREATE INDEX IF NOT EXISTS codex_entries_title_idx ON codex_entries(title);

CREATE TABLE IF NOT EXISTS revision_snapshots (
  id TEXT PRIMARY KEY,
  scene_id TEXT NOT NULL,
  project_id TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (scene_id) REFERENCES text_blocks(id) ON DELETE CASCADE,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS revision_snapshots_scene_id_idx ON revision_snapshots(scene_id);
CREATE INDEX IF NOT EXISTS revision_snapshots_project_id_idx ON revision_snapshots(project_id);
CREATE INDEX IF NOT EXISTS revision_snapshots_scene_created_at_idx
  ON revision_snapshots(scene_id, created_at DESC);
