import { createDefaultCodexNode, sortCodexNodesForExport } from './codex';
import { createDefaultStructureNode, sortStructureNodesForExport } from './structure';
import { makeId, nowIso, sortByUpdatedThenCreated } from './storage';
import { stripHtmlToPlainText } from './writing-stats';
import type {
  CodexEntry,
  CodexNode,
  LoreLoomState,
  Project,
  ProjectBackup,
  RevisionSnapshot,
  Scene,
  StructureNode,
} from './types';

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isString(value: unknown): value is string {
  return typeof value === 'string';
}

function isProject(value: unknown): value is Project {
  return (
    isRecord(value) &&
    isString(value.id) &&
    isString(value.name) &&
    isString(value.createdAt) &&
    isString(value.updatedAt)
  );
}

function isStructureNode(value: unknown): value is StructureNode {
  return (
    isRecord(value) &&
    isString(value.id) &&
    isString(value.projectId) &&
    (value.parentId === null || isString(value.parentId)) &&
    isString(value.type) &&
    (value.customTypeLabel === undefined || value.customTypeLabel === null || isString(value.customTypeLabel)) &&
    isString(value.title) &&
    typeof value.orderIndex === 'number' &&
    isString(value.createdAt) &&
    isString(value.updatedAt)
  );
}

function isSceneV3(value: unknown): value is Scene {
  return (
    isRecord(value) &&
    isString(value.id) &&
    isString(value.projectId) &&
    isString(value.structureNodeId) &&
    isString(value.title) &&
    isString(value.content) &&
    isString(value.createdAt) &&
    isString(value.updatedAt)
  );
}

function isLegacyScene(value: unknown): boolean {
  return (
    isRecord(value) &&
    isString(value.id) &&
    isString(value.projectId) &&
    isString(value.title) &&
    isString(value.content) &&
    isString(value.createdAt) &&
    isString(value.updatedAt)
  );
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every(isString);
}

function isFlatCodexEntry(value: unknown): boolean {
  return (
    isRecord(value) &&
    isString(value.id) &&
    isString(value.projectId) &&
    isString(value.type) &&
    isString(value.title) &&
    isString(value.content) &&
    isStringArray(value.tags) &&
    isString(value.createdAt) &&
    isString(value.updatedAt)
  );
}

function isCodexEntryWithNode(value: unknown): value is CodexEntry {
  return (
    isRecord(value) &&
    isString(value.id) &&
    isString(value.projectId) &&
    isString(value.codexNodeId) &&
    isString(value.type) &&
    isString(value.title) &&
    isString(value.content) &&
    isStringArray(value.tags) &&
    isString(value.createdAt) &&
    isString(value.updatedAt)
  );
}

function isCodexEntryV1(value: unknown): boolean {
  return (
    isRecord(value) &&
    isString(value.id) &&
    isString(value.projectId) &&
    isString(value.type) &&
    isString(value.title) &&
    isString(value.content) &&
    isString(value.createdAt) &&
    isString(value.updatedAt)
  );
}

function isCodexNode(value: unknown): value is CodexNode {
  return (
    isRecord(value) &&
    isString(value.id) &&
    isString(value.projectId) &&
    (value.parentId === null || isString(value.parentId)) &&
    isString(value.type) &&
    (value.customTypeLabel === undefined || value.customTypeLabel === null || isString(value.customTypeLabel)) &&
    isString(value.title) &&
    isStringArray(value.tags) &&
    typeof value.orderIndex === 'number' &&
    isString(value.createdAt) &&
    isString(value.updatedAt)
  );
}

function isRevisionSnapshotV4(value: unknown): value is RevisionSnapshot {
  return (
    isRecord(value) &&
    isString(value.id) &&
    isString(value.sceneId) &&
    isString(value.projectId) &&
    isString(value.title) &&
    isString(value.content) &&
    isString(value.createdAt)
  );
}

function uniqueId(usedIds: Set<string>) {
  let id = makeId();
  while (usedIds.has(id)) {
    id = makeId();
  }

  usedIds.add(id);
  return id;
}

function filenameFromTitle(title: string) {
  const cleaned = title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

  return cleaned || 'loreloom-project';
}

function normalizeLegacyCodex(project: Project, entries: unknown[], version: number, exportedAt: string) {
  const defaultCodexNode = createDefaultCodexNode(project.id, exportedAt);

  return {
    codexNodes: [defaultCodexNode],
    codexEntries: entries.map((entry) => {
      const baseEntry = entry as CodexEntry;
      return {
        ...baseEntry,
        codexNodeId: defaultCodexNode.id,
        tags: version === 1 ? [] : Array.isArray(baseEntry.tags) ? baseEntry.tags : [],
      };
    }),
  };
}

function normalizeLegacyScenes(project: Project, scenes: unknown[], exportedAt: string) {
  const defaultStructureNode = createDefaultStructureNode(project.id, exportedAt);

  return {
    structureNodes: [defaultStructureNode],
    scenes: scenes.map((scene) => ({
      ...(scene as Omit<Scene, 'structureNodeId'>),
      structureNodeId: defaultStructureNode.id,
    })),
  };
}

export function downloadTextFile(filename: string, content: string, mimeType = 'text/plain;charset=utf-8') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');

  anchor.href = url;
  anchor.download = filename;
  anchor.rel = 'noreferrer';
  anchor.style.display = 'none';

  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

export function sortScenesForExport(scenes: Scene[]) {
  return sortByUpdatedThenCreated(scenes);
}

export function createProjectBackup(
  project: Project,
  structureNodes: StructureNode[],
  scenes: Scene[],
  codexNodes: CodexNode[],
  codexEntries: CodexEntry[],
  revisionSnapshots: RevisionSnapshot[],
): ProjectBackup {
  return {
    format: 'LoreLoom Project Backup',
    version: 5,
    exportedAt: nowIso(),
    project,
    structureNodes: sortStructureNodesForExport(structureNodes),
    scenes: sortScenesForExport(scenes),
    codexNodes: sortCodexNodesForExport(codexNodes),
    codexEntries: codexEntries.map((entry) => ({ ...entry })),
    revisionSnapshots: revisionSnapshots.map((snapshot) => ({ ...snapshot })),
  };
}

export function serializeProjectBackup(backup: ProjectBackup) {
  return `${JSON.stringify(backup, null, 2)}\n`;
}

export function exportProjectBackupFile(
  project: Project,
  structureNodes: StructureNode[],
  scenes: Scene[],
  codexNodes: CodexNode[],
  codexEntries: CodexEntry[],
  revisionSnapshots: RevisionSnapshot[],
) {
  const backup = createProjectBackup(project, structureNodes, scenes, codexNodes, codexEntries, revisionSnapshots);
  const filename = `${filenameFromTitle(project.name)}-backup.json`;
  downloadTextFile(filename, serializeProjectBackup(backup), 'application/json;charset=utf-8');
}

export function exportProjectStoryText(project: Project, structureNodes: StructureNode[], scenes: Scene[]) {
  const orderedScenes = sortScenesForExport(scenes);
  const lines: string[] = [project.name, ''];
  const nodeTree = sortStructureNodesForExport(structureNodes);
  const projectNodeMap = new Map(nodeTree.map((node) => [node.id, node]));
  const childrenByParent = new Map<string | null, StructureNode[]>();

  for (const node of nodeTree) {
    const parentId = node.parentId && projectNodeMap.has(node.parentId) ? node.parentId : null;
    const list = childrenByParent.get(parentId) ?? [];
    list.push(node);
    childrenByParent.set(parentId, list);
  }

  const scenesByNode = new Map<string, Scene[]>();
  for (const scene of orderedScenes) {
    const node = projectNodeMap.has(scene.structureNodeId) ? scene.structureNodeId : nodeTree[0]?.id;
    if (!node) {
      continue;
    }

    const list = scenesByNode.get(node) ?? [];
    list.push(scene);
    scenesByNode.set(node, list);
  }

  const renderNode = (nodeId: string, depth: number) => {
    const node = projectNodeMap.get(nodeId);
    if (!node) {
      return;
    }

    const indent = '  '.repeat(depth);
    lines.push(`${indent}${node.title}`);

    const nodeScenes = scenesByNode.get(node.id) ?? [];
    for (const scene of nodeScenes) {
      lines.push(`${indent}  ${scene.title}`);
      const text = stripHtmlToPlainText(scene.content);
      if (text) {
        for (const line of text.split('\n')) {
          lines.push(`${indent}    ${line}`);
        }
      }
      lines.push('');
    }

    const children = childrenByParent.get(node.id) ?? [];
    for (const child of children) {
      lines.push('');
      renderNode(child.id, depth + 1);
    }
  };

  const rootNodes = childrenByParent.get(null) ?? [];
  if (rootNodes.length === 0) {
    if (orderedScenes.length > 0 && nodeTree[0]) {
      renderNode(nodeTree[0].id, 0);
    } else if (orderedScenes.length > 0) {
      for (const scene of orderedScenes) {
        lines.push(scene.title);
        const text = stripHtmlToPlainText(scene.content);
        if (text) {
          lines.push('');
          lines.push(text);
        }
        lines.push('');
      }
    }
  } else {
    for (const node of rootNodes) {
      renderNode(node.id, 0);
      lines.push('');
    }
  }

  return lines.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
}

export function exportProjectStoryFile(project: Project, structureNodes: StructureNode[], scenes: Scene[]) {
  const filename = `${filenameFromTitle(project.name)}.txt`;
  downloadTextFile(filename, exportProjectStoryText(project, structureNodes, scenes));
}

export function parseProjectBackup(input: string): { ok: true; backup: ProjectBackup } | { ok: false; error: string } {
  let parsed: unknown;
  try {
    parsed = JSON.parse(input);
  } catch {
    return { ok: false, error: 'The file is not valid JSON.' };
  }

  if (!isRecord(parsed)) {
    return { ok: false, error: 'The backup file must contain a JSON object.' };
  }

  if (parsed.format !== 'LoreLoom Project Backup') {
    return { ok: false, error: 'This file is not a LoreLoom project backup.' };
  }

  if (parsed.version !== 1 && parsed.version !== 2 && parsed.version !== 3 && parsed.version !== 4 && parsed.version !== 5) {
    return { ok: false, error: 'This backup version is not supported yet.' };
  }

  if (!isString(parsed.exportedAt) || !isProject(parsed.project) || !Array.isArray(parsed.scenes)) {
    return { ok: false, error: 'The backup file is missing required project data.' };
  }

  if (!Array.isArray(parsed.codexEntries)) {
    return { ok: false, error: 'The backup file is missing its codex placeholder array.' };
  }

  if (parsed.version === 5) {
    if (!Array.isArray(parsed.structureNodes)) {
      return { ok: false, error: 'The backup file is missing its structure nodes.' };
    }

    if (!parsed.structureNodes.every(isStructureNode)) {
      return { ok: false, error: 'One or more structure nodes in the backup are invalid.' };
    }

    if (!parsed.scenes.every(isSceneV3)) {
      return { ok: false, error: 'One or more scenes in the backup are invalid.' };
    }

    if (!Array.isArray(parsed.codexNodes)) {
      return { ok: false, error: 'The backup file is missing its codex nodes.' };
    }

    if (!parsed.codexNodes.every(isCodexNode)) {
      return { ok: false, error: 'One or more codex nodes in the backup are invalid.' };
    }

    if (!parsed.codexEntries.every(isCodexEntryWithNode)) {
      return { ok: false, error: 'One or more codex entries in the backup are invalid.' };
    }

    if (!Array.isArray(parsed.revisionSnapshots)) {
      return { ok: false, error: 'The backup file is missing its revision snapshots.' };
    }

    if (!parsed.revisionSnapshots.every(isRevisionSnapshotV4)) {
      return { ok: false, error: 'One or more revision snapshots in the backup are invalid.' };
    }

    return {
      ok: true,
      backup: {
        format: 'LoreLoom Project Backup',
        version: 5,
        exportedAt: parsed.exportedAt,
        project: parsed.project,
        structureNodes: sortStructureNodesForExport(parsed.structureNodes),
        scenes: parsed.scenes,
        codexNodes: sortCodexNodesForExport(parsed.codexNodes),
        codexEntries: parsed.codexEntries,
        revisionSnapshots: parsed.revisionSnapshots,
      },
    };
  }

  if (parsed.version === 4 || parsed.version === 3) {
    if (!Array.isArray(parsed.structureNodes)) {
      return { ok: false, error: 'The backup file is missing its structure nodes.' };
    }

    if (!parsed.structureNodes.every(isStructureNode)) {
      return { ok: false, error: 'One or more structure nodes in the backup are invalid.' };
    }

    if (!parsed.scenes.every(isSceneV3)) {
      return { ok: false, error: 'One or more scenes in the backup are invalid.' };
    }

    if (!parsed.codexEntries.every(isFlatCodexEntry)) {
      return { ok: false, error: 'One or more codex entries in the backup are invalid.' };
    }

    if (parsed.version === 4) {
      if (!Array.isArray(parsed.revisionSnapshots)) {
        return { ok: false, error: 'The backup file is missing its revision snapshots.' };
      }

      if (!parsed.revisionSnapshots.every(isRevisionSnapshotV4)) {
        return { ok: false, error: 'One or more revision snapshots in the backup are invalid.' };
      }
    }

    const normalizedCodex = normalizeLegacyCodex(parsed.project, parsed.codexEntries, 2, parsed.exportedAt);
    const revisionSnapshots = parsed.version === 4 ? (parsed.revisionSnapshots as RevisionSnapshot[]) : [];

    return {
      ok: true,
      backup: {
        format: 'LoreLoom Project Backup',
        version: 5,
        exportedAt: parsed.exportedAt,
        project: parsed.project,
        structureNodes: sortStructureNodesForExport(parsed.structureNodes),
        scenes: parsed.scenes,
        codexNodes: normalizedCodex.codexNodes,
        codexEntries: normalizedCodex.codexEntries,
        revisionSnapshots,
      },
    };
  }

  if (!parsed.scenes.every(isLegacyScene)) {
    return { ok: false, error: 'One or more scenes in the backup are invalid.' };
  }

  const codexEntriesValid =
    parsed.version === 1 ? parsed.codexEntries.every(isCodexEntryV1) : parsed.codexEntries.every(isFlatCodexEntry);
  if (!codexEntriesValid) {
    return { ok: false, error: 'One or more codex entries in the backup are invalid.' };
  }

  const legacyStructure = normalizeLegacyScenes(parsed.project, parsed.scenes, parsed.exportedAt);
  const legacyCodex = normalizeLegacyCodex(parsed.project, parsed.codexEntries, parsed.version, parsed.exportedAt);

  return {
    ok: true,
    backup: {
      format: 'LoreLoom Project Backup',
      version: 5,
      exportedAt: parsed.exportedAt,
      project: parsed.project,
      structureNodes: legacyStructure.structureNodes,
      scenes: legacyStructure.scenes as Scene[],
      codexNodes: legacyCodex.codexNodes,
      codexEntries: legacyCodex.codexEntries,
      revisionSnapshots: [],
    },
  };
}

export function importProjectBackupIntoState(state: LoreLoomState, backup: ProjectBackup) {
  const usedIds = new Set<string>([
    ...state.projects.map((project) => project.id),
    ...state.structureNodes.map((node) => node.id),
    ...state.scenes.map((scene) => scene.id),
    ...state.codexNodes.map((node) => node.id),
    ...state.codexEntries.map((entry) => entry.id),
    ...state.revisionSnapshots.map((snapshot) => snapshot.id),
  ]);

  const projectId = usedIds.has(backup.project.id) ? uniqueId(usedIds) : backup.project.id;
  if (!usedIds.has(projectId)) {
    usedIds.add(projectId);
  }

  const project: Project = {
    ...backup.project,
    id: projectId,
  };

  const structureNodeIdMap = new Map<string, string>();
  const structureNodes = backup.structureNodes.map((node) => {
    const nodeId = usedIds.has(node.id) ? uniqueId(usedIds) : node.id;
    structureNodeIdMap.set(node.id, nodeId);
    if (!usedIds.has(nodeId)) {
      usedIds.add(nodeId);
    }

    return {
      ...node,
      id: nodeId,
      projectId,
      parentId: node.parentId ? node.parentId : null,
    };
  });

  let importedStructureNodes = structureNodes.map((node) => {
    const parentId = node.parentId ? structureNodeIdMap.get(node.parentId) ?? null : null;

    return {
      ...node,
      parentId: parentId && parentId !== node.id ? parentId : null,
    };
  });

  if (importedStructureNodes.length === 0 && backup.scenes.length > 0) {
    const defaultStructureNode = createDefaultStructureNode(projectId, backup.exportedAt);
    if (!usedIds.has(defaultStructureNode.id)) {
      usedIds.add(defaultStructureNode.id);
    }

    importedStructureNodes = [defaultStructureNode];
  }

  const defaultStructureNodeId = importedStructureNodes[0]?.id ?? null;
  const codexNodeIdMap = new Map<string, string>();
  let importedCodexNodes: CodexNode[] = backup.codexNodes.map((node) => {
    const nodeId = usedIds.has(node.id) ? uniqueId(usedIds) : node.id;
    codexNodeIdMap.set(node.id, nodeId);
    if (!usedIds.has(nodeId)) {
      usedIds.add(nodeId);
    }

    return {
      ...node,
      id: nodeId,
      projectId,
      parentId: node.parentId ? node.parentId : null,
      customTypeLabel: node.customTypeLabel ?? null,
      tags: Array.isArray(node.tags) ? node.tags : [],
    };
  });

  importedCodexNodes = importedCodexNodes.map((node) => {
    const parentId = node.parentId ? codexNodeIdMap.get(node.parentId) ?? null : null;

    return {
      ...node,
      parentId: parentId && parentId !== node.id ? parentId : null,
    };
  });

  if (importedCodexNodes.length === 0) {
    const defaultCodexNode = createDefaultCodexNode(projectId, backup.exportedAt);
    if (!usedIds.has(defaultCodexNode.id)) {
      usedIds.add(defaultCodexNode.id);
    }

    importedCodexNodes = [defaultCodexNode];
  }

  const defaultCodexNodeId = importedCodexNodes[0]?.id ?? null;

  const scenes = backup.scenes.map((scene) => {
    const sceneId = usedIds.has(scene.id) ? uniqueId(usedIds) : scene.id;
    if (!usedIds.has(sceneId)) {
      usedIds.add(sceneId);
    }

    const nextStructureNodeId =
      structureNodeIdMap.get(scene.structureNodeId) ??
      (importedStructureNodes.some((node) => node.id === scene.structureNodeId) ? scene.structureNodeId : defaultStructureNodeId);

    return {
      ...scene,
      id: sceneId,
      projectId,
      structureNodeId: nextStructureNodeId ?? scene.structureNodeId,
    };
  });

  const codexEntries = backup.codexEntries.map((entry) => {
    const entryId = usedIds.has(entry.id) ? uniqueId(usedIds) : entry.id;
    if (!usedIds.has(entryId)) {
      usedIds.add(entryId);
    }

    return {
      ...entry,
      id: entryId,
      projectId,
      codexNodeId:
        codexNodeIdMap.get(entry.codexNodeId) ??
        (importedCodexNodes.some((node) => node.id === entry.codexNodeId) ? entry.codexNodeId : defaultCodexNodeId) ??
        entry.codexNodeId,
      tags: Array.isArray(entry.tags) ? entry.tags : [],
    };
  });

  const sceneIdMap = new Map<string, string>(backup.scenes.map((scene, index) => [scene.id, scenes[index].id]));

  const revisionSnapshots = (backup.revisionSnapshots ?? [])
    .map((snapshot) => {
      const sceneId = sceneIdMap.get(snapshot.sceneId);
      if (!sceneId) {
        return null;
      }

      const snapshotId = usedIds.has(snapshot.id) ? uniqueId(usedIds) : snapshot.id;
      if (!usedIds.has(snapshotId)) {
        usedIds.add(snapshotId);
      }

      return {
        ...snapshot,
        id: snapshotId,
        sceneId,
        projectId,
      };
    })
    .filter((snapshot): snapshot is RevisionSnapshot => snapshot !== null);

  return {
    project,
    state: {
      projects: [project, ...state.projects],
      structureNodes: [...importedStructureNodes, ...state.structureNodes],
      scenes: [...scenes, ...state.scenes],
      codexNodes: [...importedCodexNodes, ...state.codexNodes],
      codexEntries: [...codexEntries, ...state.codexEntries],
      revisionSnapshots: [...revisionSnapshots, ...state.revisionSnapshots],
    },
  };
}
