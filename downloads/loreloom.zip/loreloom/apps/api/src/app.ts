import Fastify, { type FastifyInstance } from 'fastify';
import type { AppConfig } from './config.js';
import type { SqliteDatabase } from './db/pragmas.js';
import { registerAdminUserRoutes } from './routes/admin-users.js';
import { registerAuthRoutes } from './routes/auth.js';
import { registerDiagnosticsRoute } from './routes/diagnostics.js';
import { registerHealthRoute } from './routes/health.js';
import { registerProjectRoutes } from './routes/projects.js';

export type BuildAppOptions = {
  config: AppConfig;
  database: SqliteDatabase;
};

export async function buildApp({ config, database }: BuildAppOptions): Promise<FastifyInstance> {
  const app = Fastify({
    bodyLimit: config.maxRequestBodyBytes,
    logger:
      config.nodeEnv === 'test'
        ? false
        : {
            level: config.logLevel,
            base: {
              service: config.appName,
            },
            redact: ['req.headers.authorization', 'req.headers.cookie'],
          },
  });

  if (config.devCorsOrigin) {
    app.addHook('onRequest', async (request, reply) => {
      const origin = request.headers.origin;
      if (origin && origin === config.devCorsOrigin) {
        reply.header('Access-Control-Allow-Origin', config.devCorsOrigin);
        reply.header('Vary', 'Origin');
        reply.header('Access-Control-Allow-Headers', 'Content-Type');
        reply.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
        reply.header('Access-Control-Allow-Credentials', 'true');
      }

      if (request.method === 'OPTIONS') {
        return reply.code(204).send();
      }
    });
  }

  await registerHealthRoute(app, config);
  await registerAuthRoutes(app, database, config);
  await registerAdminUserRoutes(app, database, config);
  await registerDiagnosticsRoute(app, config);
  await registerProjectRoutes(app, database, config);

  app.get('/', async () => {
    return {
      appName: config.appName,
      status: 'ok',
    };
  });

  app.setNotFoundHandler(async (_request, reply) => {
    return reply.code(404).send({
      error: 'not_found',
      message: 'Route not found.',
    });
  });

  app.setErrorHandler(async (error, request, reply) => {
    request.log.error(
      {
        err: error,
      },
      'Request failed',
    );

    if (error instanceof Error && 'statusCode' in error && typeof error.statusCode === 'number') {
      if ((error as { code?: string }).code === 'FST_ERR_CTP_BODY_TOO_LARGE') {
        return reply.code(413).send({
          error: 'payload_too_large',
          message: `Request body exceeds the ${config.maxRequestBodyBytes}-byte limit.`,
        });
      }

      return reply.code(error.statusCode).send({
        error: 'request_error',
        message: error.message,
      });
    }

    return reply.code(500).send({
      error: 'internal_error',
      message: 'The server could not complete the request.',
    });
  });

  app.addHook('onClose', async () => {
    database.close();
  });

  return app;
}
