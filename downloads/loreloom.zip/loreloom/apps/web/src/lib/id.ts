function buildFallbackId(prefix?: string) {
  const timestamp = Date.now().toString(36);
  const randomPart = Math.random().toString(36).slice(2, 10);
  const normalizedPrefix = prefix?.trim();

  return normalizedPrefix ? `${normalizedPrefix}-${timestamp}-${randomPart}` : `${timestamp}-${randomPart}`;
}

export function createId(prefix?: string) {
  const normalizedPrefix = prefix?.trim();

  try {
    if (
      typeof globalThis.crypto !== 'undefined' &&
      typeof globalThis.crypto.randomUUID === 'function'
    ) {
      const value = globalThis.crypto.randomUUID();
      return normalizedPrefix ? `${normalizedPrefix}-${value}` : value;
    }
  } catch {
    // Fall through to the local-safe fallback below.
  }

  return buildFallbackId(normalizedPrefix);
}
