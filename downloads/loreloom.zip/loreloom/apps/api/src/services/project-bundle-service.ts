import type { SqliteDatabase } from '../db/pragmas.js';
import {
  deleteOwnedProjectBundle,
  getOwnedProjectBundle,
  getProjectOwnershipState,
  listOwnedProjectSummaries,
  replaceProjectBundle,
} from '../repositories/project-bundles.js';
import type { ProjectBundle, ProjectBundleWithRevision, ProjectSummary } from '../validators/project-bundle.js';

export type UpsertProjectBundleConflict = {
  status: 'conflict';
  serverRevision: number;
  bundle: ProjectBundleWithRevision | null;
};

export type UpsertProjectBundleSuccess = {
  status: 'ok';
  serverRevision: number;
  updatedAt: string;
};

export type UpsertProjectBundleNotFound = {
  status: 'not_found';
};

export type UpsertProjectBundleResult =
  | UpsertProjectBundleConflict
  | UpsertProjectBundleSuccess
  | UpsertProjectBundleNotFound;

export function getProjectSummaries(database: SqliteDatabase, ownerUserId: string): ProjectSummary[] {
  return listOwnedProjectSummaries(database, ownerUserId);
}

export function getProjectBundleById(
  database: SqliteDatabase,
  projectId: string,
  ownerUserId: string,
): ProjectBundleWithRevision | null {
  return getOwnedProjectBundle(database, projectId, ownerUserId);
}

export function upsertProjectBundle(
  database: SqliteDatabase,
  ownerUserId: string,
  baseRevision: number,
  bundle: ProjectBundle,
): UpsertProjectBundleResult {
  const ownershipState = getProjectOwnershipState(database, bundle.project.id, ownerUserId);

  if (ownershipState === 'owned_by_other' || ownershipState === 'unowned') {
    return {
      status: 'not_found',
    };
  }

  const existingBundle =
    ownershipState === 'owned_by_user'
      ? getOwnedProjectBundle(database, bundle.project.id, ownerUserId)
      : null;

  if (!existingBundle && baseRevision !== 0) {
    return {
      status: 'conflict',
      serverRevision: 0,
      bundle: null,
    };
  }

  if (existingBundle && baseRevision !== existingBundle.serverRevision) {
    return {
      status: 'conflict',
      serverRevision: existingBundle.serverRevision,
      bundle: existingBundle,
    };
  }

  const nextRevision = existingBundle ? existingBundle.serverRevision + 1 : 1;

  replaceProjectBundle(database, bundle, ownerUserId, nextRevision);

  return {
    status: 'ok',
    serverRevision: nextRevision,
    updatedAt: bundle.project.updatedAt,
  };
}

export function removeProjectBundle(database: SqliteDatabase, ownerUserId: string, projectId: string) {
  return deleteOwnedProjectBundle(database, projectId, ownerUserId);
}
