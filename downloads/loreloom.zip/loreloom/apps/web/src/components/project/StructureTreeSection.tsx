import { Link } from 'react-router-dom';
import {
  getStructureNodeTypeLabel,
  type StructureNodeTreeItem,
} from '../../lib/structure';
import { stripHtmlToPlainText } from '../../lib/writing-stats';
import type { Scene, StructureNodeType } from '../../lib/types';

const STRUCTURE_NODE_TYPES: StructureNodeType[] = [
  'book',
  'part',
  'act',
  'chapter',
  'sequence',
  'section',
  'custom',
];

function nodeOptionLabel(depth: number, title: string) {
  return `${'— '.repeat(depth)}${title}`;
}

function sceneCountLabel(count: number) {
  return `${count} text block${count === 1 ? '' : 's'}`;
}

function getStructureNodeTone(type: StructureNodeType) {
  switch (type) {
    case 'book':
      return {
        card: 'border-l-[color:var(--app-gold)] bg-[rgba(198,154,84,0.06)]',
        chip: 'border-[rgba(198,154,84,0.28)] bg-[rgba(198,154,84,0.10)] text-[color:var(--app-gold-soft)]',
        dot: 'border-[rgba(198,154,84,0.50)] bg-[rgba(198,154,84,0.66)]',
      };
    case 'part':
      return {
        card: 'border-l-[rgba(186,129,149,0.9)] bg-[rgba(186,129,149,0.06)]',
        chip: 'border-[rgba(186,129,149,0.28)] bg-[rgba(186,129,149,0.10)] text-[#f1d7df]',
        dot: 'border-[rgba(186,129,149,0.45)] bg-[rgba(186,129,149,0.65)]',
      };
    case 'act':
      return {
        card: 'border-l-[rgba(137,125,178,0.9)] bg-[rgba(137,125,178,0.06)]',
        chip: 'border-[rgba(137,125,178,0.28)] bg-[rgba(137,125,178,0.10)] text-[#e2def8]',
        dot: 'border-[rgba(137,125,178,0.46)] bg-[rgba(137,125,178,0.66)]',
      };
    case 'chapter':
      return {
        card: 'border-l-[rgba(155,138,98,0.9)] bg-[rgba(155,138,98,0.06)]',
        chip: 'border-[rgba(155,138,98,0.28)] bg-[rgba(155,138,98,0.10)] text-[#ebdfc6]',
        dot: 'border-[rgba(155,138,98,0.45)] bg-[rgba(155,138,98,0.66)]',
      };
    case 'sequence':
      return {
        card: 'border-l-[rgba(123,90,137,0.92)] bg-[rgba(123,90,137,0.08)]',
        chip: 'border-[rgba(123,90,137,0.30)] bg-[rgba(123,90,137,0.12)] text-[#eadcf1]',
        dot: 'border-[rgba(123,90,137,0.50)] bg-[rgba(123,90,137,0.70)]',
      };
    case 'section':
      return {
        card: 'border-l-[rgba(133,126,108,0.9)] bg-[rgba(133,126,108,0.06)]',
        chip: 'border-[rgba(133,126,108,0.28)] bg-[rgba(133,126,108,0.10)] text-[#e4dbcb]',
        dot: 'border-[rgba(133,126,108,0.45)] bg-[rgba(133,126,108,0.65)]',
      };
    case 'custom':
      return {
        card: 'border-l-[rgba(160,148,164,0.46)] bg-[rgba(255,248,236,0.03)]',
        chip: 'border-[color:var(--app-border)] bg-[rgba(255,248,236,0.04)] text-slate-200',
        dot: 'border-[rgba(160,148,164,0.40)] bg-[rgba(160,148,164,0.45)]',
      };
  }
}

function countDescendantNodes(node: StructureNodeTreeItem): number {
  return node.children.reduce((total, child) => total + 1 + countDescendantNodes(child), 0);
}

function countSubtreeTextBlocks(node: StructureNodeTreeItem, scenes: Scene[]): number {
  const localCount = scenes.filter((scene) => scene.structureNodeId === node.id).length;
  return node.children.reduce((total, child) => total + countSubtreeTextBlocks(child, scenes), localCount);
}

type StructureTreeState = {
  selectedStructureNodeId: string | null;
  collapsedNodeIds: Set<string>;
  activeStructureEditNodeId: string | null;
  structureEditTitle: string;
  structureEditType: StructureNodeType;
  structureEditCustomTypeLabel: string;
  activeChildStructureParentId: string | null;
  childStructureTitle: string;
  childStructureType: StructureNodeType;
  childStructureCustomTypeLabel: string;
  activeSceneCreateNodeId: string | null;
  draftSceneTitle: string;
  renamingSceneId: string | null;
  renamingSceneTitle: string;
  isTopLevelStructureFormOpen: boolean;
  topLevelStructureTitle: string;
  topLevelStructureType: StructureNodeType;
  topLevelStructureCustomTypeLabel: string;
};

type StructureTreeActions = {
  onSelectNode: (nodeId: string) => void;
  onToggleNodeCollapse: (nodeId: string) => void;
  onBeginEditNode: (nodeId: string) => void;
  onStructureEditTitleChange: (value: string) => void;
  onStructureEditTypeChange: (value: StructureNodeType) => void;
  onStructureEditCustomTypeLabelChange: (value: string) => void;
  onSaveNodeEdit: (nodeId: string) => void;
  onCancelNodeEdit: () => void;
  onCreateChildNodeHere: (nodeId: string) => void;
  onChildNodeTitleChange: (value: string) => void;
  onChildNodeTypeChange: (value: StructureNodeType) => void;
  onChildNodeCustomTypeLabelChange: (value: string) => void;
  onConfirmCreateChildNode: (nodeId: string) => void;
  onCancelCreateChildNode: () => void;
  onDeleteNode: (nodeId: string) => void;
  onBeginCreateSceneHere: (nodeId: string) => void;
  onDraftSceneTitleChange: (value: string) => void;
  onCreateSceneHere: (nodeId: string) => void;
  onCancelCreateSceneHere: () => void;
  onBeginRenameScene: (scene: Scene) => void;
  onRenamingSceneTitleChange: (value: string) => void;
  onSaveRenamedScene: (sceneId: string) => void;
  onCancelRenameScene: () => void;
  onDeleteScene: (scene: Scene) => void;
  onMoveScene: (sceneId: string, structureNodeId: string) => void;
  onToggleTopLevelStructureForm: () => void;
  onTopLevelStructureTitleChange: (value: string) => void;
  onTopLevelStructureTypeChange: (value: StructureNodeType) => void;
  onTopLevelStructureCustomTypeLabelChange: (value: string) => void;
  onCreateTopLevelStructureNode: () => void;
  onCancelTopLevelStructureCreation: () => void;
};

type StructureNodeBranchProps = {
  node: StructureNodeTreeItem;
  depth: number;
  parentTitle: string | null;
  projectId: string;
  scenes: Scene[];
  flatNodeOptions: Array<{ node: StructureNodeTreeItem; depth: number }>;
  canDeleteNode: (nodeId: string) => boolean;
  state: StructureTreeState;
  actions: StructureTreeActions;
};

function StructureNodeBranch({
  node,
  depth,
  parentTitle,
  projectId,
  scenes,
  flatNodeOptions,
  canDeleteNode,
  state,
  actions,
}: StructureNodeBranchProps) {
  const nodeTone = getStructureNodeTone(node.type);
  const isSelected = state.selectedStructureNodeId === node.id;
  const isEditingNodeHere = state.activeStructureEditNodeId === node.id;
  const isCreatingChildHere = state.activeChildStructureParentId === node.id;
  const nodeScenes = scenes.filter((scene) => scene.structureNodeId === node.id);
  const isCollapsed = state.collapsedNodeIds.has(node.id);
  const hasVisibleChildren = node.children.length > 0 || nodeScenes.length > 0;
  const descendantNodeCount = countDescendantNodes(node);
  const subtreeTextBlockCount = countSubtreeTextBlocks(node, scenes);
  const isEmptyNode = descendantNodeCount === 0 && subtreeTextBlockCount === 0;
  const isCreatingSceneHere = state.activeSceneCreateNodeId === node.id;
  const canDeleteThisNode = canDeleteNode(node.id);

  return (
    <div className={`space-y-3 ${depth > 0 ? 'ml-6 border-l border-[rgba(205,176,134,0.14)] pl-4' : ''}`}>
      <div
        className={`rounded-2xl border p-4 transition ${
          isSelected
            ? 'border-[color:var(--app-border-strong)] bg-[rgba(123,90,137,0.12)] shadow-[0_0_0_1px_rgba(198,154,84,0.16)]'
            : 'border-[color:var(--app-border)] bg-[rgba(16,10,20,0.72)]'
        } ${depth > 0 ? 'bg-slate-950/70' : ''} ${nodeTone.card} border-l-4 ${
          isCollapsed ? 'border-dashed border-white/15' : ''
        } ${isEmptyNode ? 'border-dashed border-white/15' : ''}`}
      >
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex min-w-0 items-start gap-3">
            {hasVisibleChildren ? (
              <button
                type="button"
                onClick={() => actions.onToggleNodeCollapse(node.id)}
                className={`app-focus-ring mt-0.5 inline-flex h-6 w-6 items-center justify-center rounded-lg border text-sm transition hover:bg-white/[0.06] ${
                  isCollapsed
                    ? 'border-white/15 bg-slate-950/80 text-slate-300'
                    : 'border-[rgba(198,154,84,0.24)] bg-[rgba(198,154,84,0.12)] text-[color:var(--app-gold-soft)]'
                }`}
                aria-label={isCollapsed ? `Expand ${node.title}` : `Collapse ${node.title}`}
                aria-expanded={!isCollapsed}
              >
                {isCollapsed ? '▸' : '▾'}
              </button>
            ) : (
              <div className={`mt-1 h-3 w-3 shrink-0 rounded-full border ${nodeTone.dot}`} aria-hidden="true" />
            )}
            <button type="button" onClick={() => actions.onSelectNode(node.id)} className="min-w-0 text-left">
              <p className="text-[11px] uppercase tracking-[0.16em] text-slate-400">
                {depth === 0 ? 'Top-level node' : `Child of ${parentTitle ?? 'another node'}`}
              </p>
              <h3 className="mt-1 text-lg font-medium text-white">{node.title}</h3>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <span className={`rounded-full border px-2 py-1 text-[11px] uppercase tracking-[0.16em] ${nodeTone.chip}`}>
                  {getStructureNodeTypeLabel(node)}
                </span>
                <span className="text-sm text-slate-400">{sceneCountLabel(nodeScenes.length)}</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-2 text-xs text-slate-400">
                {hasVisibleChildren ? (
                  <span className="rounded-full border border-[color:var(--app-border)] px-2 py-1">
                    {isCollapsed ? 'Collapsed' : 'Expanded'}
                  </span>
                ) : (
                  <span className="rounded-full border border-dashed border-[color:var(--app-border)] px-2 py-1">Empty node</span>
                )}
                {isCollapsed ? (
                  <span className="rounded-full border border-[color:var(--app-border)] px-2 py-1">
                    {descendantNodeCount} nested node{descendantNodeCount === 1 ? '' : 's'} · {subtreeTextBlockCount} text block
                    {subtreeTextBlockCount === 1 ? '' : 's'}
                  </span>
                ) : null}
                {!isCollapsed && node.children.length > 0 ? (
                  <span className="rounded-full border border-[color:var(--app-border)] px-2 py-1">
                    {node.children.length} child node{node.children.length === 1 ? '' : 's'}
                  </span>
                ) : null}
              </div>
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => actions.onBeginCreateSceneHere(node.id)}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
            >
              Create text block
            </button>
            <button
              type="button"
              onClick={() => actions.onBeginEditNode(node.id)}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
            >
              Edit node
            </button>
            <button
              type="button"
              disabled={!canDeleteThisNode}
              onClick={() => actions.onDeleteNode(node.id)}
              className="app-button-danger inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium transition focus-visible:ring-2 focus-visible:ring-rose-300 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950 disabled:cursor-not-allowed disabled:border-white/10 disabled:bg-white/5 disabled:text-slate-500"
            >
              Delete node
            </button>
            <button
              type="button"
              onClick={() => actions.onCreateChildNodeHere(node.id)}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
            >
              Add child node
            </button>
          </div>
        </div>

        <p className="mt-3 text-sm leading-6 text-slate-400">
          {canDeleteThisNode
            ? 'This node is empty enough to delete.'
            : 'Delete becomes available once this node has no child nodes and no text blocks.'}
        </p>

        {isSelected && !isEditingNodeHere && !isCreatingChildHere && !isCreatingSceneHere ? (
          <div className="mt-3">
            <button
              type="button"
              onClick={() => actions.onSelectNode(node.id)}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium text-slate-200"
            >
              Clear focus
            </button>
          </div>
        ) : null}

        {isEditingNodeHere ? (
          <form
            className="app-panel-inset mt-4 rounded-2xl p-4"
            onSubmit={(event) => {
              event.preventDefault();
              actions.onSaveNodeEdit(node.id);
            }}
          >
            <p className="app-accent-label text-[11px] uppercase tracking-[0.16em]">Editing {node.title}</p>
            <label className="mt-3 block text-sm text-slate-300" htmlFor={`edit-node-title-${node.id}`}>
              Node title
            </label>
            <input
              id={`edit-node-title-${node.id}`}
              className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
              value={state.structureEditTitle}
              onChange={(event) => actions.onStructureEditTitleChange(event.target.value)}
            />
            <label className="mt-4 block text-sm text-slate-300" htmlFor={`edit-node-type-${node.id}`}>
              Node type
            </label>
            <select
              id={`edit-node-type-${node.id}`}
              className="app-select app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
              value={state.structureEditType}
              onChange={(event) => actions.onStructureEditTypeChange(event.target.value as StructureNodeType)}
            >
              {STRUCTURE_NODE_TYPES.map((type) => (
                <option key={type} value={type}>
                  {type === 'custom' ? 'Custom' : getStructureNodeTypeLabel({ type, customTypeLabel: null })}
                </option>
              ))}
            </select>
            {state.structureEditType === 'custom' ? (
              <>
                <label className="mt-4 block text-sm text-slate-300" htmlFor={`edit-node-custom-type-label-${node.id}`}>
                  Custom node label
                </label>
                <input
                  id={`edit-node-custom-type-label-${node.id}`}
                  className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
                  placeholder="Interlude"
                  value={state.structureEditCustomTypeLabel}
                  onChange={(event) => actions.onStructureEditCustomTypeLabelChange(event.target.value)}
                />
              </>
            ) : null}
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="submit"
                className="app-button-primary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
              >
                Save node
              </button>
              <button
                type="button"
                onClick={actions.onCancelNodeEdit}
                className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : null}

        {isCreatingChildHere ? (
          <form
            className="app-panel-inset mt-4 rounded-2xl p-4"
            onSubmit={(event) => {
              event.preventDefault();
              actions.onConfirmCreateChildNode(node.id);
            }}
          >
            <p className="app-accent-label text-[11px] uppercase tracking-[0.16em]">New child node under {node.title}</p>
            <p className="mt-2 text-sm leading-6 text-slate-400">
              This child will appear directly beneath this node in the structure tree.
            </p>
            <label className="mt-3 block text-sm text-slate-300" htmlFor={`child-node-title-${node.id}`}>
              Child node title
            </label>
            <input
              id={`child-node-title-${node.id}`}
              className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
              placeholder="Chapter 2"
              value={state.childStructureTitle}
              onChange={(event) => actions.onChildNodeTitleChange(event.target.value)}
            />
            <label className="mt-4 block text-sm text-slate-300" htmlFor={`child-node-type-${node.id}`}>
              Child node type
            </label>
            <select
              id={`child-node-type-${node.id}`}
              className="app-select app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
              value={state.childStructureType}
              onChange={(event) => actions.onChildNodeTypeChange(event.target.value as StructureNodeType)}
            >
              {STRUCTURE_NODE_TYPES.map((type) => (
                <option key={type} value={type}>
                  {type === 'custom' ? 'Custom' : getStructureNodeTypeLabel({ type, customTypeLabel: null })}
                </option>
              ))}
            </select>
            {state.childStructureType === 'custom' ? (
              <>
                <label className="mt-4 block text-sm text-slate-300" htmlFor={`child-node-custom-type-label-${node.id}`}>
                  Custom node label
                </label>
                <input
                  id={`child-node-custom-type-label-${node.id}`}
                  className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
                  placeholder="Interlude"
                  value={state.childStructureCustomTypeLabel}
                  onChange={(event) => actions.onChildNodeCustomTypeLabelChange(event.target.value)}
                />
              </>
            ) : null}
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="submit"
                className="app-button-primary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
              >
                Create child node
              </button>
              <button
                type="button"
                onClick={actions.onCancelCreateChildNode}
                className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : null}

        {isCreatingSceneHere ? (
          <form
            className="app-panel-inset mt-4 rounded-2xl p-4"
            onSubmit={(event) => {
              event.preventDefault();
              actions.onCreateSceneHere(node.id);
            }}
          >
            <p className="app-accent-label text-[11px] uppercase tracking-[0.16em]">New text block in {node.title}</p>
            <label className="mt-3 block text-sm text-slate-300" htmlFor={`new-scene-${node.id}`}>
              Text block title
            </label>
            <input
              id={`new-scene-${node.id}`}
              className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
              placeholder="Arrival at the gate"
              value={state.draftSceneTitle}
              onChange={(event) => actions.onDraftSceneTitleChange(event.target.value)}
            />
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="submit"
                className="app-button-primary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
              >
                Create text block in this node
              </button>
              <button
                type="button"
                onClick={actions.onCancelCreateSceneHere}
                className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : null}

        {!isCollapsed && nodeScenes.length === 0 ? (
          <div className="app-panel-empty mt-4 rounded-2xl px-4 py-3 text-sm leading-6 text-slate-400">
            {node.children.length > 0
              ? 'This node currently holds child nodes but no direct text blocks.'
              : 'This node is ready for child nodes or text blocks.'}
          </div>
        ) : !isCollapsed ? (
          <div className="app-panel-inset mt-4 ml-5 space-y-2 rounded-2xl border-l-[color:var(--app-border-strong)] p-3 pl-4">
            <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Text blocks in this node</p>
            {nodeScenes.map((scene) => {
              const currentNodeId =
                flatNodeOptions.some(({ node: optionNode }) => optionNode.id === scene.structureNodeId)
                  ? scene.structureNodeId
                  : flatNodeOptions[0]?.node.id ?? scene.structureNodeId;

              return (
                <div key={scene.id} className="app-panel-soft rounded-xl p-3">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div className="flex min-w-0 items-start gap-3">
                      <div
                        className="mt-1 h-2.5 w-2.5 shrink-0 rounded-full border border-slate-500/70 bg-slate-500/40"
                        aria-hidden="true"
                      />
                      <div className="min-w-0">
                        {state.renamingSceneId === scene.id ? (
                          <>
                            <label className="sr-only" htmlFor={`rename-scene-${scene.id}`}>
                              Rename text block
                            </label>
                            <input
                              id={`rename-scene-${scene.id}`}
                              className="app-input app-focus-ring w-full rounded-xl px-3 py-2 text-sm font-medium"
                              value={state.renamingSceneTitle}
                              onChange={(event) => actions.onRenamingSceneTitleChange(event.target.value)}
                            />
                          </>
                        ) : (
                          <Link
                            to={`/projects/${projectId}/scenes/${scene.id}`}
                            className="app-link block text-sm font-medium text-white underline-offset-4 transition hover:underline focus-visible:underline focus-visible:outline-none"
                          >
                            {scene.title}
                          </Link>
                        )}
                        <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-500">Belongs to {node.title}</p>
                        <p className="mt-1 line-clamp-2 text-sm leading-6 text-slate-300">
                          {stripHtmlToPlainText(scene.content) || 'No content yet.'}
                        </p>
                      </div>
                    </div>

                    <div className="flex min-w-48 flex-col gap-2">
                      <div className="flex flex-wrap gap-2">
                        <Link
                          to={`/projects/${projectId}/scenes/${scene.id}`}
                          className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
                        >
                          Open text block
                        </Link>
                        {state.renamingSceneId === scene.id ? (
                          <>
                            <button
                              type="button"
                              onClick={() => actions.onSaveRenamedScene(scene.id)}
                              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
                            >
                              Save name
                            </button>
                            <button
                              type="button"
                              onClick={actions.onCancelRenameScene}
                              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
                            >
                              Cancel
                            </button>
                          </>
                        ) : (
                          <button
                            type="button"
                            onClick={() => actions.onBeginRenameScene(scene)}
                            className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
                          >
                            Rename text block
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => actions.onDeleteScene(scene)}
                          className="inline-flex items-center rounded-xl border border-rose-400/30 bg-rose-400/10 px-3 py-2 text-sm font-medium text-rose-200 transition hover:bg-rose-400/20 focus-visible:ring-2 focus-visible:ring-rose-300 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950"
                        >
                          Delete text block
                        </button>
                      </div>

                      <label className="flex flex-col gap-1 text-xs uppercase tracking-[0.16em] text-slate-400">
                        Move to node
                        <select
                          value={currentNodeId}
                          onChange={(event) => actions.onMoveScene(scene.id, event.target.value)}
                          aria-label={`Move ${scene.title} to another structure node`}
                          className="app-select app-focus-ring min-w-48 rounded-xl px-3 py-2 text-sm uppercase tracking-normal"
                        >
                          {flatNodeOptions.map(({ node: optionNode, depth }) => (
                            <option key={optionNode.id} value={optionNode.id}>
                              {nodeOptionLabel(depth, optionNode.title)}
                            </option>
                          ))}
                        </select>
                      </label>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : null}
      </div>

      {!isCollapsed && node.children.length > 0 ? (
        <div className="space-y-3">
          {node.children.map((child) => (
            <StructureNodeBranch
              key={child.id}
              node={child}
              depth={depth + 1}
              parentTitle={node.title}
              projectId={projectId}
              scenes={scenes}
              flatNodeOptions={flatNodeOptions}
              canDeleteNode={canDeleteNode}
              state={state}
              actions={actions}
            />
          ))}
        </div>
      ) : null}
    </div>
  );
}

type StructureTreeSectionProps = {
  projectId: string;
  structureNodes: StructureNodeTreeItem[];
  structureNodeTitlesById: Map<string, string>;
  flatNodeOptions: Array<{ node: StructureNodeTreeItem; depth: number }>;
  scenes: Scene[];
  deleteableStructureNodeIds: Set<string>;
  state: StructureTreeState;
  actions: StructureTreeActions;
};

// This section keeps the outline rendering and inline tree forms together so
// ProjectPage can focus on data orchestration rather than nested UI details.
export default function StructureTreeSection({
  projectId,
  structureNodes,
  structureNodeTitlesById,
  flatNodeOptions,
  scenes,
  deleteableStructureNodeIds,
  state,
  actions,
}: StructureTreeSectionProps) {
  return (
    <section className="app-panel rounded-3xl p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="max-w-2xl">
          <h2 className="text-lg font-medium text-white">Structure</h2>
          <p className="mt-2 text-sm leading-6 text-slate-300">
            Keep structure actions close to the tree. Add top-level nodes here, then create child nodes and text blocks directly inside the section they belong to.
          </p>
        </div>
        <div className="flex flex-col items-start gap-2 sm:items-end">
          <p className="text-sm text-slate-400">
            {flatNodeOptions.length} node{flatNodeOptions.length === 1 ? '' : 's'}
          </p>
          <button
            type="button"
            onClick={actions.onToggleTopLevelStructureForm}
            className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
          >
            {state.isTopLevelStructureFormOpen ? 'Close top-level form' : 'Create top-level node'}
          </button>
        </div>
      </div>

      {state.isTopLevelStructureFormOpen ? (
        <form
          className="app-panel-inset mt-4 rounded-2xl p-4"
          onSubmit={(event) => {
            event.preventDefault();
            actions.onCreateTopLevelStructureNode();
          }}
        >
          <p className="app-accent-label text-[11px] uppercase tracking-[0.16em]">New top-level node</p>
          <p className="mt-2 text-sm leading-6 text-slate-400">This node will appear at the root of the structure tree.</p>
          <label className="mt-3 block text-sm text-slate-300" htmlFor="top-level-structure-title">
            Node title
          </label>
          <input
            id="top-level-structure-title"
            className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
            placeholder="Part One"
            value={state.topLevelStructureTitle}
            onChange={(event) => actions.onTopLevelStructureTitleChange(event.target.value)}
          />
          <label className="mt-4 block text-sm text-slate-300" htmlFor="top-level-structure-type">
            Node type
          </label>
          <select
            id="top-level-structure-type"
            className="app-select app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
            value={state.topLevelStructureType}
            onChange={(event) => actions.onTopLevelStructureTypeChange(event.target.value as StructureNodeType)}
          >
            {STRUCTURE_NODE_TYPES.map((type) => (
              <option key={type} value={type}>
                {type === 'custom' ? 'Custom' : getStructureNodeTypeLabel({ type, customTypeLabel: null })}
              </option>
            ))}
          </select>
          {state.topLevelStructureType === 'custom' ? (
            <>
              <label className="mt-4 block text-sm text-slate-300" htmlFor="top-level-structure-custom-type-label">
                Custom node label
              </label>
              <input
                id="top-level-structure-custom-type-label"
                className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
                placeholder="Interlude"
                value={state.topLevelStructureCustomTypeLabel}
                onChange={(event) => actions.onTopLevelStructureCustomTypeLabelChange(event.target.value)}
              />
            </>
          ) : null}
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="submit"
              className="app-button-primary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
            >
              Create node
            </button>
            <button
              type="button"
              onClick={actions.onCancelTopLevelStructureCreation}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
            >
              Cancel
            </button>
          </div>
        </form>
      ) : null}

      {structureNodes.length === 0 ? (
        <div className="app-panel-empty mt-6 rounded-3xl p-8 text-slate-300">
          <h3 className="text-base font-medium text-white">No structure nodes yet</h3>
          <p className="mt-2 max-w-xl text-sm leading-6 text-slate-300">
            Create a structure node to start organizing text blocks into books, acts, chapters, or custom groups.
          </p>
        </div>
      ) : (
        <div className="mt-6 space-y-4">
          {structureNodes.map((node) => (
            <StructureNodeBranch
              key={node.id}
              node={node}
              depth={0}
              parentTitle={node.parentId ? structureNodeTitlesById.get(node.parentId) ?? null : null}
              projectId={projectId}
              scenes={scenes}
              flatNodeOptions={flatNodeOptions}
              canDeleteNode={(nodeId) => deleteableStructureNodeIds.has(nodeId)}
              state={state}
              actions={actions}
            />
          ))}
        </div>
      )}
    </section>
  );
}
