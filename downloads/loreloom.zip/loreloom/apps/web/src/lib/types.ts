export type ID = string;

export type Project = {
  id: ID;
  name: string;
  createdAt: string;
  updatedAt: string;
};

export type StructureNodeType = 'book' | 'part' | 'act' | 'chapter' | 'sequence' | 'section' | 'custom';

export type StructureNode = {
  id: ID;
  projectId: ID;
  parentId: ID | null;
  type: StructureNodeType;
  customTypeLabel?: string | null;
  title: string;
  orderIndex: number;
  createdAt: string;
  updatedAt: string;
};

export type Scene = {
  id: ID;
  projectId: ID;
  structureNodeId: ID;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
};

export type RevisionSnapshot = {
  id: ID;
  sceneId: ID;
  projectId: ID;
  title: string;
  content: string;
  createdAt: string;
};

export type CodexNodeType =
  | 'codex'
  | 'group'
  | 'characters'
  | 'places'
  | 'factions'
  | 'objects'
  | 'timeline'
  | 'research'
  | 'custom';

export type CodexNode = {
  id: ID;
  projectId: ID;
  parentId: ID | null;
  type: CodexNodeType;
  customTypeLabel?: string | null;
  title: string;
  tags: string[];
  orderIndex: number;
  createdAt: string;
  updatedAt: string;
};

export type LoreLoomState = {
  projects: Project[];
  structureNodes: StructureNode[];
  scenes: Scene[];
  codexNodes: CodexNode[];
  codexEntries: CodexEntry[];
  revisionSnapshots: RevisionSnapshot[];
};

export type ProjectSyncStatus = 'idle' | 'syncing' | 'offline' | 'conflict';

export type ProjectSyncMeta = {
  dirty: boolean;
  status: ProjectSyncStatus;
  serverRevision: number | null;
  lastSyncAt: string | null;
  error: string | null;
  changeToken: number;
  syncRequestToken: number;
};

export type BackendStatus = 'unknown' | 'online' | 'offline';
export type SyncHydrationState = 'idle' | 'hydrating' | 'ready';

export type LoreLoomSyncState = {
  projects: Record<ID, ProjectSyncMeta>;
  pendingDeletes: ID[];
  backendStatus: BackendStatus;
  hydrationState: SyncHydrationState;
};

export type DiagnosticEventType =
  | 'sync_requested'
  | 'sync_started'
  | 'sync_succeeded'
  | 'sync_offline'
  | 'sync_conflict'
  | 'delete_sync_started'
  | 'delete_sync_succeeded'
  | 'delete_sync_failed'
  | 'backend_hydration_started'
  | 'backend_hydration_succeeded'
  | 'backend_hydration_failed'
  | 'diagnostic_bundle_exported';

export type DiagnosticEvent = {
  id: ID;
  at: string;
  type: DiagnosticEventType;
  projectId?: ID | null;
  status?: ProjectSyncStatus | 'ok' | 'error' | null;
  message?: string | null;
};

export type LoreLoomDiagnosticsState = {
  events: DiagnosticEvent[];
};

export type LoreLoomBackupState = {
  lastProjectBackupExportAt: string | null;
  projectBackupExports: Record<ID, string>;
};

export type WritingFontId =
  | 'system-sans'
  | 'inter'
  | 'source-sans-3'
  | 'ibm-plex-sans'
  | 'atkinson-hyperlegible'
  | 'literata'
  | 'merriweather'
  | 'source-serif-4'
  | 'ibm-plex-serif'
  | 'jetbrains-mono'
  | 'ibm-plex-mono';

export type InterfaceFontId = Extract<
  WritingFontId,
  'system-sans' | 'inter' | 'source-sans-3' | 'ibm-plex-sans' | 'atkinson-hyperlegible'
>;

export type WritingFontSize = 'small' | 'medium' | 'large' | 'extra-large';
export type WritingLineSpacing = 'compact' | 'comfortable' | 'spacious';
export type WritingEditorWidth = 'narrow' | 'standard' | 'wide';

export type LoreLoomWritingAppearanceState = {
  interfaceFontId: InterfaceFontId;
  writingFontId: WritingFontId;
  fontSize: WritingFontSize;
  lineSpacing: WritingLineSpacing;
  editorWidth: WritingEditorWidth;
};

export type LoreLoomPersistedState = LoreLoomState & {
  sync: LoreLoomSyncState;
  diagnostics: LoreLoomDiagnosticsState;
  backups: LoreLoomBackupState;
  appearance: LoreLoomWritingAppearanceState;
};

export type CodexEntryType = 'character' | 'location' | 'object' | 'faction' | 'lore' | 'timeline' | 'custom';

export type CodexEntry = {
  id: ID;
  projectId: ID;
  codexNodeId: ID;
  title: string;
  type: CodexEntryType;
  content: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
};

export type ProjectBackupCodexEntry = {
  id: ID;
  projectId: ID;
  codexNodeId: ID;
  title: string;
  type: CodexEntryType;
  content: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
};

export type ProjectBackupCodexNode = CodexNode;
export type ProjectBackupStructureNode = StructureNode;
export type ProjectBackupRevisionSnapshot = RevisionSnapshot;

export type ProjectBackup = {
  format: 'LoreLoom Project Backup';
  version: 5;
  exportedAt: string;
  project: Project;
  structureNodes: ProjectBackupStructureNode[];
  scenes: Scene[];
  codexNodes: ProjectBackupCodexNode[];
  codexEntries: ProjectBackupCodexEntry[];
  revisionSnapshots: ProjectBackupRevisionSnapshot[];
};
