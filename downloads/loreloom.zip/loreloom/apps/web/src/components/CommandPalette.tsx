import { useEffect, useRef } from 'react';

export type CommandPaletteItem = {
  id: string;
  section: 'Navigate' | 'Create' | 'Export' | 'Codex';
  title: string;
  subtitle?: string;
  onSelect: () => void;
};

export default function CommandPalette({
  isOpen,
  items,
  query,
  onClose,
  onQueryChange,
}: {
  isOpen: boolean;
  items: CommandPaletteItem[];
  query: string;
  onClose: () => void;
  onQueryChange: (value: string) => void;
}) {
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    window.setTimeout(() => inputRef.current?.focus(), 0);
  }, [isOpen]);

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-[rgba(13,8,18,0.76)] px-4 py-12 backdrop-blur-sm">
      <div className="app-panel w-full max-w-2xl rounded-3xl shadow-2xl shadow-black/40">
        <div className="border-b border-[color:var(--app-border)] px-4 py-4 sm:px-5">
          <label className="sr-only" htmlFor="command-palette-search">
            Search commands
          </label>
          <input
            ref={inputRef}
            id="command-palette-search"
            value={query}
            onChange={(event) => onQueryChange(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Escape') {
                event.preventDefault();
                onClose();
              }
            }}
            placeholder="Jump, create, preview, export..."
            className="app-input app-focus-ring w-full rounded-xl px-4 py-3"
          />
        </div>
        <div className="max-h-[60vh] overflow-y-auto p-3">
          {items.length === 0 ? (
            <div className="app-panel-empty rounded-2xl px-4 py-6 text-sm leading-6 text-slate-400">
              No matching commands yet.
            </div>
          ) : (
            <div className="space-y-4">
              {(['Navigate', 'Create', 'Export', 'Codex'] as const).map((section) => {
                const sectionItems = items.filter((item) => item.section === section);
                if (sectionItems.length === 0) {
                  return null;
                }

                return (
                  <section key={section} className="space-y-2">
                    <p className="app-accent-label px-2 text-[11px] uppercase tracking-[0.16em]">{section}</p>
                    <div className="space-y-2">
                      {sectionItems.map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={item.onSelect}
                          className="app-panel-soft app-focus-ring w-full rounded-2xl px-4 py-3 text-left transition hover:bg-white/[0.06]"
                        >
                          <p className="text-sm font-medium text-white">{item.title}</p>
                          {item.subtitle ? (
                            <p className="mt-1 text-sm leading-6 text-slate-400">{item.subtitle}</p>
                          ) : null}
                        </button>
                      ))}
                    </div>
                  </section>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
