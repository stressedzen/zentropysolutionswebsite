import type { FastifyInstance } from 'fastify';
import { ZodError } from 'zod';
import type { AppConfig } from '../config.js';
import type { SqliteDatabase } from '../db/pragmas.js';
import { serializeClearedSessionCookie, serializeSessionCookie } from '../auth/sessions.js';
import {
  changePasswordForCurrentUser,
  createFirstAdminUser,
  getCurrentAuthenticatedUser,
  getSetupStatus,
  loginUser,
  logoutUser,
} from '../services/auth-service.js';
import { changePasswordBodySchema, loginBodySchema, setupAdminBodySchema } from '../validators/auth.js';

function sendInvalidRequest(
  reply: { code: (statusCode: number) => { send: (payload: unknown) => unknown } },
  error: ZodError,
) {
  return reply.code(400).send({
    error: 'invalid_request',
    message: 'Please fix the highlighted fields and try again.',
    issues: error.issues.map((issue) => ({
      path: issue.path.join('.'),
      message: issue.message,
    })),
  });
}

function setAuthCookie(
  reply: { header: (name: string, value: string) => unknown },
  config: Pick<AppConfig, 'authCookieName' | 'authSecureCookie'>,
  sessionToken: string,
  expiresAt: string,
) {
  reply.header(
    'Set-Cookie',
    serializeSessionCookie(sessionToken, {
      cookieName: config.authCookieName,
      expiresAt,
      secure: config.authSecureCookie,
    }),
  );
}

function clearAuthCookie(
  reply: { header: (name: string, value: string) => unknown },
  config: Pick<AppConfig, 'authCookieName' | 'authSecureCookie'>,
) {
  reply.header(
    'Set-Cookie',
    serializeClearedSessionCookie(config.authCookieName, {
      secure: config.authSecureCookie,
    }),
  );
}

export async function registerAuthRoutes(
  app: FastifyInstance,
  database: SqliteDatabase,
  config: Pick<AppConfig, 'authCookieName' | 'authSecureCookie' | 'authSessionDurationHours'>,
) {
  app.get('/api/setup/status', async () => {
    return getSetupStatus(database);
  });

  app.post('/api/setup/admin', async (request, reply) => {
    const bodyResult = setupAdminBodySchema.safeParse(request.body);

    if (!bodyResult.success) {
      return sendInvalidRequest(reply, bodyResult.error);
    }

    const result = await createFirstAdminUser(database, config, {
      username: bodyResult.data.username,
      password: bodyResult.data.password,
      displayName: bodyResult.data.displayName?.trim() ? bodyResult.data.displayName.trim() : null,
    });

    if (result.status === 'setup_already_completed') {
      clearAuthCookie(reply, config);
      return reply.code(409).send({
        error: 'setup_already_completed',
        message: 'Initial admin setup is no longer available.',
      });
    }

    if (result.status !== 'authenticated') {
      clearAuthCookie(reply, config);
      return reply.code(500).send({
        error: 'internal_error',
        message: 'The server could not complete the request.',
      });
    }

    setAuthCookie(reply, config, result.sessionToken, result.expiresAt);

    return reply.code(201).send({
      authenticated: true,
      user: result.user,
    });
  });

  app.post('/api/auth/login', async (request, reply) => {
    const bodyResult = loginBodySchema.safeParse(request.body);

    if (!bodyResult.success) {
      return sendInvalidRequest(reply, bodyResult.error);
    }

    const result = await loginUser(database, config, {
      username: bodyResult.data.username,
      password: bodyResult.data.password,
    });

    if (result.status === 'invalid_credentials') {
      clearAuthCookie(reply, config);
      return reply.code(401).send({
        error: 'invalid_credentials',
        message: 'The provided username or password is not valid.',
      });
    }

    if (result.status !== 'authenticated') {
      clearAuthCookie(reply, config);
      return reply.code(500).send({
        error: 'internal_error',
        message: 'The server could not complete the request.',
      });
    }

    setAuthCookie(reply, config, result.sessionToken, result.expiresAt);

    return {
      authenticated: true,
      user: result.user,
    };
  });

  app.post('/api/auth/logout', async (request, reply) => {
    logoutUser(database, request.headers.cookie, config);
    clearAuthCookie(reply, config);

    return {
      authenticated: false,
      ok: true,
    };
  });

  app.get('/api/auth/me', async (request, reply) => {
    const result = getCurrentAuthenticatedUser(database, request.headers.cookie, config);

    if (result.clearCookie) {
      clearAuthCookie(reply, config);
    }

    if (!result.authenticated) {
      return {
        authenticated: false,
      };
    }

    return {
      authenticated: true,
      user: result.user,
    };
  });

  app.post('/api/auth/change-password', async (request, reply) => {
    const bodyResult = changePasswordBodySchema.safeParse(request.body);

    if (!bodyResult.success) {
      return sendInvalidRequest(reply, bodyResult.error);
    }

    const result = await changePasswordForCurrentUser(database, config, request.headers.cookie, {
      currentPassword: bodyResult.data.currentPassword,
      newPassword: bodyResult.data.newPassword,
    });

    if (result.status === 'not_authenticated') {
      clearAuthCookie(reply, config);
      return reply.code(401).send({
        error: 'unauthorized',
        message: 'Authentication is required.',
      });
    }

    if (result.status === 'invalid_current_password') {
      return reply.code(400).send({
        error: 'invalid_current_password',
        message: 'The current password was not accepted.',
      });
    }

    return {
      authenticated: true,
      user: result.user,
    };
  });
}
