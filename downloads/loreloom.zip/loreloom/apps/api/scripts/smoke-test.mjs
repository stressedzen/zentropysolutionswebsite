const baseUrl = (process.env.API_BASE_URL ?? 'http://127.0.0.1:8787').replace(/\/$/, '');

async function requestJson(path, init) {
  const response = await fetch(`${baseUrl}${path}`, init);
  const text = await response.text();
  const body = text ? JSON.parse(text) : null;

  if (!response.ok) {
    throw new Error(`Smoke test failed for ${path}: ${response.status} ${JSON.stringify(body)}`);
  }

  return body;
}

async function main() {
  try {
    const health = await requestJson('/health');
    const projects = await requestJson('/api/projects');

    console.log(
      JSON.stringify(
        {
          ok: true,
          baseUrl,
          health,
          projectCount: Array.isArray(projects.projects) ? projects.projects.length : null,
        },
        null,
        2,
      ),
    );
  } catch (error) {
    console.error(
      error instanceof Error
        ? error.message
        : 'Smoke test failed before a response could be read. Is the API server running?',
    );
    process.exit(1);
  }
}

await main();
