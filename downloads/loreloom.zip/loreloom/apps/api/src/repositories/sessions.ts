import type { SqliteDatabase } from '../db/pragmas.js';

export type SessionRow = {
  id: string;
  user_id: string;
  session_token_hash: string;
  created_at: string;
  expires_at: string;
  last_seen_at: string | null;
};

export type CreateSessionInput = {
  id: string;
  userId: string;
  sessionTokenHash: string;
  createdAt: string;
  expiresAt: string;
  lastSeenAt: string | null;
};

export function findSessionById(database: SqliteDatabase, sessionId: string): SessionRow | null {
  return (
    (database
      .prepare(
        `
          SELECT id, user_id, session_token_hash, created_at, expires_at, last_seen_at
          FROM sessions
          WHERE id = ?
        `,
      )
      .get(sessionId) as SessionRow | undefined) ?? null
  );
}

export function findSessionByTokenHash(database: SqliteDatabase, sessionTokenHash: string): SessionRow | null {
  return (
    (database
      .prepare(
        `
          SELECT id, user_id, session_token_hash, created_at, expires_at, last_seen_at
          FROM sessions
          WHERE session_token_hash = ?
        `,
      )
      .get(sessionTokenHash) as SessionRow | undefined) ?? null
  );
}

export function createSession(database: SqliteDatabase, input: CreateSessionInput): SessionRow {
  database
    .prepare(
      `
        INSERT INTO sessions (id, user_id, session_token_hash, created_at, expires_at, last_seen_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `,
    )
    .run(
      input.id,
      input.userId,
      input.sessionTokenHash,
      input.createdAt,
      input.expiresAt,
      input.lastSeenAt,
    );

  const createdSession = findSessionById(database, input.id);

  if (!createdSession) {
    throw new Error(`Session ${input.id} was not created.`);
  }

  return createdSession;
}

export function touchSession(database: SqliteDatabase, sessionId: string, lastSeenAt: string): void {
  database
    .prepare(
      `
        UPDATE sessions
        SET last_seen_at = ?
        WHERE id = ?
      `,
    )
    .run(lastSeenAt, sessionId);
}

export function deleteSessionById(database: SqliteDatabase, sessionId: string): void {
  database.prepare('DELETE FROM sessions WHERE id = ?').run(sessionId);
}

export function deleteSessionByTokenHash(database: SqliteDatabase, sessionTokenHash: string): void {
  database.prepare('DELETE FROM sessions WHERE session_token_hash = ?').run(sessionTokenHash);
}

export function deleteSessionsByUserId(database: SqliteDatabase, userId: string): number {
  const result = database.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
  return result.changes;
}

export function deleteSessionsByUserIdExcept(
  database: SqliteDatabase,
  userId: string,
  excludedSessionId: string,
): number {
  const result = database
    .prepare('DELETE FROM sessions WHERE user_id = ? AND id <> ?')
    .run(userId, excludedSessionId);
  return result.changes;
}

export function deleteExpiredSessions(database: SqliteDatabase, nowIso: string): number {
  const result = database.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(nowIso);
  return result.changes;
}
