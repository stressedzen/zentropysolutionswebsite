import type { FastifyInstance } from 'fastify';
import type { AppConfig } from '../config.js';

export async function registerDiagnosticsRoute(app: FastifyInstance, config: AppConfig) {
  app.get('/api/diagnostics/export', async () => {
    return {
      format: 'LoreLoom Diagnostic Bundle',
      version: 1,
      generatedAt: new Date().toISOString(),
      diagnosticsEnabled: false,
      backend: {
        appName: config.appName,
        appVersion: config.appVersion,
        status: 'ok',
        health: {
          status: 'ok',
          appName: config.appName,
          timestamp: new Date().toISOString(),
        },
        config: {
          nodeEnv: config.nodeEnv,
          logLevel: config.logLevel,
          maxRequestBodyBytes: config.maxRequestBodyBytes,
          databasePath: config.databasePath,
          devCorsOriginConfigured: config.devCorsOrigin !== null,
        },
      },
    };
  });
}
