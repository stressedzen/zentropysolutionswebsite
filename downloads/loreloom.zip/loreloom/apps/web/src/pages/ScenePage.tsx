import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { EditorContent, useEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import SyncStatusBadge from '../components/SyncStatusBadge';
import { fuzzyScore } from '../lib/fuzzy';
import { stripHtmlToPlainText, countHtmlCharacters, countHtmlWords, estimateReadingTimeMinutes } from '../lib/writing-stats';
import { useLoreLoomStore } from '../store/useLoreLoomStore';

function ToolbarButton({
  active,
  disabled,
  label,
  onClick,
}: {
  active?: boolean;
  disabled?: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      aria-pressed={active}
      onClick={onClick}
      className={`app-focus-ring inline-flex items-center rounded-lg border px-3 py-1.5 text-sm transition ${
        active
          ? 'border-[color:var(--app-border-strong)] bg-[rgba(123,90,137,0.16)] text-[#eadcf1]'
          : 'border-[color:var(--app-border)] bg-[rgba(255,248,236,0.04)] text-slate-200 hover:bg-white/[0.05]'
      } ${disabled ? 'cursor-not-allowed opacity-50' : ''}`}
    >
      {label}
    </button>
  );
}

function formatSnapshotDate(iso: string) {
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(new Date(iso));
}

export default function ScenePage() {
  const { projectId, sceneId } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const projects = useLoreLoomStore((state) => state.projects);
  const scenes = useLoreLoomStore((state) => state.scenes);
  const codexEntries = useLoreLoomStore((state) => state.codexEntries);
  const revisionSnapshots = useLoreLoomStore((state) => state.revisionSnapshots);
  const updateScene = useLoreLoomStore((state) => state.updateScene);
  const deleteScene = useLoreLoomStore((state) => state.deleteScene);
  const createSceneAfter = useLoreLoomStore((state) => state.createSceneAfter);
  const createRevisionSnapshotForScene = useLoreLoomStore((state) => state.createRevisionSnapshotForScene);
  const restoreRevisionSnapshot = useLoreLoomStore((state) => state.restoreRevisionSnapshot);
  const requestProjectSync = useLoreLoomStore((state) => state.requestProjectSync);
  const [saveState, setSaveState] = useState<'saved' | 'saving'>('saved');
  const [isCodexLookupOpen, setIsCodexLookupOpen] = useState(false);
  const [codexQuery, setCodexQuery] = useState('');
  const [expandedCodexEntryId, setExpandedCodexEntryId] = useState<string | null>(null);
  const saveStateTimer = useRef<number | null>(null);
  const initialSceneId = useRef<string | null>(null);
  const codexSearchInputRef = useRef<HTMLInputElement | null>(null);
  const sessionStartRef = useRef<{ sceneId: string; title: string; content: string } | null>(null);
  const sessionSnapshotCommittedRef = useRef(false);
  const isFocusMode = searchParams.get('focus') === '1';

  const project = useMemo(
    () => (projectId ? projects.find((entry) => entry.id === projectId) : undefined),
    [projectId, projects],
  );
  const scene = useMemo(
    () => (sceneId ? scenes.find((entry) => entry.id === sceneId) : undefined),
    [sceneId, scenes],
  );
  const sceneSnapshots = useMemo(
    () => revisionSnapshots.filter((snapshot) => snapshot.sceneId === sceneId).sort((left, right) => right.createdAt.localeCompare(left.createdAt)),
    [revisionSnapshots, sceneId],
  );
  const projectCodexEntries = useMemo(
    () => codexEntries.filter((entry) => entry.projectId === projectId),
    [codexEntries, projectId],
  );
  const filteredCodexEntries = useMemo(() => {
    const normalizedQuery = codexQuery.trim();
    if (!normalizedQuery) {
      return projectCodexEntries.slice(0, 8);
    }

    return projectCodexEntries
      .map((entry) => {
        const tagString = entry.tags.join(' ');
        const titleScore = fuzzyScore(normalizedQuery, entry.title);
        const tagScore = fuzzyScore(normalizedQuery, tagString);
        const includesMatch =
          entry.title.toLowerCase().includes(normalizedQuery.toLowerCase()) ||
          tagString.toLowerCase().includes(normalizedQuery.toLowerCase());

        return {
          entry,
          score: Math.max(titleScore, tagScore, includesMatch ? 1 : -1),
        };
      })
      .filter((result) => result.score >= 0)
      .sort((left, right) => right.score - left.score || left.entry.title.localeCompare(right.entry.title))
      .slice(0, 8)
      .map((result) => result.entry);
  }, [codexQuery, projectCodexEntries]);
  const sceneWordCount = useMemo(() => countHtmlWords(scene?.content || ''), [scene?.content]);
  const sceneCharacterCount = useMemo(() => countHtmlCharacters(scene?.content || ''), [scene?.content]);
  const sceneReadingTimeMinutes = useMemo(() => estimateReadingTimeMinutes(sceneWordCount), [sceneWordCount]);

  function buildScenePath(nextSceneId: string, focusMode: boolean) {
    return `/projects/${projectId}/scenes/${nextSceneId}${focusMode ? '?focus=1' : ''}`;
  }

  function resetSessionStart(currentScene: { id: string; title: string; content: string }) {
    sessionStartRef.current = {
      sceneId: currentScene.id,
      title: currentScene.title,
      content: currentScene.content,
    };
    sessionSnapshotCommittedRef.current = false;
  }

  function commitRevisionSnapshotForCurrentScene() {
    const sessionStart = sessionStartRef.current;
    if (!sessionStart || sessionSnapshotCommittedRef.current) {
      return;
    }

    createRevisionSnapshotForScene(sessionStart.sceneId, {
      title: sessionStart.title,
      content: sessionStart.content,
    });
    sessionSnapshotCommittedRef.current = true;
  }

  function closeCodexLookup() {
    setIsCodexLookupOpen(false);
    setCodexQuery('');
    setExpandedCodexEntryId(null);
  }

  function exitFocusMode() {
    if (!scene) {
      return;
    }

    commitRevisionSnapshotForCurrentScene();
    resetSessionStart(scene);
    requestProjectSync(scene.projectId);
    navigate(buildScenePath(scene.id, false));
  }

  function handleContinueInNewTextBlock() {
    if (!scene) {
      return;
    }

    commitRevisionSnapshotForCurrentScene();
    const nextScene = createSceneAfter(scene.id, 'Untitled Text Block');
    if (!nextScene) {
      return;
    }

    requestProjectSync(scene.projectId);
    navigate(buildScenePath(nextScene.id, isFocusMode));
  }

  function toggleCodexLookup() {
    setIsCodexLookupOpen((current) => {
      if (current) {
        setCodexQuery('');
        setExpandedCodexEntryId(null);
      }

      return !current;
    });
  }

  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({
        placeholder: 'Write the text block here...',
      }),
    ],
    content: scene?.content || '',
    immediatelyRender: false,
    editorProps: {
      attributes: {
        class: 'prose prose-invert max-w-none focus:outline-none',
        spellcheck: 'true',
        autocorrect: 'on',
        autocapitalize: 'sentences',
        lang: 'en',
      },
    },
    onUpdate: ({ editor: instance }) => {
      if (!scene) {
        return;
      }

      updateScene(scene.id, { content: instance.getHTML() });
    },
  });

  useEffect(() => {
    if (!editor || !scene) {
      return;
    }

    const currentHtml = editor.getHTML();
    if (currentHtml !== scene.content) {
      editor.commands.setContent(scene.content || '', { emitUpdate: false });
    }
  }, [editor, scene?.content, scene?.id]);

  useEffect(() => {
    if (!scene) {
      return;
    }

    if (initialSceneId.current !== scene.id) {
      initialSceneId.current = scene.id;
      setSaveState('saved');
      return;
    }

    setSaveState('saving');

    if (saveStateTimer.current !== null) {
      window.clearTimeout(saveStateTimer.current);
    }

    saveStateTimer.current = window.setTimeout(() => {
      setSaveState('saved');
      saveStateTimer.current = null;
    }, 500);

    return () => {
      if (saveStateTimer.current !== null) {
        window.clearTimeout(saveStateTimer.current);
      }
    };
  }, [scene?.updatedAt, scene?.id]);

  useEffect(() => {
    return () => {
      if (saveStateTimer.current !== null) {
        window.clearTimeout(saveStateTimer.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!scene) {
      return;
    }

    resetSessionStart(scene);
    closeCodexLookup();

    return () => {
      commitRevisionSnapshotForCurrentScene();
      requestProjectSync(scene.projectId);
    };
  }, [requestProjectSync, scene?.id]);

  useEffect(() => {
    const handlePageHide = () => {
      commitRevisionSnapshotForCurrentScene();
      if (scene) {
        requestProjectSync(scene.projectId);
      }
    };

    window.addEventListener('pagehide', handlePageHide);
    return () => window.removeEventListener('pagehide', handlePageHide);
  }, [requestProjectSync, scene]);

  useEffect(() => {
    if (!isFocusMode) {
      return;
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      if (
        projectCodexEntries.length > 0 &&
        (event.metaKey || event.ctrlKey) &&
        event.shiftKey &&
        event.key.toLowerCase() === 'l'
      ) {
        event.preventDefault();
        setIsCodexLookupOpen((current) => !current);
        return;
      }

      if (event.key === 'Escape') {
        if (isCodexLookupOpen) {
          event.preventDefault();
          closeCodexLookup();
          return;
        }

        event.preventDefault();
        exitFocusMode();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCodexLookupOpen, isFocusMode, projectCodexEntries.length, scene?.id]);

  useEffect(() => {
    if (!isFocusMode || !isCodexLookupOpen) {
      return;
    }

    codexSearchInputRef.current?.focus();
  }, [isCodexLookupOpen, isFocusMode]);

  useEffect(() => {
    if (!isFocusMode || projectCodexEntries.length > 0) {
      return;
    }

    closeCodexLookup();
  }, [isFocusMode, projectCodexEntries.length]);

  useEffect(() => {
    if (!expandedCodexEntryId) {
      return;
    }

    if (!projectCodexEntries.some((entry) => entry.id === expandedCodexEntryId)) {
      setExpandedCodexEntryId(null);
    }
  }, [expandedCodexEntryId, projectCodexEntries]);

  useEffect(() => {
    if (isFocusMode) {
      return;
    }

    closeCodexLookup();
  }, [isFocusMode]);

  if (!project || !scene) {
    return (
      <div className="app-panel rounded-3xl p-8 text-slate-300">
        <h2 className="text-lg font-medium text-white">Text block not found</h2>
        <p className="mt-2 text-sm leading-6 text-slate-300">
          This text block may have been deleted or the link may be outdated.
        </p>
        <Link to="/" className="app-link mt-4 inline-flex underline underline-offset-4">
          Return to dashboard
        </Link>
      </div>
    );
  }

  return (
    <div className={isFocusMode ? 'mx-auto w-full max-w-6xl space-y-4 pb-10 pt-2' : 'space-y-6'}>
      <div
        className={`flex flex-wrap items-center justify-between gap-3 ${
          isFocusMode ? 'app-panel-soft rounded-2xl px-4 py-3' : ''
        }`}
      >
        {isFocusMode ? (
          <div>
            <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Focus Mode</p>
            <p className="mt-1 text-sm text-slate-400">Escape exits focus mode and returns you to the full editor.</p>
          </div>
        ) : (
          <Link to={`/projects/${project.id}`} className="app-link text-sm underline underline-offset-4">
            Back to {project.name}
          </Link>
        )}
        <div className="flex flex-wrap items-center gap-2">
          {isFocusMode ? (
            <button
              type="button"
              onClick={exitFocusMode}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
            >
              Exit Focus Mode
            </button>
          ) : (
            <button
              type="button"
              onClick={() => navigate(buildScenePath(scene.id, true))}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
            >
              Enter Focus Mode
            </button>
          )}
          {isFocusMode && projectCodexEntries.length > 0 ? (
            <button
              type="button"
              onClick={toggleCodexLookup}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
            >
              {isCodexLookupOpen ? 'Hide Codex Lookup' : 'Codex Lookup'}
            </button>
          ) : null}
          <button
            type="button"
            onClick={handleContinueInNewTextBlock}
            className="app-button-primary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
          >
            Continue in New Text Block
          </button>
          {!isFocusMode ? (
            <button
              type="button"
              onClick={() => {
                const confirmed = window.confirm('Delete this text block? This cannot be undone.');
                if (!confirmed) {
                  return;
                }

                deleteScene(scene.id);
                requestProjectSync(project.id);
                navigate(`/projects/${project.id}`);
              }}
              className="inline-flex items-center rounded-xl border border-rose-400/30 bg-rose-400/10 px-3 py-2 text-sm font-medium text-rose-200 transition hover:bg-rose-400/20 focus-visible:ring-2 focus-visible:ring-rose-300 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950"
            >
              Delete text block
            </button>
          ) : null}
        </div>
      </div>

      <section
        className={`rounded-3xl border ${
          isFocusMode ? 'border-white/5 bg-slate-950/60 px-6 py-6 sm:px-8' : 'app-panel p-6'
        }`}
      >
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-sm uppercase tracking-[0.18em] text-slate-400">
              {isFocusMode ? 'Focused Text Block' : 'Text Block'}
            </p>
            <p className="mt-2 text-sm text-slate-400">
              {isFocusMode
                ? 'A quieter writing surface that still saves locally as you type.'
                : 'Rich text saves locally as you write.'}
            </p>
          </div>
          <div className={`flex flex-wrap items-center gap-2 ${isFocusMode ? 'text-xs' : 'text-sm'} text-slate-400`}>
            <span aria-live="polite">{saveState === 'saving' ? 'Saving locally...' : 'Saved locally'}</span>
            <SyncStatusBadge projectId={project.id} compact />
            <span className="app-panel-soft rounded-full px-2.5 py-1">
              {sceneWordCount.toLocaleString()} words
            </span>
            <span className="app-panel-soft rounded-full px-2.5 py-1">
              {sceneCharacterCount.toLocaleString()} characters
            </span>
            <span className="app-panel-soft rounded-full px-2.5 py-1">
              {sceneReadingTimeMinutes === 0 ? 'Less than 1 min' : `${sceneReadingTimeMinutes} min read`}
            </span>
          </div>
        </div>

        {isFocusMode && projectCodexEntries.length > 0 ? (
          <div className="mt-5">
            <div className="app-panel-soft flex flex-wrap items-center justify-between gap-3 rounded-2xl px-4 py-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Codex Lookup</p>
                <p className="mt-1 text-sm text-slate-400">Search titles and tags without leaving the writing flow.</p>
              </div>
              <p className="text-xs text-slate-500">Cmd/Ctrl+Shift+L</p>
            </div>

            {isCodexLookupOpen ? (
              <div className="app-panel-inset mt-3 rounded-2xl p-4">
                <label className="block text-sm text-slate-300" htmlFor="focus-codex-search">
                  Search codex by title or tags
                </label>
                <input
                  ref={codexSearchInputRef}
                  id="focus-codex-search"
                  className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
                  placeholder="Search characters, locations, or tags"
                  value={codexQuery}
                  onChange={(event) => setCodexQuery(event.target.value)}
                />

                <div className="mt-3 space-y-2">
                  {filteredCodexEntries.length > 0 ? (
                    filteredCodexEntries.map((entry) => {
                      const isExpanded = expandedCodexEntryId === entry.id;
                      const preview = stripHtmlToPlainText(entry.content) || 'No details yet.';

                      return (
                        <div key={entry.id} className="app-panel-soft rounded-xl">
                          <button
                            type="button"
                            onClick={() =>
                              setExpandedCodexEntryId((current) => (current === entry.id ? null : entry.id))
                            }
                            className="app-focus-ring w-full px-4 py-3 text-left transition hover:bg-white/[0.04] focus-visible:ring-inset"
                            aria-expanded={isExpanded}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="min-w-0">
                                <p className="font-medium text-white">{entry.title}</p>
                                <p className="mt-1 text-[11px] uppercase tracking-[0.16em] text-slate-400">
                                  {entry.type}
                                  {entry.tags.length > 0 ? ` · ${entry.tags.join(', ')}` : ''}
                                </p>
                                <p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-300">{preview}</p>
                              </div>
                              <span className="shrink-0 text-xs text-slate-500">{isExpanded ? 'Hide' : 'Open'}</span>
                            </div>
                          </button>

                          {isExpanded ? (
                    <div className="border-t border-[color:var(--app-border)] px-4 py-3">
                      <p className="writing-reading-surface writing-body whitespace-pre-wrap text-slate-200">
                        {preview}
                      </p>
                    </div>
                          ) : null}
                        </div>
                      );
                    })
                  ) : (
                    <div className="app-panel-empty rounded-xl px-4 py-3 text-sm text-slate-400">
                      No codex entries match that search yet.
                    </div>
                  )}
                </div>
              </div>
            ) : null}
          </div>
        ) : null}

        <div className="writing-column mt-4">
          <label className="block text-sm text-slate-300" htmlFor="scene-title">
            Text block title
          </label>
          <input
            id="scene-title"
            className={`app-focus-ring mt-2 w-full border-0 bg-transparent font-semibold tracking-tight text-white placeholder:text-slate-600 ${
              isFocusMode ? 'text-4xl leading-tight sm:text-5xl' : 'text-3xl'
            }`}
            style={{ fontFamily: 'var(--writing-font-family)' }}
            value={scene.title}
            onChange={(event) => updateScene(scene.id, { title: event.target.value })}
            aria-label="Text block title"
            spellCheck
          />

          {!isFocusMode ? (
            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              <div className="app-panel-inset rounded-2xl px-4 py-3">
                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Words</p>
                <p className="mt-2 text-lg font-medium text-white">{sceneWordCount.toLocaleString()}</p>
              </div>
              <div className="app-panel-inset rounded-2xl px-4 py-3">
                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Characters</p>
                <p className="mt-2 text-lg font-medium text-white">{sceneCharacterCount.toLocaleString()}</p>
              </div>
              <div className="app-panel-inset rounded-2xl px-4 py-3">
                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Reading time</p>
                <p className="mt-2 text-lg font-medium text-white">
                  {sceneReadingTimeMinutes === 0 ? 'Less than 1 min' : `${sceneReadingTimeMinutes} min`}
                </p>
              </div>
            </div>
          ) : null}

          <div className={`flex flex-wrap gap-2 ${isFocusMode ? 'mt-8' : 'mt-6'}`}>
            <ToolbarButton
              label="Bold"
              active={editor?.isActive('bold')}
              disabled={!editor}
              onClick={() => editor?.chain().focus().toggleBold().run()}
            />
            <ToolbarButton
              label="Italic"
              active={editor?.isActive('italic')}
              disabled={!editor}
              onClick={() => editor?.chain().focus().toggleItalic().run()}
            />
            <ToolbarButton
              label="Bullet list"
              active={editor?.isActive('bulletList')}
              disabled={!editor}
              onClick={() => editor?.chain().focus().toggleBulletList().run()}
            />
            <ToolbarButton
              label="Undo"
              disabled={!editor || !editor.can().chain().focus().undo().run()}
              onClick={() => editor?.chain().focus().undo().run()}
            />
            <ToolbarButton
              label="Redo"
              disabled={!editor || !editor.can().chain().focus().redo().run()}
              onClick={() => editor?.chain().focus().redo().run()}
            />
          </div>

          <div
            className={`app-panel-inset rounded-2xl writing-body ${
              isFocusMode ? 'mt-5 p-6 sm:p-8' : 'mt-4 p-4'
            }`}
          >
            <EditorContent className="writing-editor" editor={editor} />
          </div>

          <p className="mt-3 text-sm leading-6 text-slate-400">
            Tip: use the toolbar or keyboard shortcuts like{' '}
            <kbd className="app-panel-soft rounded px-1.5 py-0.5 text-xs text-slate-300">Ctrl</kbd>+
            <kbd className="app-panel-soft rounded px-1.5 py-0.5 text-xs text-slate-300">B</kbd>{' '}
            for bold.
          </p>
        </div>

        <section className={`app-panel-inset mt-6 rounded-2xl ${isFocusMode ? 'p-4' : 'p-5'}`}>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="text-base font-medium text-white">Snapshots</h2>
              <p className="mt-2 text-sm leading-6 text-slate-400">
                Autosave keeps the live draft current. Snapshots are recovery points created when you leave an editing
                session after meaningful changes.
              </p>
            </div>
            <p className="text-sm text-slate-500">{sceneSnapshots.length} saved</p>
          </div>

          {sceneSnapshots.length === 0 ? (
            <div className="app-panel-empty mt-4 rounded-2xl px-4 py-3 text-sm leading-6 text-slate-400">
              No snapshots yet. Leave the editor after a meaningful change to create a recovery point automatically.
            </div>
          ) : (
            <div className="mt-4 space-y-3">
              {sceneSnapshots.map((snapshot) => {
                const preview = stripHtmlToPlainText(snapshot.content) || 'No content saved.';
                return (
                  <article key={snapshot.id} className="app-panel-soft rounded-2xl p-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <h3 className="font-medium text-white">{snapshot.title || 'Untitled Text Block'}</h3>
                        <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-500">
                          {formatSnapshotDate(snapshot.createdAt)}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const confirmed = window.confirm(
                            `Restore the snapshot from ${formatSnapshotDate(snapshot.createdAt)}? Your current draft will be replaced.`,
                          );
                          if (!confirmed) {
                            return;
                          }

                          restoreRevisionSnapshot(snapshot.id);
                          const restoredScene = useLoreLoomStore.getState().getSceneById(scene.id);
                          if (restoredScene) {
                            resetSessionStart(restoredScene);
                          }
                          requestProjectSync(project.id);
                        }}
                        className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
                      >
                        Restore snapshot
                      </button>
                    </div>
                    <p className="mt-3 line-clamp-4 whitespace-pre-wrap text-sm leading-6 text-slate-300">{preview}</p>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </section>
    </div>
  );
}
