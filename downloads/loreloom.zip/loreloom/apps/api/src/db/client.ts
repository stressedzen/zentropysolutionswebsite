import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { applySqlitePragmas, type SqliteDatabase } from './pragmas.js';

export function createDatabase(databasePath: string): SqliteDatabase {
  fs.mkdirSync(path.dirname(databasePath), { recursive: true });

  const database = new Database(databasePath);
  applySqlitePragmas(database);

  return database;
}
