import { useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import type { ProjectSyncMeta } from '../lib/types';
import { useLoreLoomStore } from '../store/useLoreLoomStore';

type BadgeState = {
  label: string;
  className: string;
  title?: string;
};

function describeSync(meta: ProjectSyncMeta | undefined, backendStatus: 'unknown' | 'online' | 'offline'): BadgeState {
  if (meta?.status === 'conflict') {
    return {
      label: 'Conflict',
      className: 'border-[color:var(--app-border-strong)] bg-[rgba(198,154,84,0.12)] text-[color:var(--app-gold-soft)]',
      title: meta.error ?? 'The backend has a newer version of this project.',
    };
  }

  if (meta?.status === 'syncing') {
    return {
      label: 'Syncing',
      className: 'border-[color:var(--app-border-soft)] bg-[rgba(123,90,137,0.14)] text-[#e6d7ef]',
      title: 'LoreLoom is saving a durable copy in the backend.',
    };
  }

  if (meta?.status === 'offline' || backendStatus === 'offline') {
    return {
      label: 'Offline',
      className: 'border-[color:var(--app-border)] bg-[rgba(255,248,236,0.04)] text-slate-300',
      title: meta?.error ?? 'Local writing is still available. Backend sync will retry later.',
    };
  }

  if (meta?.dirty) {
    return {
      label: 'Local changes',
      className: 'border-[color:var(--app-border)] bg-[rgba(255,248,236,0.04)] text-slate-200',
      title: 'Changes are saved locally and waiting for backend sync.',
    };
  }

  if (meta?.lastSyncAt) {
    return {
      label: 'Synced',
      className: 'border-[rgba(167,140,103,0.35)] bg-[rgba(167,140,103,0.12)] text-[#f2dcc0]',
      title: `Last synced ${new Date(meta.lastSyncAt).toLocaleString()}.`,
    };
  }

  return {
    label: backendStatus === 'online' ? 'Ready to sync' : 'Local only',
    className: 'border-[color:var(--app-border)] bg-[rgba(255,248,236,0.04)] text-slate-300',
    title: 'The local-first editor is ready. A backend copy will sync when available.',
  };
}

export default function SyncStatusBadge({ projectId, compact = false }: { projectId?: string; compact?: boolean }) {
  const location = useLocation();
  const syncProjects = useLoreLoomStore((state) => state.sync.projects);
  const backendStatus = useLoreLoomStore((state) => state.sync.backendStatus);

  const derivedProjectId = useMemo(() => {
    if (projectId) {
      return projectId;
    }

    const match = location.pathname.match(/\/projects\/([^/]+)/);
    return match?.[1];
  }, [location.pathname, projectId]);

  const meta = useMemo(() => {
    if (derivedProjectId) {
      return syncProjects[derivedProjectId];
    }

    const projectMetas = Object.values(syncProjects);
    if (projectMetas.some((entry) => entry.status === 'conflict')) {
      return projectMetas.find((entry) => entry.status === 'conflict');
    }
    if (projectMetas.some((entry) => entry.status === 'syncing')) {
      return projectMetas.find((entry) => entry.status === 'syncing');
    }
    if (projectMetas.some((entry) => entry.status === 'offline')) {
      return projectMetas.find((entry) => entry.status === 'offline');
    }
    if (projectMetas.some((entry) => entry.dirty)) {
      return projectMetas.find((entry) => entry.dirty);
    }
    if (projectMetas.some((entry) => entry.lastSyncAt)) {
      return projectMetas
        .filter((entry) => entry.lastSyncAt)
        .sort((left, right) => (right.lastSyncAt ?? '').localeCompare(left.lastSyncAt ?? ''))[0];
    }

    return undefined;
  }, [derivedProjectId, syncProjects]);

  const badge = describeSync(meta, backendStatus);

  return (
    <span
      title={badge.title}
      className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium ${badge.className} ${
        compact ? '' : 'tracking-[0.08em] uppercase'
      }`}
    >
      {badge.label}
    </span>
  );
}
