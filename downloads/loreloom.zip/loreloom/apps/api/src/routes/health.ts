import type { FastifyInstance } from 'fastify';
import type { AppConfig } from '../config.js';

export async function registerHealthRoute(app: FastifyInstance, config: AppConfig) {
  app.get('/health', async () => {
    return {
      status: 'ok',
      appName: config.appName,
      timestamp: new Date().toISOString(),
    };
  });
}
