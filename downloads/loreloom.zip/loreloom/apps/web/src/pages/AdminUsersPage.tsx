import { useEffect, useMemo, useState, type FormEvent } from 'react';
import {
  ApiClientError,
  createAdminManagedUser,
  fetchAdminUsers,
  resetAdminManagedUserPassword,
  type AdminUserSummary,
} from '../lib/api';
import { copyTextToClipboard } from '../lib/clipboard';

type CreateUserFormState = {
  username: string;
  displayName: string;
  role: 'admin' | 'user';
};

type TemporaryPasswordNotice = {
  mode: 'created' | 'reset';
  username: string;
  password: string;
};

type ValidationIssue = {
  message: string;
};

const initialFormState: CreateUserFormState = {
  username: '',
  displayName: '',
  role: 'user',
};

function formatAdminError(error: unknown) {
  if (error instanceof ApiClientError) {
    if (
      error.status === 400 &&
      typeof error.data === 'object' &&
      error.data !== null &&
      'issues' in error.data &&
      Array.isArray(error.data.issues)
    ) {
      const issues = error.data.issues.filter(
        (issue): issue is ValidationIssue =>
          typeof issue === 'object' &&
          issue !== null &&
          'message' in issue &&
          typeof (issue as { message?: unknown }).message === 'string',
      );

      if (issues.length > 0) {
        return issues.map((issue) => issue.message).join('\n');
      }
    }

    if (error.status === 403) {
      return 'Admin access is required for local user management.';
    }

    if (error.status === 404) {
      return 'That user could not be found anymore. Try refreshing the page.';
    }

    if (error.status === 409 && typeof error.data === 'object' && error.data !== null && 'error' in error.data) {
      if (error.data.error === 'username_taken') {
        return 'That username is already in use on this LoreLoom instance.';
      }
    }

    return error.message;
  }

  return error instanceof Error ? error.message : 'Something went wrong while talking to the LoreLoom API.';
}

function formatDate(value: string) {
  try {
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(new Date(value));
  } catch {
    return value;
  }
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<AdminUserSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [form, setForm] = useState<CreateUserFormState>(initialFormState);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [activeResetUserId, setActiveResetUserId] = useState<string | null>(null);
  const [temporaryPasswordNotice, setTemporaryPasswordNotice] = useState<TemporaryPasswordNotice | null>(null);
  const [temporaryPasswordVisible, setTemporaryPasswordVisible] = useState(true);
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);
  const sortedUsers = useMemo(
    () =>
      [...users].sort((left, right) => {
        if (left.role !== right.role) {
          return left.role === 'admin' ? -1 : 1;
        }

        return left.username.localeCompare(right.username);
      }),
    [users],
  );

  const loadUsers = async () => {
    setLoading(true);
    setLoadError(null);

    try {
      const response = await fetchAdminUsers();
      setUsers(response.users);
    } catch (error) {
      setLoadError(formatAdminError(error));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadUsers();
  }, []);

  const handleCreateUser = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);
    setTemporaryPasswordNotice(null);
    setSubmitting(true);

    try {
      const response = await createAdminManagedUser({
        username: form.username.trim(),
        displayName: form.displayName.trim() || undefined,
        role: form.role,
      });

      setUsers((current) => [...current, response.user]);
      setTemporaryPasswordNotice({
        mode: 'created',
        username: response.user.username,
        password: response.temporaryPassword,
      });
      setTemporaryPasswordVisible(true);
      setCopyFeedback(null);
      setForm(initialFormState);
    } catch (error) {
      setFormError(formatAdminError(error));
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetPassword = async (user: AdminUserSummary) => {
    const confirmed = window.confirm(
      `Reset the password for ${user.username}? Their existing sessions will be signed out immediately.`,
    );

    if (!confirmed) {
      return;
    }

    setFormError(null);
    setTemporaryPasswordNotice(null);
    setActiveResetUserId(user.id);

    try {
      const response = await resetAdminManagedUserPassword(user.id);
      setUsers((current) =>
        current.map((entry) => (entry.id === response.user.id ? response.user : entry)),
      );
      setTemporaryPasswordNotice({
        mode: 'reset',
        username: response.user.username,
        password: response.temporaryPassword,
      });
      setTemporaryPasswordVisible(true);
      setCopyFeedback(null);
    } catch (error) {
      setFormError(formatAdminError(error));
    } finally {
      setActiveResetUserId(null);
    }
  };

  const copyTemporaryPassword = async () => {
    if (!temporaryPasswordNotice?.password) {
      return;
    }

    const copied = await copyTextToClipboard(temporaryPasswordNotice.password);
    if (copied) {
      setCopyFeedback('Password copied to clipboard.');
      return;
    }

    setCopyFeedback('Copy failed. You can select the password manually and copy it yourself.');
  };

  return (
    <div className="space-y-6">
      <section className="rounded-3xl border border-white/10 bg-white/5 p-6">
        <div className="space-y-2">
          <p className="text-sm font-medium uppercase tracking-[0.18em] text-amber-200/80">Admin / Users</p>
          <h1 className="text-3xl font-semibold tracking-tight text-white">Local user management</h1>
          <p className="max-w-3xl text-sm leading-7 text-slate-300">
            Admins can create local users and reset passwords for trusted self-hosted testing. LoreLoom
            does not email passwords or recovery links.
          </p>
        </div>
      </section>

      {temporaryPasswordNotice ? (
        <section className="rounded-3xl border border-amber-300/30 bg-amber-300/10 p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="space-y-2">
              <p className="text-sm font-medium text-amber-100">
                {temporaryPasswordNotice.mode === 'created'
                  ? `Temporary password for new user ${temporaryPasswordNotice.username}`
                  : `Temporary password for ${temporaryPasswordNotice.username}`}
              </p>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => setTemporaryPasswordVisible((current) => !current)}
                  className="rounded-xl border border-white/15 px-3 py-1.5 text-xs font-medium text-slate-100 transition hover:bg-white/5 focus:outline-none focus:ring-2 focus:ring-amber-300/40"
                >
                  {temporaryPasswordVisible ? 'Hide password' : 'Show password'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    void copyTemporaryPassword();
                  }}
                  className="rounded-xl border border-white/20 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-amber-300/60"
                >
                  Copy password
                </button>
              </div>
              <input
                type={temporaryPasswordVisible ? 'text' : 'password'}
                readOnly
                value={temporaryPasswordNotice.password}
                className="w-full rounded-2xl border border-white/10 bg-slate-950/60 px-4 py-3 font-mono text-sm text-white outline-none"
                onFocus={(event) => event.currentTarget.select()}
              />
              <p className="text-xs leading-6 text-amber-100/80">
                This password is only shown once, please copy it down.
              </p>
              {copyFeedback ? <p className="text-xs leading-6 text-amber-100/90">{copyFeedback}</p> : null}
            </div>
            <button
              type="button"
              onClick={() => setTemporaryPasswordNotice(null)}
              className="rounded-xl border border-white/10 px-4 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/5 focus:outline-none focus:ring-2 focus:ring-amber-300/40"
            >
              Clear
            </button>
          </div>
        </section>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
        <section className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <div className="mb-5 space-y-2">
            <h2 className="text-xl font-semibold text-white">Create a local user</h2>
            <p className="text-sm leading-6 text-slate-300">
              New users receive a generated temporary password. Public signup is not enabled.
            </p>
          </div>

          <form className="space-y-4" onSubmit={handleCreateUser}>
            <label className="block space-y-2 text-sm text-slate-200">
              <span>Username</span>
              <input
                value={form.username}
                onChange={(event) => setForm((current) => ({ ...current, username: event.target.value }))}
                className="w-full rounded-xl border border-white/10 bg-slate-900/70 px-4 py-3 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-amber-300/70 focus:ring-2 focus:ring-amber-300/30"
                placeholder="new_writer"
                autoComplete="off"
              />
            </label>
            <label className="block space-y-2 text-sm text-slate-200">
              <span>Display name</span>
              <input
                value={form.displayName}
                onChange={(event) => setForm((current) => ({ ...current, displayName: event.target.value }))}
                className="w-full rounded-xl border border-white/10 bg-slate-900/70 px-4 py-3 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-amber-300/70 focus:ring-2 focus:ring-amber-300/30"
                placeholder="Optional"
                autoComplete="off"
              />
            </label>
            <label className="block space-y-2 text-sm text-slate-200">
              <span>Role</span>
              <select
                value={form.role}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    role: event.target.value === 'admin' ? 'admin' : 'user',
                  }))
                }
                className="w-full rounded-xl border border-white/10 bg-slate-900/70 px-4 py-3 text-sm text-white outline-none transition focus:border-amber-300/70 focus:ring-2 focus:ring-amber-300/30"
              >
                <option value="user">User</option>
                <option value="admin">Admin</option>
              </select>
            </label>
            {formError ? (
              <div className="whitespace-pre-line rounded-2xl border border-rose-400/30 bg-rose-500/10 px-4 py-4 text-sm text-rose-100">
                {formError}
              </div>
            ) : null}
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex rounded-xl bg-white px-4 py-2 text-sm font-medium text-slate-950 transition hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-70 focus:outline-none focus:ring-2 focus:ring-amber-300 focus:ring-offset-2 focus:ring-offset-slate-950"
            >
              {submitting ? 'Creating user…' : 'Create user'}
            </button>
          </form>
        </section>

        <section className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <div className="mb-5 space-y-2">
            <h2 className="text-xl font-semibold text-white">Users on this instance</h2>
            <p className="text-sm leading-6 text-slate-300">
              Password resets sign the user out everywhere and generates a random password
            </p>
          </div>

          {loading ? <p className="text-sm text-slate-300">Loading users…</p> : null}

          {loadError ? (
            <div className="whitespace-pre-line rounded-2xl border border-rose-400/30 bg-rose-500/10 px-4 py-4 text-sm text-rose-100">
              {loadError}
            </div>
          ) : null}

          {!loading && !loadError ? (
            <div className="space-y-3">
              {sortedUsers.map((user) => (
                <article
                  key={user.id}
                  className="rounded-2xl border border-white/10 bg-slate-950/40 px-4 py-4"
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-base font-semibold text-white">{user.displayName?.trim() || user.username}</h3>
                        <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs uppercase tracking-[0.16em] text-slate-300">
                          {user.role}
                        </span>
                      </div>
                      <p className="text-sm text-slate-400">@{user.username}</p>
                      <p className="text-xs leading-6 text-slate-500">
                        Created {formatDate(user.createdAt)}. Updated {formatDate(user.updatedAt)}.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        void handleResetPassword(user);
                      }}
                      disabled={activeResetUserId === user.id}
                      className="inline-flex rounded-xl border border-white/10 px-4 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-70 focus:outline-none focus:ring-2 focus:ring-amber-300/40"
                    >
                      {activeResetUserId === user.id ? 'Resetting…' : 'Reset password'}
                    </button>
                  </div>
                </article>
              ))}
            </div>
          ) : null}
        </section>
      </div>
    </div>
  );
}
