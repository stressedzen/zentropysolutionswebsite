import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { ZodError } from 'zod';
import type { AppConfig } from '../config.js';
import type { SqliteDatabase } from '../db/pragmas.js';
import {
  getProjectBundleById,
  getProjectSummaries,
  removeProjectBundle,
  upsertProjectBundle,
} from '../services/project-bundle-service.js';
import { projectParamsSchema, putProjectBundleBodySchema } from '../validators/project-bundle.js';
import { requireAuthenticatedUser, type AuthenticatedRequest } from './auth-guard.js';

function sendValidationError(
  reply: { code: (statusCode: number) => { send: (payload: unknown) => unknown } },
  error: ZodError,
) {
  return reply.code(400).send({
    error: 'validation_error',
    issues: error.issues.map((issue) => ({
      path: issue.path.join('.'),
      message: issue.message,
    })),
  });
}

export async function registerProjectRoutes(
  app: FastifyInstance,
  database: SqliteDatabase,
  config: Pick<AppConfig, 'authCookieName' | 'authSecureCookie'>,
) {
  const requireProjectAuth = async (request: FastifyRequest, reply: FastifyReply) => {
    const currentUser = await requireAuthenticatedUser(request, reply, database, config);
    if (!currentUser) {
      return;
    }

    (request as AuthenticatedRequest).currentUser = currentUser;
  };

  app.get('/api/projects', { preHandler: requireProjectAuth }, async (request) => {
    const currentUser = (request as AuthenticatedRequest).currentUser;
    return {
      projects: getProjectSummaries(database, currentUser.id),
    };
  });

  app.get('/api/projects/:id/bundle', { preHandler: requireProjectAuth }, async (request, reply) => {
    const currentUser = (request as AuthenticatedRequest).currentUser;
    const paramsResult = projectParamsSchema.safeParse(request.params);

    if (!paramsResult.success) {
      return sendValidationError(reply, paramsResult.error);
    }

    const bundle = getProjectBundleById(database, paramsResult.data.id, currentUser.id);

    if (!bundle) {
      return reply.code(404).send({
        error: 'not_found',
        message: `Project ${paramsResult.data.id} was not found.`,
      });
    }

    return bundle;
  });

  app.put('/api/projects/:id/bundle', { preHandler: requireProjectAuth }, async (request, reply) => {
    const currentUser = (request as AuthenticatedRequest).currentUser;
    const paramsResult = projectParamsSchema.safeParse(request.params);

    if (!paramsResult.success) {
      return sendValidationError(reply, paramsResult.error);
    }

    const bodyResult = putProjectBundleBodySchema.safeParse(request.body);

    if (!bodyResult.success) {
      return sendValidationError(reply, bodyResult.error);
    }

    if (paramsResult.data.id !== bodyResult.data.bundle.project.id) {
      return reply.code(400).send({
        error: 'project_id_mismatch',
        message: 'Route project id must match bundle.project.id.',
      });
    }

    const result = upsertProjectBundle(
      database,
      currentUser.id,
      bodyResult.data.baseRevision,
      bodyResult.data.bundle,
    );

    if (result.status === 'not_found') {
      return reply.code(404).send({
        error: 'not_found',
        message: `Project ${paramsResult.data.id} was not found.`,
      });
    }

    if (result.status === 'conflict') {
      return reply.code(409).send({
        error: 'revision_conflict',
        serverRevision: result.serverRevision,
        bundle: result.bundle,
      });
    }

    return {
      ok: true,
      serverRevision: result.serverRevision,
      updatedAt: result.updatedAt,
    };
  });

  app.delete('/api/projects/:id', { preHandler: requireProjectAuth }, async (request, reply) => {
    const currentUser = (request as AuthenticatedRequest).currentUser;
    const paramsResult = projectParamsSchema.safeParse(request.params);

    if (!paramsResult.success) {
      return sendValidationError(reply, paramsResult.error);
    }

    const deleted = removeProjectBundle(database, currentUser.id, paramsResult.data.id);

    if (!deleted) {
      return reply.code(404).send({
        error: 'not_found',
        message: `Project ${paramsResult.data.id} was not found.`,
      });
    }

    return reply.code(200).send({
      ok: true,
    });
  });
}
