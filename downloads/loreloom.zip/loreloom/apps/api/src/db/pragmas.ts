import Database from 'better-sqlite3';

export type SqliteDatabase = InstanceType<typeof Database>;

export function applySqlitePragmas(database: SqliteDatabase) {
  database.pragma('journal_mode = WAL');
  database.pragma('foreign_keys = ON');
  database.pragma('synchronous = NORMAL');
  database.pragma('busy_timeout = 5000');
}
