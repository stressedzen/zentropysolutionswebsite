import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';

const PASSWORD_SCHEME = 'scrypt';
const SCRYPT_COST = 1 << 14;
const SCRYPT_BLOCK_SIZE = 8;
const SCRYPT_PARALLELIZATION = 1;
const DERIVED_KEY_LENGTH = 64;
const SALT_LENGTH_BYTES = 16;
const MAX_MEMORY_BYTES = 64 * 1024 * 1024;
const TEMP_PASSWORD_BYTES = 12;

type ScryptParameters = {
  cost: number;
  blockSize: number;
  parallelization: number;
  keyLength: number;
};

function encodeBase64Url(buffer: Buffer): string {
  return buffer.toString('base64url');
}

async function deriveKey(password: string, salt: Buffer, parameters: ScryptParameters): Promise<Buffer> {
  return new Promise<Buffer>((resolve, reject) => {
    scryptCallback(
      password,
      salt,
      parameters.keyLength,
      {
        N: parameters.cost,
        r: parameters.blockSize,
        p: parameters.parallelization,
        maxmem: MAX_MEMORY_BYTES,
      },
      (error, derivedKey) => {
        if (error) {
          reject(error);
          return;
        }

        resolve(Buffer.from(derivedKey));
      },
    );
  });
}

function assertPassword(password: string) {
  if (password.length === 0) {
    throw new Error('Password must not be empty.');
  }
}

export async function hashPassword(password: string): Promise<string> {
  assertPassword(password);

  const salt = randomBytes(SALT_LENGTH_BYTES);
  const derivedKey = await deriveKey(password, salt, {
    cost: SCRYPT_COST,
    blockSize: SCRYPT_BLOCK_SIZE,
    parallelization: SCRYPT_PARALLELIZATION,
    keyLength: DERIVED_KEY_LENGTH,
  });

  return [
    PASSWORD_SCHEME,
    SCRYPT_COST,
    SCRYPT_BLOCK_SIZE,
    SCRYPT_PARALLELIZATION,
    DERIVED_KEY_LENGTH,
    encodeBase64Url(salt),
    encodeBase64Url(derivedKey),
  ].join('$');
}

export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  if (password.length === 0) {
    return false;
  }

  const [scheme, cost, blockSize, parallelization, keyLength, saltEncoded, hashEncoded] =
    storedHash.split('$');

  if (
    scheme !== PASSWORD_SCHEME ||
    !cost ||
    !blockSize ||
    !parallelization ||
    !keyLength ||
    !saltEncoded ||
    !hashEncoded
  ) {
    return false;
  }

  const parsedCost = Number.parseInt(cost, 10);
  const parsedBlockSize = Number.parseInt(blockSize, 10);
  const parsedParallelization = Number.parseInt(parallelization, 10);
  const parsedKeyLength = Number.parseInt(keyLength, 10);

  if (
    !Number.isInteger(parsedCost) ||
    !Number.isInteger(parsedBlockSize) ||
    !Number.isInteger(parsedParallelization) ||
    !Number.isInteger(parsedKeyLength)
  ) {
    return false;
  }

  let salt: Buffer;
  let expectedHash: Buffer;

  try {
    salt = Buffer.from(saltEncoded, 'base64url');
    expectedHash = Buffer.from(hashEncoded, 'base64url');
  } catch {
    return false;
  }

  const actualHash = await deriveKey(password, salt, {
    cost: parsedCost,
    blockSize: parsedBlockSize,
    parallelization: parsedParallelization,
    keyLength: parsedKeyLength,
  });

  if (expectedHash.length !== actualHash.length) {
    return false;
  }

  return timingSafeEqual(expectedHash, actualHash);
}

export function createTemporaryPassword(): string {
  return randomBytes(TEMP_PASSWORD_BYTES).toString('base64url').slice(0, 16);
}
