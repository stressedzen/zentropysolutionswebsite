import { makeId, nowIso } from './storage';
import type { CodexNode, CodexNodeType } from './types';

export const DEFAULT_CODEX_NODE_TITLE = 'Codex';
export const DEFAULT_CODEX_NODE_TYPE: CodexNodeType = 'codex';

export const CODEX_NODE_TYPES: CodexNodeType[] = [
  'codex',
  'group',
  'characters',
  'places',
  'factions',
  'objects',
  'timeline',
  'research',
  'custom',
];

export type CodexNodeTreeItem = CodexNode & {
  children: CodexNodeTreeItem[];
};

function compareCodexNodes(left: CodexNode, right: CodexNode) {
  if (left.orderIndex !== right.orderIndex) {
    return left.orderIndex - right.orderIndex;
  }

  const created = left.createdAt.localeCompare(right.createdAt);
  if (created !== 0) {
    return created;
  }

  return left.title.localeCompare(right.title);
}

export function createDefaultCodexNode(projectId: string, timestamp = nowIso()): CodexNode {
  return {
    id: makeId(),
    projectId,
    parentId: null,
    type: DEFAULT_CODEX_NODE_TYPE,
    customTypeLabel: null,
    title: DEFAULT_CODEX_NODE_TITLE,
    tags: [],
    orderIndex: 0,
    createdAt: timestamp,
    updatedAt: timestamp,
  };
}

export function getNextCodexOrderIndex(nodes: CodexNode[], parentId: string | null) {
  return nodes
    .filter((node) => node.parentId === parentId)
    .reduce((max, node) => Math.max(max, node.orderIndex), -1) + 1;
}

export function getCodexNodeTypeLabel(node: Pick<CodexNode, 'type' | 'customTypeLabel'>) {
  if (node.type === 'custom') {
    return node.customTypeLabel?.trim() || 'Custom';
  }

  switch (node.type) {
    case 'codex':
      return 'Codex';
    case 'group':
      return 'Group';
    case 'characters':
      return 'Characters';
    case 'places':
      return 'Places';
    case 'factions':
      return 'Factions';
    case 'objects':
      return 'Objects';
    case 'timeline':
      return 'Timeline';
    case 'research':
      return 'Research';
  }
}

export function getSortedCodexNodesForProject(nodes: CodexNode[], projectId: string) {
  return nodes
    .filter((node) => node.projectId === projectId)
    .sort(compareCodexNodes);
}

export function sortCodexNodesForExport(nodes: CodexNode[]) {
  return [...nodes].sort(compareCodexNodes).map((node) => ({
    ...node,
    customTypeLabel: node.customTypeLabel ?? null,
    tags: Array.isArray(node.tags) ? [...node.tags] : [],
  }));
}

export function findDefaultCodexNode(nodes: CodexNode[], projectId: string) {
  const projectNodes = getSortedCodexNodesForProject(nodes, projectId);
  return projectNodes[0] ?? null;
}

export function buildCodexNodeTree(nodes: CodexNode[]): CodexNodeTreeItem[] {
  const byId = new Map(nodes.map((node) => [node.id, node]));
  const grouped = new Map<string | null, CodexNode[]>();

  for (const node of nodes) {
    const parentId = node.parentId && byId.has(node.parentId) ? node.parentId : null;
    const current = grouped.get(parentId) ?? [];
    current.push(node);
    grouped.set(parentId, current);
  }

  const build = (parentId: string | null): CodexNodeTreeItem[] => {
    const children = (grouped.get(parentId) ?? []).slice().sort(compareCodexNodes);
    return children.map((node) => ({
      ...node,
      children: build(node.id),
    }));
  };

  return build(null);
}

export function flattenCodexNodeTree(nodes: CodexNodeTreeItem[]) {
  const flat: Array<{ node: CodexNodeTreeItem; depth: number }> = [];

  const visit = (list: CodexNodeTreeItem[], depth: number) => {
    for (const node of list) {
      flat.push({ node, depth });
      visit(node.children, depth + 1);
    }
  };

  visit(nodes, 0);
  return flat;
}
