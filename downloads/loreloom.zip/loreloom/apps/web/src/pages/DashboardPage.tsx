import { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LoreLoomLogo from '../components/LoreLoomLogo';
import { useLoreLoomStore } from '../store/useLoreLoomStore';
import { scenePreview, sortByUpdatedThenCreated } from '../lib/storage';
import { parseProjectBackup } from '../lib/backup';
import { countProjectWords, formatRelativeBackupDate, formatWritingDate, isBackupReminderStale } from '../lib/writing-stats';

export default function DashboardPage() {
  const navigate = useNavigate();
  const projects = useLoreLoomStore((state) => state.projects);
  const scenes = useLoreLoomStore((state) => state.scenes);
  const createProject = useLoreLoomStore((state) => state.createProject);
  const importProjectBackup = useLoreLoomStore((state) => state.importProjectBackup);
  const requestProjectSync = useLoreLoomStore((state) => state.requestProjectSync);
  const lastProjectBackupExportAt = useLoreLoomStore((state) => state.backups.lastProjectBackupExportAt);
  const importInputRef = useRef<HTMLInputElement | null>(null);
  const [name, setName] = useState('');
  const [importError, setImportError] = useState('');
  const sortedProjects = useMemo(() => sortByUpdatedThenCreated(projects), [projects]);
  const backupReminderIsStale = isBackupReminderStale(lastProjectBackupExportAt);

  return (
    <div className="space-y-8">
      <section className="grid gap-4 lg:grid-cols-[1.4fr_0.9fr]">
        <div className="app-panel-hero rounded-3xl p-6">
          <div className="mb-3 flex items-center gap-3">
            <LoreLoomLogo className="h-9 sm:h-10" />
            <p className="app-accent-label text-sm uppercase tracking-[0.22em]">Dashboard</p>
          </div>
          <h1 className="max-w-2xl text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Build worlds, text blocks, and notes in a lightweight workspace.
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-6 text-slate-300 sm:text-base">
            
          </p>
        </div>

        <form
          className="app-panel rounded-3xl p-6"
          onSubmit={(event) => {
            event.preventDefault();
            const project = createProject(name);
            setName('');
            navigate(`/projects/${project.id}`);
          }}
        >
          <h2 className="text-lg font-medium text-white">Create Project</h2>
          <label className="mt-4 block text-sm text-slate-300" htmlFor="project-name">
            Project name
          </label>
          <input
            id="project-name"
            className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2 ring-0"
            placeholder="The Glass City"
            value={name}
            onChange={(event) => setName(event.target.value)}
          />
          <button
            type="submit"
            className="app-button-primary app-focus-ring mt-4 inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
          >
            Create project
          </button>
        </form>
      </section>

      <section
        className={`rounded-3xl border p-5 ${
          backupReminderIsStale ? 'app-panel border-[color:var(--app-border-strong)] bg-[color:var(--app-panel-highlight)]' : 'app-panel'
        }`}
      >
        <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h2 className="text-sm font-medium uppercase tracking-[0.18em] text-slate-400">Manual backups</h2>
            <p className="mt-2 text-base font-medium text-white">
              Last backup exported: {formatRelativeBackupDate(lastProjectBackupExportAt)}
            </p>
          </div>
          <p className="max-w-xl text-sm leading-6 text-slate-400">
            Manual backup exports are an extra ownership copy alongside local autosave and backend sync.
          </p>
        </div>
      </section>

      <section>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-white">Projects</h2>
          <span className="text-sm text-slate-400">{sortedProjects.length} total</span>
        </div>

        {sortedProjects.length === 0 ? (
          <div className="app-panel-empty rounded-3xl p-8 text-slate-300">
            <h3 className="text-base font-medium text-white">No projects yet</h3>
            <p className="mt-2 max-w-xl text-sm leading-6 text-slate-300">
              Create a project to begin a writing workspace. Projects and text blocks are saved in this browser.
            </p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {sortedProjects.map((project) => {
              const projectScenes = scenes.filter((scene) => scene.projectId === project.id);
              const latestScene = projectScenes[0];
              const projectWordCount = countProjectWords(projectScenes);

              return (
                <button
                  key={project.id}
                  type="button"
                  onClick={() => navigate(`/projects/${project.id}`)}
                  className="app-panel app-focus-ring rounded-3xl p-5 text-left transition hover:-translate-y-0.5 hover:border-[color:var(--app-border-strong)] hover:bg-white/[0.05]"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-medium text-white">{project.name}</h3>
                      <p className="mt-1 text-sm text-slate-400">
                        {projectScenes.length} text block{projectScenes.length === 1 ? '' : 's'}
                      </p>
                    </div>
                    <span className="rounded-full border border-[color:var(--app-border)] px-3 py-1 text-xs text-slate-400">
                      Project
                    </span>
                  </div>
                  <p className="mt-4 line-clamp-3 text-sm leading-6 text-slate-300">
                    {latestScene ? scenePreview(latestScene) : 'No text blocks yet.'}
                  </p>
                  <div className="mt-4 grid grid-cols-2 gap-3 text-left sm:grid-cols-3">
                    <div className="app-panel-inset rounded-2xl px-3 py-2">
                      <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Words</p>
                      <p className="mt-1 text-sm font-medium text-white">{projectWordCount.toLocaleString()}</p>
                    </div>
                    <div className="app-panel-inset rounded-2xl px-3 py-2">
                      <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Text Blocks</p>
                      <p className="mt-1 text-sm font-medium text-white">{projectScenes.length}</p>
                    </div>
                    <div className="app-panel-inset rounded-2xl px-3 py-2 col-span-2 sm:col-span-1">
                      <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Updated</p>
                      <p className="mt-1 text-sm font-medium text-white">{formatWritingDate(project.updatedAt)}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </section>

      <section className="app-panel rounded-3xl p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="max-w-2xl">
            <h2 className="text-lg font-medium text-white">Import project backup</h2>
            <p className="mt-2 text-sm leading-6 text-slate-300">
              Import a LoreLoom project backup JSON file to restore or migrate a project without overwriting
              your existing data.
            </p>
          </div>
          <button
            type="button"
            onClick={() => importInputRef.current?.click()}
            className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
          >
            Import backup
          </button>
        </div>
        <input
          ref={importInputRef}
          type="file"
          accept=".json,application/json"
          className="sr-only"
          onChange={async (event) => {
            const file = event.target.files?.[0];
            event.target.value = '';

            if (!file) {
              return;
            }

            try {
              const text = await file.text();
              const parsed = parseProjectBackup(text);
              if (!parsed.ok) {
                throw new Error(parsed.error);
              }

              const importedProject = importProjectBackup(parsed.backup);
              requestProjectSync(importedProject.id);
              setImportError('');
              navigate(`/projects/${importedProject.id}`);
            } catch (error) {
              setImportError(error instanceof Error ? error.message : 'Import failed.');
            }
          }}
        />
        {importError ? (
          <p className="mt-4 text-sm leading-6 text-rose-200" role="alert">
            {importError}
          </p>
        ) : (
          <p className="mt-4 text-sm leading-6 text-slate-400">
            Supported files are LoreLoom project backups exported from the project page.
          </p>
        )}
      </section>

      <section className="app-panel rounded-3xl p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="max-w-2xl">
            <h2 className="text-lg font-medium text-white">Diagnostics</h2>
            <p className="mt-2 text-sm leading-6 text-slate-300">
              Inspect local sync and deployment diagnostics, then export a manual diagnostic bundle if you want to share a bug report.
            </p>
            <p className="mt-3 text-sm leading-6 text-slate-400">
              Need help or have suggestions? Join the{' '}
              <a
                href="https://discord.gg/ktUw2gsyAW"
                target="_blank"
                rel="noreferrer"
                className="app-link underline underline-offset-4 transition"
              >
                LoreLoom Discord
              </a>
              .
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/diagnostics')}
            className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
          >
            Open diagnostics
          </button>
        </div>
      </section>
    </div>
  );
}
