import { useEffect, useMemo, useState, type FormEvent, type RefObject } from 'react';
import { CODEX_NODE_TYPES, type CodexNodeTreeItem, getCodexNodeTypeLabel } from '../../lib/codex';
import type { CodexEntry, CodexEntryType, CodexNodeType } from '../../lib/types';

const CODEX_ENTRY_TYPES: CodexEntryType[] = [
  'character',
  'location',
  'object',
  'faction',
  'lore',
  'timeline',
  'custom',
];

type FlatCodexNodeOption = {
  node: CodexNodeTreeItem;
  depth: number;
};

type CodexPanelProps = {
  projectId: string;
  sectionRef: RefObject<HTMLElement | null>;
  nodes: CodexNodeTreeItem[];
  flatNodeOptions: FlatCodexNodeOption[];
  entries: CodexEntry[];
  selectedCodexNodeId: string | null;
  selectedCodexId: string | null;
  deleteableCodexNodeIds: Set<string>;
  editorMode: 'entry' | 'node';
  defaultCodexNodeId: string | null;
  isEditingCodexEntry: boolean;
  isEditingCodexNode: boolean;
  codexTitle: string;
  codexType: CodexEntryType;
  codexContent: string;
  codexTags: string;
  codexEntryNodeId: string | null;
  codexNodeParentId: string | null;
  codexNodeTitle: string;
  codexNodeType: CodexNodeType;
  codexNodeCustomTypeLabel: string;
  codexNodeTags: string;
  onSelectNode: (nodeId: string) => void;
  onCreateEntry: (nodeId?: string | null) => void;
  onEditNode: (nodeId: string) => void;
  onCreateRootNode: () => void;
  onCreateChildNode: (nodeId: string) => void;
  onDeleteNode: (nodeId: string) => void;
  onSelectEntry: (entryId: string) => void;
  onDeleteEntry: () => void;
  onEntrySubmit: (event: FormEvent<HTMLFormElement>) => void;
  onNodeSubmit: (event: FormEvent<HTMLFormElement>) => void;
  onCancelNodeEdit: () => void;
  onTitleChange: (value: string) => void;
  onTypeChange: (value: CodexEntryType) => void;
  onTagsChange: (value: string) => void;
  onContentChange: (value: string) => void;
  onCodexEntryNodeChange: (value: string) => void;
  onCodexNodeParentChange: (value: string | null) => void;
  onCodexNodeTitleChange: (value: string) => void;
  onCodexNodeTypeChange: (value: CodexNodeType) => void;
  onCodexNodeCustomTypeLabelChange: (value: string) => void;
  onCodexNodeTagsChange: (value: string) => void;
};

function matchesQuery(value: string, query: string) {
  if (!query) {
    return true;
  }

  const haystack = value.trim().toLowerCase();
  return query
    .toLowerCase()
    .split(/\s+/)
    .every((token) => !token || haystack.includes(token));
}

function sortEntries(entries: CodexEntry[]) {
  return [...entries].sort((left, right) => {
    const updated = right.updatedAt.localeCompare(left.updatedAt);
    if (updated !== 0) {
      return updated;
    }

    return right.createdAt.localeCompare(left.createdAt);
  });
}

function filterCodexTree(
  nodes: CodexNodeTreeItem[],
  entriesByNodeId: Map<string, CodexEntry[]>,
  query: string,
) {
  if (!query.trim()) {
    return {
      visibleNodes: new Set(nodes.flatMap((node) => collectNodeIds(node))),
      visibleEntries: new Set(
        Array.from(entriesByNodeId.values())
          .flatMap((entries) => entries)
          .map((entry) => entry.id),
      ),
    };
  }

  const visibleNodes = new Set<string>();
  const visibleEntries = new Set<string>();

  const visit = (node: CodexNodeTreeItem): boolean => {
    const nodeMatches = matchesQuery(
      [node.title, node.type, node.customTypeLabel ?? '', node.tags.join(' ')].join(' '),
      query,
    );

    const directEntries = entriesByNodeId.get(node.id) ?? [];
    const matchingDirectEntries = directEntries.filter((entry) =>
      matchesQuery([entry.title, entry.type, entry.tags.join(' '), entry.content].join(' '), query),
    );
    const matchingChild = node.children.some((child) => visit(child));
    const visible = nodeMatches || matchingDirectEntries.length > 0 || matchingChild;

    if (visible) {
      visibleNodes.add(node.id);
      const entriesToShow = nodeMatches ? directEntries : matchingDirectEntries;
      for (const entry of entriesToShow) {
        visibleEntries.add(entry.id);
      }

      if (nodeMatches) {
        for (const child of node.children) {
          markSubtreeVisible(child, entriesByNodeId, visibleNodes, visibleEntries);
        }
      }
    }

    return visible;
  };

  for (const node of nodes) {
    visit(node);
  }

  return { visibleNodes, visibleEntries };
}

function collectNodeIds(node: CodexNodeTreeItem): string[] {
  return [node.id, ...node.children.flatMap((child) => collectNodeIds(child))];
}

function markSubtreeVisible(
  node: CodexNodeTreeItem,
  entriesByNodeId: Map<string, CodexEntry[]>,
  visibleNodes: Set<string>,
  visibleEntries: Set<string>,
) {
  visibleNodes.add(node.id);
  for (const entry of entriesByNodeId.get(node.id) ?? []) {
    visibleEntries.add(entry.id);
  }
  for (const child of node.children) {
    markSubtreeVisible(child, entriesByNodeId, visibleNodes, visibleEntries);
  }
}

export default function CodexPanel({
  projectId,
  sectionRef,
  nodes,
  flatNodeOptions,
  entries,
  selectedCodexNodeId,
  selectedCodexId,
  deleteableCodexNodeIds,
  editorMode,
  defaultCodexNodeId,
  isEditingCodexEntry,
  isEditingCodexNode,
  codexTitle,
  codexType,
  codexContent,
  codexTags,
  codexEntryNodeId,
  codexNodeParentId,
  codexNodeTitle,
  codexNodeType,
  codexNodeCustomTypeLabel,
  codexNodeTags,
  onSelectNode,
  onCreateEntry,
  onEditNode,
  onCreateRootNode,
  onCreateChildNode,
  onDeleteNode,
  onSelectEntry,
  onDeleteEntry,
  onEntrySubmit,
  onNodeSubmit,
  onCancelNodeEdit,
  onTitleChange,
  onTypeChange,
  onTagsChange,
  onContentChange,
  onCodexEntryNodeChange,
  onCodexNodeParentChange,
  onCodexNodeTitleChange,
  onCodexNodeTypeChange,
  onCodexNodeCustomTypeLabelChange,
  onCodexNodeTagsChange,
}: CodexPanelProps) {
  const [query, setQuery] = useState('');
  const [collapsedNodeIds, setCollapsedNodeIds] = useState<Set<string>>(() => new Set());

  const entriesByNodeId = useMemo(() => {
    const map = new Map<string, CodexEntry[]>();

    for (const entry of sortEntries(entries)) {
      const current = map.get(entry.codexNodeId) ?? [];
      current.push(entry);
      map.set(entry.codexNodeId, current);
    }

    return map;
  }, [entries]);

  const { visibleNodes, visibleEntries } = useMemo(
    () => filterCodexTree(nodes, entriesByNodeId, query),
    [entriesByNodeId, nodes, query],
  );

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }

    try {
      const raw = window.sessionStorage.getItem(`loreloom-collapsed-codex-nodes:${projectId}`);
      if (!raw) {
        setCollapsedNodeIds(new Set());
        return;
      }

      const parsed = JSON.parse(raw) as string[];
      setCollapsedNodeIds(new Set(Array.isArray(parsed) ? parsed : []));
    } catch {
      setCollapsedNodeIds(new Set());
    }
  }, [projectId]);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }

    window.sessionStorage.setItem(
      `loreloom-collapsed-codex-nodes:${projectId}`,
      JSON.stringify(Array.from(collapsedNodeIds)),
    );
  }, [collapsedNodeIds, projectId]);

  useEffect(() => {
    setCollapsedNodeIds((current) => {
      const validNodeIds = new Set(nodes.flatMap((node) => collectNodeIds(node)));
      const next = new Set(Array.from(current).filter((nodeId) => validNodeIds.has(nodeId)));
      return next.size === current.size ? current : next;
    });
  }, [nodes]);

  useEffect(() => {
    if (!query.trim()) {
      return;
    }

    setCollapsedNodeIds((current) => {
      const next = new Set(current);
      for (const nodeId of visibleNodes) {
        next.delete(nodeId);
      }
      return next;
    });
  }, [query, visibleNodes]);

  function toggleNodeCollapse(nodeId: string) {
    setCollapsedNodeIds((current) => {
      const next = new Set(current);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  }

  function renderNode(node: CodexNodeTreeItem, depth: number) {
    if (!visibleNodes.has(node.id)) {
      return null;
    }

    const nodeEntries = (entriesByNodeId.get(node.id) ?? []).filter((entry) => visibleEntries.has(entry.id));
    const hasVisibleChildren = node.children.some((child) => visibleNodes.has(child.id));
    const hasToggle = hasVisibleChildren || nodeEntries.length > 0;
    const isCollapsed = collapsedNodeIds.has(node.id);
    const isSelected = selectedCodexNodeId === node.id;
    const canDeleteNode = deleteableCodexNodeIds.has(node.id);

    return (
      <div key={node.id} className="space-y-2">
        <div
          className={`flex items-start gap-2 rounded-2xl border px-3 py-3 transition ${
            isSelected
              ? 'border-[color:var(--app-border-strong)] bg-[rgba(123,90,137,0.16)] shadow-[0_0_0_1px_rgba(198,154,84,0.16)]'
              : 'border-[color:var(--app-border)] bg-[rgba(16,10,20,0.78)]'
          }`}
          style={{ marginLeft: `${depth * 14}px` }}
        >
          <button
            type="button"
            aria-label={hasToggle ? (isCollapsed ? 'Expand node' : 'Collapse node') : 'Select node'}
            onClick={() => {
              onSelectNode(node.id);
              if (hasToggle) {
                toggleNodeCollapse(node.id);
              }
            }}
            className="app-focus-ring mt-1 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-[color:var(--app-border)] text-xs text-slate-300 transition hover:bg-white/[0.05]"
          >
            {hasToggle ? (isCollapsed ? '+' : '–') : '•'}
          </button>

          <button
            type="button"
            onClick={() => onSelectNode(node.id)}
            className="app-focus-ring min-w-0 flex-1 text-left"
          >
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="truncate font-medium text-white">{node.title}</h3>
              <span className="rounded-full border border-[color:var(--app-border)] px-2 py-1 text-[11px] uppercase tracking-[0.14em] text-slate-400">
                {getCodexNodeTypeLabel(node)}
              </span>
              {node.tags.length > 0 ? (
                <span className="rounded-full border border-[color:var(--app-border)] px-2 py-1 text-[11px] text-slate-400">
                  {node.tags.length} tag{node.tags.length === 1 ? '' : 's'}
                </span>
              ) : null}
            </div>
            <p className="mt-2 text-xs text-slate-400">
              {nodeEntries.length} entr{nodeEntries.length === 1 ? 'y' : 'ies'}
              {hasVisibleChildren ? ` • ${node.children.filter((child) => visibleNodes.has(child.id)).length} child nodes` : ''}
            </p>
            {node.tags.length > 0 ? (
              <div className="mt-3 flex flex-wrap gap-2">
                {node.tags.map((tag) => (
                  <span key={tag} className="app-panel-soft rounded-full px-2 py-1 text-xs text-slate-300">
                    {tag}
                  </span>
                ))}
              </div>
            ) : null}
          </button>

          <div className="flex shrink-0 flex-col items-end gap-2">
            <button
              type="button"
              onClick={() => onCreateChildNode(node.id)}
              className="app-link text-xs underline underline-offset-4"
            >
              Child node
            </button>
            <button
              type="button"
              onClick={() => {
                onSelectNode(node.id);
                onCreateEntry(node.id);
              }}
              className="app-link text-xs underline underline-offset-4"
            >
              New entry
            </button>
            <button
              type="button"
              onClick={() => onEditNode(node.id)}
              className="app-link text-xs underline underline-offset-4"
            >
              Edit
            </button>
            {canDeleteNode ? (
              <button
                type="button"
                onClick={() => onDeleteNode(node.id)}
                className="text-xs text-rose-200 underline underline-offset-4"
              >
                Delete
              </button>
            ) : null}
          </div>
        </div>

        {!isCollapsed ? (
          <div className="space-y-2">
            {nodeEntries.map((entry) => (
              <button
                key={entry.id}
                type="button"
                onClick={() => onSelectEntry(entry.id)}
                aria-pressed={selectedCodexId === entry.id}
                className={`app-focus-ring ml-8 w-[calc(100%-2rem)] rounded-2xl border px-4 py-3 text-left transition ${
                  selectedCodexId === entry.id
                    ? 'border-[color:var(--app-border-strong)] bg-[rgba(123,90,137,0.16)] shadow-[0_0_0_1px_rgba(198,154,84,0.16)]'
                    : 'border-[color:var(--app-border)] bg-[rgba(10,6,14,0.82)] hover:bg-white/[0.05]'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <h4 className="truncate font-medium text-white">{entry.title}</h4>
                    <p className="mt-1 text-xs uppercase tracking-[0.14em] text-slate-400">{entry.type}</p>
                  </div>
                  {entry.tags.length > 0 ? (
                    <span className="rounded-full border border-[color:var(--app-border)] px-2 py-1 text-xs text-slate-400">
                      {entry.tags.length} tag{entry.tags.length === 1 ? '' : 's'}
                    </span>
                  ) : null}
                </div>
                <p className="mt-3 line-clamp-3 text-sm leading-6 text-slate-300">
                  {entry.content.trim() || 'No details yet.'}
                </p>
              </button>
            ))}

            {node.children.map((child) => renderNode(child, depth + 1))}
          </div>
        ) : null}
      </div>
    );
  }

  const filteredNodeCount = visibleNodes.size;
  const filteredEntryCount = visibleEntries.size;

  return (
    <section ref={sectionRef} className="grid gap-4 lg:grid-cols-[1.05fr_0.95fr]">
      <div className="app-panel rounded-3xl p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold text-white">Codex</h2>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-300">
              Organize characters, places, factions, research, and lore into a nested codex tree that stays close to the draft.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onCreateRootNode}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
            >
              New node
            </button>
            <button
              type="button"
              onClick={() => onCreateEntry()}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
            >
              New entry
            </button>
          </div>
        </div>

        <div className="mt-5 grid gap-3 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
          <div>
            <label className="text-sm text-slate-300" htmlFor="codex-search">
              Search codex
            </label>
            <input
              id="codex-search"
              className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
              placeholder="Search nodes, tags, or entries"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </div>
          <p className="text-xs text-slate-400">
            {filteredNodeCount} node{filteredNodeCount === 1 ? '' : 's'} • {filteredEntryCount} entr
            {filteredEntryCount === 1 ? 'y' : 'ies'}
          </p>
        </div>

        <div className="mt-6 space-y-3">
          {nodes.length === 0 ? (
            <div className="app-panel-empty rounded-3xl p-6 text-slate-300">
              <h3 className="text-base font-medium text-white">No codex structure yet</h3>
              <p className="mt-2 text-sm leading-6 text-slate-300">
                Create a node for characters, places, factions, or research, then add entries inside it.
              </p>
            </div>
          ) : filteredNodeCount === 0 && filteredEntryCount === 0 ? (
            <div className="app-panel-empty rounded-3xl p-6 text-slate-300">
              <h3 className="text-base font-medium text-white">No matches</h3>
              <p className="mt-2 text-sm leading-6 text-slate-300">
                Try a different search term or clear the filter to see the full codex tree again.
              </p>
            </div>
          ) : (
            nodes.map((node) => renderNode(node, 0))
          )}
        </div>
      </div>

      {editorMode === 'node' ? (
        <form className="app-panel rounded-3xl p-6" onSubmit={onNodeSubmit}>
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="text-lg font-medium text-white">
                {isEditingCodexNode ? 'Edit Codex Node' : 'Create Codex Node'}
              </h3>
              <p className="mt-2 text-sm leading-6 text-slate-300">
                Use nodes to shape a clear hierarchy for characters, research, places, timelines, and anything custom.
              </p>
            </div>
            {isEditingCodexNode && selectedCodexNodeId && deleteableCodexNodeIds.has(selectedCodexNodeId) ? (
              <button
                type="button"
                onClick={() => onDeleteNode(selectedCodexNodeId)}
                className="app-button-danger inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
              >
                Delete node
              </button>
            ) : null}
          </div>

          <label className="mt-5 block text-sm text-slate-300" htmlFor="codex-node-title">
            Node title
          </label>
          <input
            id="codex-node-title"
            className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
            placeholder="Characters"
            value={codexNodeTitle}
            onChange={(event) => onCodexNodeTitleChange(event.target.value)}
          />

          <label className="mt-4 block text-sm text-slate-300" htmlFor="codex-node-type">
            Node type
          </label>
          <select
            id="codex-node-type"
            className="app-select app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
            value={codexNodeType}
            onChange={(event) => onCodexNodeTypeChange(event.target.value as CodexNodeType)}
          >
            {CODEX_NODE_TYPES.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>

          {codexNodeType === 'custom' ? (
            <>
              <label className="mt-4 block text-sm text-slate-300" htmlFor="codex-node-custom-type">
                Custom type label
              </label>
              <input
                id="codex-node-custom-type"
                className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
                placeholder="Research dossier"
                value={codexNodeCustomTypeLabel}
                onChange={(event) => onCodexNodeCustomTypeLabelChange(event.target.value)}
              />
            </>
          ) : null}

          {!isEditingCodexNode ? (
            <>
              <label className="mt-4 block text-sm text-slate-300" htmlFor="codex-node-parent">
                Parent node
              </label>
              <select
                id="codex-node-parent"
                className="app-select app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
                value={codexNodeParentId ?? ''}
                onChange={(event) => onCodexNodeParentChange(event.target.value || null)}
              >
                <option value="">Top level</option>
                {flatNodeOptions.map(({ node, depth }) => (
                  <option key={node.id} value={node.id}>
                    {`${'— '.repeat(depth)}${node.title}`}
                  </option>
                ))}
              </select>
            </>
          ) : (
            <div className="mt-4 rounded-2xl border border-[color:var(--app-border)] bg-[rgba(16,10,20,0.72)] px-4 py-3 text-sm text-slate-300">
              Parent node:{' '}
              <span className="text-white">
                {flatNodeOptions.find(({ node }) => node.id === codexNodeParentId)?.node.title ?? 'Top level'}
              </span>
            </div>
          )}

          <label className="mt-4 block text-sm text-slate-300" htmlFor="codex-node-tags">
            Tags
          </label>
          <input
            id="codex-node-tags"
            className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
            placeholder="characters, main cast"
            value={codexNodeTags}
            onChange={(event) => onCodexNodeTagsChange(event.target.value)}
          />

          <div className="mt-5 flex flex-wrap gap-3">
            <button
              type="submit"
              className="app-button-primary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
            >
              {isEditingCodexNode ? 'Save node' : 'Create node'}
            </button>
            <button
              type="button"
              onClick={onCancelNodeEdit}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
            >
              Back to entry editor
            </button>
          </div>
        </form>
      ) : (
        <form className="app-panel rounded-3xl p-6" onSubmit={onEntrySubmit}>
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="text-lg font-medium text-white">
                {isEditingCodexEntry ? 'Edit Codex Entry' : 'Create Codex Entry'}
              </h3>
              <p className="mt-2 text-sm leading-6 text-slate-300">
                {isEditingCodexEntry
                  ? 'You are editing an existing entry. Saving updates this entry in its current node.'
                  : 'Create a new worldbuilding entry inside the selected node.'}
              </p>
            </div>
            {isEditingCodexEntry ? (
              <button
                type="button"
                onClick={onDeleteEntry}
                className="app-button-danger inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium"
              >
                Delete entry
              </button>
            ) : null}
          </div>

          <label className="mt-5 block text-sm text-slate-300" htmlFor="codex-entry-node">
            Node
          </label>
          <select
            id="codex-entry-node"
            className="app-select app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
            value={codexEntryNodeId ?? defaultCodexNodeId ?? ''}
            onChange={(event) => onCodexEntryNodeChange(event.target.value)}
          >
            {flatNodeOptions.map(({ node, depth }) => (
              <option key={node.id} value={node.id}>
                {`${'— '.repeat(depth)}${node.title}`}
              </option>
            ))}
          </select>

          <label className="mt-4 block text-sm text-slate-300" htmlFor="codex-title">
            Title
          </label>
          <input
            id="codex-title"
            className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
            placeholder="Captain Iri"
            value={codexTitle}
            onChange={(event) => onTitleChange(event.target.value)}
          />

          <label className="mt-4 block text-sm text-slate-300" htmlFor="codex-type">
            Type
          </label>
          <select
            id="codex-type"
            className="app-select app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
            value={codexType}
            onChange={(event) => onTypeChange(event.target.value as CodexEntryType)}
          >
            {CODEX_ENTRY_TYPES.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>

          <label className="mt-4 block text-sm text-slate-300" htmlFor="codex-tags">
            Tags
          </label>
          <input
            id="codex-tags"
            className="app-input app-focus-ring mt-2 w-full rounded-xl px-3 py-2"
            placeholder="pirate, ally, missing"
            value={codexTags}
            onChange={(event) => onTagsChange(event.target.value)}
          />

          <label className="mt-4 block text-sm text-slate-300" htmlFor="codex-content">
            Notes
          </label>
          <textarea
            id="codex-content"
            className="app-textarea app-focus-ring mt-2 min-h-48 w-full rounded-2xl px-3 py-3"
            placeholder="Add details that matter to the story."
            value={codexContent}
            onChange={(event) => onContentChange(event.target.value)}
          />

          <div className="mt-5 flex flex-wrap gap-3">
            <button
              type="submit"
              className="app-button-primary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
            >
              {isEditingCodexEntry ? 'Save entry' : 'Create entry'}
            </button>
            <button
              type="button"
              onClick={() => {
                if (selectedCodexNodeId) {
                  onCreateChildNode(selectedCodexNodeId);
                  return;
                }
                onCreateRootNode();
              }}
              className="app-button-secondary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium"
            >
              New node instead
            </button>
          </div>
        </form>
      )}
    </section>
  );
}
