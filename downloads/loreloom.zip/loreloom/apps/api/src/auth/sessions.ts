import { createHash, randomBytes } from 'node:crypto';
import type { AppConfig } from '../config.js';

const SESSION_TOKEN_LENGTH_BYTES = 32;
const SESSION_ID_LENGTH_BYTES = 18;
const SESSION_TOUCH_INTERVAL_MS = 15 * 60 * 1000;

export type SessionCookieOptions = {
  cookieName: string;
  expiresAt: string;
  httpOnly?: boolean;
  path?: string;
  sameSite?: 'Strict' | 'Lax' | 'None';
  secure?: boolean;
};

function formatExpires(expiresAt: string): string {
  return new Date(expiresAt).toUTCString();
}

export function createSessionId(): string {
  return randomBytes(SESSION_ID_LENGTH_BYTES).toString('base64url');
}

export function createSessionToken(): string {
  return randomBytes(SESSION_TOKEN_LENGTH_BYTES).toString('base64url');
}

export function createUserId(): string {
  return `user_${randomBytes(18).toString('base64url')}`;
}

export function hashSessionToken(sessionToken: string): string {
  return createHash('sha256').update(sessionToken).digest('base64url');
}

export function createSessionExpiry(config: Pick<AppConfig, 'authSessionDurationHours'>, now = new Date()): string {
  return new Date(now.getTime() + config.authSessionDurationHours * 60 * 60 * 1000).toISOString();
}

export function isSessionExpired(expiresAt: string, now = new Date()): boolean {
  return Date.parse(expiresAt) <= now.getTime();
}

export function serializeSessionCookie(sessionToken: string, options: SessionCookieOptions): string {
  const segments = [
    `${options.cookieName}=${encodeURIComponent(sessionToken)}`,
    `Expires=${formatExpires(options.expiresAt)}`,
    `Path=${options.path ?? '/'}`,
    `SameSite=${options.sameSite ?? 'Lax'}`,
  ];

  if (options.httpOnly ?? true) {
    segments.push('HttpOnly');
  }

  if (options.secure ?? false) {
    segments.push('Secure');
  }

  return segments.join('; ');
}

export function serializeClearedSessionCookie(
  cookieName: string,
  options: Pick<SessionCookieOptions, 'path' | 'sameSite' | 'httpOnly' | 'secure'> = {},
): string {
  return serializeSessionCookie('', {
    cookieName,
    expiresAt: new Date(0).toISOString(),
    path: options.path,
    sameSite: options.sameSite,
    httpOnly: options.httpOnly,
    secure: options.secure,
  });
}

export function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  if (!cookieHeader) {
    return {};
  }

  return cookieHeader
    .split(';')
    .map((segment) => segment.trim())
    .filter(Boolean)
    .reduce<Record<string, string>>((cookies, segment) => {
      const separatorIndex = segment.indexOf('=');

      if (separatorIndex <= 0) {
        return cookies;
      }

      const name = segment.slice(0, separatorIndex).trim();
      const value = segment.slice(separatorIndex + 1).trim();

      if (!name) {
        return cookies;
      }

      try {
        cookies[name] = decodeURIComponent(value);
      } catch {
        cookies[name] = value;
      }

      return cookies;
    }, {});
}

export function getSessionTokenFromCookieHeader(
  cookieHeader: string | undefined,
  cookieName: string,
): string | null {
  const cookies = parseCookies(cookieHeader);
  const sessionToken = cookies[cookieName];

  return sessionToken?.trim() ? sessionToken.trim() : null;
}

export function shouldTouchSession(lastSeenAt: string | null, now = new Date()): boolean {
  if (!lastSeenAt) {
    return true;
  }

  const lastSeenTimestamp = Date.parse(lastSeenAt);

  if (Number.isNaN(lastSeenTimestamp)) {
    return true;
  }

  return now.getTime() - lastSeenTimestamp >= SESSION_TOUCH_INTERVAL_MS;
}
