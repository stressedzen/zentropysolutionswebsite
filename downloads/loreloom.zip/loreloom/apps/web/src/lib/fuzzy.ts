export function fuzzyScore(query: string, candidate: string) {
  const normalizedQuery = query.trim().toLowerCase();
  const normalizedCandidate = candidate.trim().toLowerCase();

  if (!normalizedQuery) {
    return 0;
  }

  let score = 0;
  let queryIndex = 0;
  let consecutive = 0;

  for (let index = 0; index < normalizedCandidate.length && queryIndex < normalizedQuery.length; index += 1) {
    if (normalizedCandidate[index] !== normalizedQuery[queryIndex]) {
      consecutive = 0;
      continue;
    }

    score += consecutive > 0 ? 3 : 1;
    consecutive += 1;
    queryIndex += 1;
  }

  if (queryIndex !== normalizedQuery.length) {
    return -1;
  }

  if (normalizedCandidate.startsWith(normalizedQuery)) {
    score += 5;
  }

  return score;
}
