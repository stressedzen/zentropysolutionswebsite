import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { fetchBackendDiagnosticsExport } from '../lib/api';
import { exportDiagnosticBundleFile } from '../lib/diagnostics';
import { useLoreLoomStore } from '../store/useLoreLoomStore';

function formatBytes(value: number | null) {
  if (value === null || !Number.isFinite(value)) {
    return 'Unavailable';
  }

  if (value < 1024) {
    return `${value} B`;
  }

  if (value < 1024 * 1024) {
    return `${(value / 1024).toFixed(1)} KB`;
  }

  return `${(value / (1024 * 1024)).toFixed(2)} MB`;
}

export default function DiagnosticsPage() {
  const diagnosticsState = useLoreLoomStore((state) => state.diagnostics);
  const persistedState = useLoreLoomStore((state) => state);
  const projects = useLoreLoomStore((state) => state.projects);
  const structureNodes = useLoreLoomStore((state) => state.structureNodes);
  const scenes = useLoreLoomStore((state) => state.scenes);
  const codexNodes = useLoreLoomStore((state) => state.codexNodes);
  const codexEntries = useLoreLoomStore((state) => state.codexEntries);
  const revisionSnapshots = useLoreLoomStore((state) => state.revisionSnapshots);
  const sync = useLoreLoomStore((state) => state.sync);
  const recordDiagnosticEvent = useLoreLoomStore((state) => state.recordDiagnosticEvent);
  const [isExporting, setIsExporting] = useState(false);
  const [backendDiagnostics, setBackendDiagnostics] = useState<Awaited<
    ReturnType<typeof fetchBackendDiagnosticsExport>
  > | null>(null);
  const [backendDiagnosticsError, setBackendDiagnosticsError] = useState<string | null>(null);

  const summary = useMemo(
    () => ({
      projectCount: projects.length,
      structureNodeCount: structureNodes.length,
      textBlockCount: scenes.length,
      codexNodeCount: codexNodes.length,
      codexEntryCount: codexEntries.length,
      revisionSnapshotCount: revisionSnapshots.length,
      dirtyProjectCount: Object.values(sync.projects).filter((entry) => entry.dirty).length,
      conflictProjectCount: Object.values(sync.projects).filter((entry) => entry.status === 'conflict').length,
      offlineProjectCount: Object.values(sync.projects).filter((entry) => entry.status === 'offline').length,
      pendingDeleteCount: sync.pendingDeletes.length,
    }),
    [codexEntries.length, codexNodes.length, projects.length, revisionSnapshots.length, scenes.length, structureNodes.length, sync],
  );

  useEffect(() => {
    let cancelled = false;

    void fetchBackendDiagnosticsExport()
      .then((value) => {
        if (cancelled) {
          return;
        }

        setBackendDiagnostics(value);
        setBackendDiagnosticsError(null);
      })
      .catch((error) => {
        if (cancelled) {
          return;
        }

        setBackendDiagnosticsError(error instanceof Error ? error.message : 'Could not load backend diagnostics.');
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link to="/" className="app-link text-sm underline underline-offset-4">
          Back to dashboard
        </Link>
        <button
          type="button"
          disabled={isExporting}
          onClick={async () => {
            try {
              setIsExporting(true);
              await exportDiagnosticBundleFile(persistedState);
              recordDiagnosticEvent({
                type: 'diagnostic_bundle_exported',
                status: 'ok',
                message: 'Diagnostic bundle exported locally.',
              });
            } finally {
              setIsExporting(false);
            }
          }}
          className="app-button-primary app-focus-ring inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-60"
        >
          {isExporting ? 'Preparing bundle...' : 'Export Diagnostic Bundle'}
        </button>
      </div>

      <section className="app-panel rounded-3xl p-6">
        <p className="app-accent-label text-sm uppercase tracking-[0.18em]">Diagnostics</p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight text-white">Local deployment diagnostics</h1>
        <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-300">
          Export a manual diagnostic bundle if you want to share deployment or sync issues with the developer.
        </p>
        <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-400">
          Export a diagnostic bundle, then share it with the developer through{' '}
          <a
            href="https://discord.gg/ktUw2gsyAW"
            target="_blank"
            rel="noreferrer"
            className="app-link underline underline-offset-4 transition"
          >
            Discord
          </a>{' '}
          if requested.
        </p>
        <p className="mt-2 text-sm leading-6 text-slate-400">
          This file does not include your manuscript or codex content.
        </p>
        <p className="mt-1 text-sm leading-6 text-slate-400">You can inspect it before sending.</p>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <div className="app-panel-soft rounded-2xl px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Projects</p>
          <p className="mt-2 text-lg font-medium text-white">{summary.projectCount}</p>
        </div>
        <div className="app-panel-soft rounded-2xl px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Text Blocks</p>
          <p className="mt-2 text-lg font-medium text-white">{summary.textBlockCount}</p>
        </div>
        <div className="app-panel-soft rounded-2xl px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Codex Nodes</p>
          <p className="mt-2 text-lg font-medium text-white">{summary.codexNodeCount}</p>
        </div>
        <div className="app-panel-soft rounded-2xl px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Codex Entries</p>
          <p className="mt-2 text-lg font-medium text-white">{summary.codexEntryCount}</p>
        </div>
        <div className="app-panel-soft rounded-2xl px-4 py-3">
          <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Snapshots</p>
          <p className="mt-2 text-lg font-medium text-white">{summary.revisionSnapshotCount}</p>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="app-panel rounded-3xl p-6">
          <h2 className="text-lg font-medium text-white">Sync summary</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="app-panel-inset rounded-2xl px-4 py-3">
              <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Dirty Projects</p>
              <p className="mt-2 text-base font-medium text-white">{summary.dirtyProjectCount}</p>
            </div>
            <div className="app-panel-inset rounded-2xl px-4 py-3">
              <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Conflicts</p>
              <p className="mt-2 text-base font-medium text-white">{summary.conflictProjectCount}</p>
            </div>
            <div className="app-panel-inset rounded-2xl px-4 py-3">
              <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Offline Statuses</p>
              <p className="mt-2 text-base font-medium text-white">{summary.offlineProjectCount}</p>
            </div>
            <div className="app-panel-inset rounded-2xl px-4 py-3">
              <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Pending Deletes</p>
              <p className="mt-2 text-base font-medium text-white">{summary.pendingDeleteCount}</p>
            </div>
          </div>

          <div className="app-panel-inset mt-5 rounded-2xl p-4">
            <h3 className="text-sm font-medium text-white">Per-project sync state</h3>
            <div className="mt-3 space-y-3">
              {projects.length > 0 ? (
                projects.map((project) => {
                  const syncEntry = sync.projects[project.id];
                  return (
                    <div key={project.id} className="app-panel-soft rounded-2xl p-4">
                      <p className="text-xs uppercase tracking-[0.16em] text-slate-500">Project ID</p>
                      <p className="mt-1 break-all text-sm text-slate-200">{project.id}</p>
                      <div className="mt-3 grid gap-2 sm:grid-cols-2">
                        <p className="text-sm text-slate-300">Status: {syncEntry?.status ?? 'idle'}</p>
                        <p className="text-sm text-slate-300">Dirty: {syncEntry?.dirty ? 'yes' : 'no'}</p>
                        <p className="text-sm text-slate-300">
                          Server revision: {syncEntry?.serverRevision ?? 'none'}
                        </p>
                        <p className="text-sm text-slate-300">Last sync: {syncEntry?.lastSyncAt ?? 'never'}</p>
                      </div>
                      {syncEntry?.error ? (
                        <p className="mt-3 text-sm leading-6 text-amber-200">Error: {syncEntry.error}</p>
                      ) : null}
                    </div>
                  );
                })
              ) : (
                <p className="text-sm text-slate-400">No local projects yet.</p>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <section className="app-panel rounded-3xl p-6">
            <h2 className="text-lg font-medium text-white">Backend</h2>
            {backendDiagnostics ? (
              <div className="mt-4 space-y-3 text-sm text-slate-300">
                <p>App: {backendDiagnostics.backend.appName}</p>
                <p>Version: {backendDiagnostics.backend.appVersion}</p>
                <p>Node environment: {backendDiagnostics.backend.config.nodeEnv}</p>
                <p>Log level: {backendDiagnostics.backend.config.logLevel}</p>
                <p>Request size limit: {backendDiagnostics.backend.config.maxRequestBodyBytes.toLocaleString()} bytes</p>
                <p>Database path: {backendDiagnostics.backend.config.databasePath}</p>
                <p>Diagnostics history enabled on backend: {backendDiagnostics.diagnosticsEnabled ? 'yes' : 'no'}</p>
              </div>
            ) : (
              <p className="mt-4 text-sm leading-6 text-slate-400">
                {backendDiagnosticsError ?? 'Loading backend diagnostics...'}
              </p>
            )}
          </section>

          <section className="app-panel rounded-3xl p-6">
            <h2 className="text-lg font-medium text-white">Local environment</h2>
            <div className="mt-4 space-y-3 text-sm text-slate-300">
              <p>Backend status: {sync.backendStatus}</p>
              <p>Hydration state: {sync.hydrationState}</p>
              <p>Recent diagnostic events: {diagnosticsState.events.length}</p>
              <p>Browser local storage key present: {typeof window !== 'undefined' ? 'yes' : 'no'}</p>
            </div>
          </section>
        </div>
      </section>

      <section className="app-panel rounded-3xl p-6">
        <h2 className="text-lg font-medium text-white">Recent diagnostics events</h2>
        {diagnosticsState.events.length === 0 ? (
          <p className="mt-4 text-sm leading-6 text-slate-400">
            No diagnostics events recorded yet. Sync activity will appear here over time.
          </p>
        ) : (
          <div className="mt-4 space-y-3">
            {diagnosticsState.events.slice(0, 25).map((event) => (
              <article key={event.id} className="app-panel-inset rounded-2xl p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium text-white">{event.type}</p>
                    <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-500">{event.at}</p>
                  </div>
                  <span className="rounded-full border border-[color:var(--app-border)] px-3 py-1 text-xs text-slate-300">
                    {event.status ?? 'event'}
                  </span>
                </div>
                {event.projectId ? (
                  <p className="mt-3 break-all text-sm text-slate-300">Project ID: {event.projectId}</p>
                ) : null}
                {event.message ? <p className="mt-3 text-sm leading-6 text-slate-300">{event.message}</p> : null}
              </article>
            ))}
          </div>
        )}
      </section>

      <section className="app-panel rounded-3xl p-6">
        <h2 className="text-lg font-medium text-white">Privacy reminder</h2>
        <ul className="mt-4 space-y-2 text-sm leading-6 text-slate-300">
          <li>Included: IDs, counts, timestamps, sync states, event types, and error messages.</li>
          <li>Excluded: manuscript text, text block content, codex content, revision snapshot content, and titles.</li>
          <li>Sharing is always manual. LoreLoom does not upload this file automatically.</li>
        </ul>
      </section>
    </div>
  );
}
