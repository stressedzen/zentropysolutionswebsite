CREATE TABLE IF NOT EXISTS codex_nodes (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  parent_id TEXT NULL,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  custom_type_label TEXT NULL,
  tags_json TEXT NOT NULL,
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_id) REFERENCES codex_nodes(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS codex_nodes_project_id_idx ON codex_nodes(project_id);
CREATE INDEX IF NOT EXISTS codex_nodes_parent_id_idx ON codex_nodes(parent_id);
CREATE INDEX IF NOT EXISTS codex_nodes_project_parent_order_idx
  ON codex_nodes(project_id, parent_id, order_index);

ALTER TABLE codex_entries
ADD COLUMN codex_node_id TEXT NULL REFERENCES codex_nodes(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS codex_entries_codex_node_id_idx ON codex_entries(codex_node_id);
