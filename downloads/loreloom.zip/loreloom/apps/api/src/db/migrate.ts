import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import type { SqliteDatabase } from './pragmas.js';
import { createDatabase } from './client.js';
import { loadConfig } from '../config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type MigrationFile = {
  version: number;
  name: string;
  filename: string;
  sql: string;
};

function resolveMigrationsDirectory() {
  const candidateDirectories = [
    path.join(__dirname, 'migrations'),
    path.resolve(__dirname, '..', '..', 'src', 'db', 'migrations'),
  ];

  for (const candidate of candidateDirectories) {
    if (fs.existsSync(candidate)) {
      return candidate;
    }
  }

  throw new Error('Could not locate the migrations directory.');
}

function ensureSchemaMigrationsTable(database: SqliteDatabase) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
  `);
}

function readMigrationFiles(): MigrationFile[] {
  const migrationsDirectory = resolveMigrationsDirectory();

  return fs
    .readdirSync(migrationsDirectory)
    .filter((filename) => filename.endsWith('.sql'))
    .sort()
    .map((filename) => {
      const [versionPart, ...nameParts] = filename.replace(/\.sql$/, '').split('_');
      const version = Number.parseInt(versionPart, 10);

      if (!Number.isInteger(version)) {
        throw new Error(`Invalid migration filename: ${filename}`);
      }

      return {
        version,
        name: nameParts.join('_') || 'migration',
        filename,
        sql: fs.readFileSync(path.join(migrationsDirectory, filename), 'utf8'),
      };
    });
}

export function runMigrations(database: SqliteDatabase) {
  ensureSchemaMigrationsTable(database);

  const appliedVersions = new Set<number>(
    (database.prepare('SELECT version FROM schema_migrations ORDER BY version ASC').all() as Array<{
      version: number;
    }>).map((row) => row.version),
  );

  const migrations = readMigrationFiles();

  for (const migration of migrations) {
    if (appliedVersions.has(migration.version)) {
      continue;
    }

    const transaction = database.transaction(() => {
      database.exec(migration.sql);
      database
        .prepare('INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)')
        .run(migration.version, migration.name, new Date().toISOString());
    });

    transaction();
  }
}

function main() {
  const config = loadConfig();
  const database = createDatabase(config.databasePath);

  runMigrations(database);
  database.close();

  // Keep the output short because this command will often be run in scripts.
  console.log(`Migrations complete for ${config.databasePath}`);
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  main();
}
