import type { SqliteDatabase } from '../db/pragmas.js';
import type { AppConfig } from '../config.js';
import { hashPassword, verifyPassword } from '../auth/passwords.js';
import {
  createSessionExpiry,
  createSessionId,
  createSessionToken,
  createUserId,
  getSessionTokenFromCookieHeader,
  hashSessionToken,
  isSessionExpired,
  shouldTouchSession,
} from '../auth/sessions.js';
import { isSetupRequired } from '../auth/setup.js';
import { assignUnownedProjectsToOwner } from '../repositories/project-bundles.js';
import {
  createSession,
  deleteSessionByTokenHash,
  findSessionByTokenHash,
  touchSession,
} from '../repositories/sessions.js';
import {
  countUsers,
  createUser,
  findUserById,
  findUserByUsername,
  updateUserPasswordHash,
  type UserRow,
} from '../repositories/users.js';
import { deleteSessionsByUserIdExcept } from '../repositories/sessions.js';

export type AuthenticatedUser = {
  id: string;
  username: string;
  displayName: string | null;
  role: UserRow['role'];
};

export type SetupStatus = {
  setupRequired: boolean;
};

export type SetupAdminInput = {
  username: string;
  password: string;
  displayName: string | null;
};

export type LoginInput = {
  username: string;
  password: string;
};

export type AuthResult =
  | {
      status: 'authenticated';
      user: AuthenticatedUser;
      sessionToken: string;
      expiresAt: string;
    }
  | {
      status: 'invalid_credentials';
    }
  | {
      status: 'setup_already_completed';
    };

export type LoginResult =
  | {
      status: 'authenticated';
      user: AuthenticatedUser;
      sessionToken: string;
      expiresAt: string;
    }
  | {
      status: 'invalid_credentials';
    };

export type CurrentUserResult = {
  authenticated: boolean;
  user: AuthenticatedUser | null;
  clearCookie: boolean;
};

export type CurrentSessionResult =
  | {
      authenticated: true;
      user: AuthenticatedUser;
      sessionId: string;
      clearCookie: false;
    }
  | {
      authenticated: false;
      user: null;
      sessionId: null;
      clearCookie: boolean;
    };

export type ChangePasswordInput = {
  currentPassword: string;
  newPassword: string;
};

export type ChangePasswordResult =
  | {
      status: 'changed';
      user: AuthenticatedUser;
    }
  | {
      status: 'invalid_current_password';
    }
  | {
      status: 'not_authenticated';
    };

function normalizeUsername(username: string): string {
  return username.trim().toLowerCase();
}

function mapAuthenticatedUser(user: UserRow): AuthenticatedUser {
  return {
    id: user.id,
    username: user.username,
    displayName: user.display_name,
    role: user.role,
  };
}

function createSessionForUser(
  database: SqliteDatabase,
  config: Pick<AppConfig, 'authSessionDurationHours'>,
  userId: string,
  now = new Date(),
) {
  const createdAt = now.toISOString();
  const sessionToken = createSessionToken();
  const expiresAt = createSessionExpiry(config, now);

  createSession(database, {
    id: createSessionId(),
    userId,
    sessionTokenHash: hashSessionToken(sessionToken),
    createdAt,
    expiresAt,
    lastSeenAt: createdAt,
  });

  return {
    sessionToken,
    expiresAt,
  };
}

export function getSetupStatus(database: SqliteDatabase): SetupStatus {
  return {
    setupRequired: isSetupRequired(countUsers(database)),
  };
}

export async function createFirstAdminUser(
  database: SqliteDatabase,
  config: Pick<AppConfig, 'authSessionDurationHours'>,
  input: SetupAdminInput,
): Promise<AuthResult> {
  const now = new Date();
  const createdAt = now.toISOString();
  const normalizedUsername = normalizeUsername(input.username);
  const passwordHash = await hashPassword(input.password);

  const transaction = database.transaction(() => {
    if (!isSetupRequired(countUsers(database))) {
      return {
        status: 'setup_already_completed' as const,
      };
    }

    const user = createUser(database, {
      id: createUserId(),
      username: normalizedUsername,
      passwordHash,
      displayName: input.displayName,
      role: 'admin',
      createdAt,
      updatedAt: createdAt,
    });

    assignUnownedProjectsToOwner(database, user.id);

    const session = createSessionForUser(database, config, user.id, now);

    return {
      user,
      session,
    };
  });

  const result = transaction();

  if (result.status === 'setup_already_completed') {
    return result;
  }

  return {
    status: 'authenticated',
    user: mapAuthenticatedUser(result.user),
    sessionToken: result.session.sessionToken,
    expiresAt: result.session.expiresAt,
  };
}

export async function loginUser(
  database: SqliteDatabase,
  config: Pick<AppConfig, 'authSessionDurationHours'>,
  input: LoginInput,
): Promise<LoginResult> {
  const user = findUserByUsername(database, normalizeUsername(input.username));

  if (!user) {
    return {
      status: 'invalid_credentials',
    };
  }

  const passwordMatches = await verifyPassword(input.password, user.password_hash);

  if (!passwordMatches) {
    return {
      status: 'invalid_credentials',
    };
  }

  const session = createSessionForUser(database, config, user.id);

  return {
    status: 'authenticated',
    user: mapAuthenticatedUser(user),
    sessionToken: session.sessionToken,
    expiresAt: session.expiresAt,
  };
}

export function getCurrentAuthenticatedUser(
  database: SqliteDatabase,
  cookieHeader: string | undefined,
  config: Pick<AppConfig, 'authCookieName'>,
): CurrentUserResult {
  const currentSession = getCurrentAuthenticatedSession(database, cookieHeader, config);

  return {
    authenticated: currentSession.authenticated,
    user: currentSession.user,
    clearCookie: currentSession.clearCookie,
  };
}

export function getCurrentAuthenticatedSession(
  database: SqliteDatabase,
  cookieHeader: string | undefined,
  config: Pick<AppConfig, 'authCookieName'>,
): CurrentSessionResult {
  const sessionToken = getSessionTokenFromCookieHeader(cookieHeader, config.authCookieName);

  if (!sessionToken) {
    return {
      authenticated: false,
      user: null,
      sessionId: null,
      clearCookie: false,
    };
  }

  const tokenHash = hashSessionToken(sessionToken);
  const session = findSessionByTokenHash(database, tokenHash);

  if (!session) {
    return {
      authenticated: false,
      user: null,
      sessionId: null,
      clearCookie: true,
    };
  }

  if (isSessionExpired(session.expires_at)) {
    deleteSessionByTokenHash(database, tokenHash);
    return {
      authenticated: false,
      user: null,
      sessionId: null,
      clearCookie: true,
    };
  }

  const user = findUserById(database, session.user_id);

  if (!user) {
    deleteSessionByTokenHash(database, tokenHash);
    return {
      authenticated: false,
      user: null,
      sessionId: null,
      clearCookie: true,
    };
  }

  if (shouldTouchSession(session.last_seen_at)) {
    touchSession(database, session.id, new Date().toISOString());
  }

  return {
    authenticated: true,
    user: mapAuthenticatedUser(user),
    sessionId: session.id,
    clearCookie: false,
  };
}

export function logoutUser(
  database: SqliteDatabase,
  cookieHeader: string | undefined,
  config: Pick<AppConfig, 'authCookieName'>,
): void {
  const sessionToken = getSessionTokenFromCookieHeader(cookieHeader, config.authCookieName);

  if (!sessionToken) {
    return;
  }

  deleteSessionByTokenHash(database, hashSessionToken(sessionToken));
}

export async function changePasswordForCurrentUser(
  database: SqliteDatabase,
  config: Pick<AppConfig, 'authCookieName'>,
  cookieHeader: string | undefined,
  input: ChangePasswordInput,
): Promise<ChangePasswordResult> {
  const currentSession = getCurrentAuthenticatedSession(database, cookieHeader, config);

  if (!currentSession.authenticated || !currentSession.user || !currentSession.sessionId) {
    return {
      status: 'not_authenticated',
    };
  }

  const currentUser = findUserById(database, currentSession.user.id);

  if (!currentUser) {
    return {
      status: 'not_authenticated',
    };
  }

  const currentPasswordMatches = await verifyPassword(input.currentPassword, currentUser.password_hash);

  if (!currentPasswordMatches) {
    return {
      status: 'invalid_current_password',
    };
  }

  const nextPasswordHash = await hashPassword(input.newPassword);
  const updatedAt = new Date().toISOString();

  database.transaction(() => {
    updateUserPasswordHash(database, {
      userId: currentUser.id,
      passwordHash: nextPasswordHash,
      updatedAt,
    });
    deleteSessionsByUserIdExcept(database, currentUser.id, currentSession.sessionId);
    touchSession(database, currentSession.sessionId, updatedAt);
  })();

  const updatedUser = findUserById(database, currentUser.id);

  if (!updatedUser) {
    return {
      status: 'not_authenticated',
    };
  }

  return {
    status: 'changed',
    user: mapAuthenticatedUser(updatedUser),
  };
}
