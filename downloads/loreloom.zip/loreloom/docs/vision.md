# LoreLoom Vision

LoreLoom is a lightweight, self-hostable writing and worldbuilding platform.

The product should:
- work without AI
- run cheaply on low-power hardware such as a Raspberry Pi
- avoid vendor lock-in
- support clean export
- keep AI optional and provider-agnostic
- prefer simple architecture over clever architecture

## Current Slice

The first vertical slice is a local-only web app with:
- a dashboard of projects
- project creation
- scene creation
- a scene editor with title and rich text content
- persistence in the browser via `localStorage`

This slice intentionally stops short of backend services, auth, databases, and AI.
